(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"jetfam_300x600_fr_atlas_P_1", frames: [[0,0,557,1114],[0,1116,131,130],[133,1116,121,121],[256,1116,121,121]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset1tearDBL = function() {
	this.initialize(ss["jetfam_300x600_fr_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset2pngcopy = function() {
	this.initialize(ss["jetfam_300x600_fr_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Asset3 = function() {
	this.initialize(ss["jetfam_300x600_fr_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Asset4 = function() {
	this.initialize(ss["jetfam_300x600_fr_atlas_P_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBJAAIAAAwg");
	this.shape.setTransform(89.75,-163.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag1BHQgdgaAAgtQAAgsAdgbQAcgYAqAAQAqAAAUARIgQA0QgTgRgXAAQgTAAgKALQgNALAAAVQAAATANAMQALAKASAAQAcAAAQgRIASAwQgXAYgrAAQgqAAgcgZg");
	this.shape_1.setTransform(73.4,-163.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_2.setTransform(56.525,-163.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag/BJQgVgUAAgpIAAhqIA+AAIAABtQAAAOAFAGQAIAHAJAAQALAAAGgHQAHgGAAgOIAAhtIA9AAIAABqQAAApgUAUQgWAWgrAAQgpAAgWgWg");
	this.shape_3.setTransform(37.05,-163.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhHBHQgdgaAAgtQAAgsAdgaQAbgaAsAAQAsAAAcAaQAdAaAAAsQAAAtgdAaQgcAZgsABQgsgBgbgZgAgcgfQgLALAAATQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgTgLgLQgLgMgSgBQgRABgLAMg");
	this.shape_4.setTransform(16.725,-163.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhKBHIAbguQALAKARAFQANAFAHAAQAOAAAAgIQAAgFgOgFIgagIQgSgHgHgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgWArQgKgJgPgFQgMgEgIAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPAAAZQABAegYATQgWAQggAAQgnAAghgZg");
	this.shape_5.setTransform(-1.75,-163.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAgBdIgHgaIg0AAIgHAaIg/AAIBAi5IBCAAIBCC5gAAMAUIgMgxIgPAxIAbAAg");
	this.shape_6.setTransform(-24.1,-163.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag9BdIAAi5IA8AAIAACHIA/AAIAAAyg");
	this.shape_7.setTransform(-40.15,-163.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhCBdIAAi5ICDAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBKAAIAAAwg");
	this.shape_8.setTransform(-60.5,-163.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhXBdIAAi5IBGAAQAvAAAbAUQAfAYAAAwQAAAxgfAYQgbAUgvAAgAgaAqIAOAAQASAAAJgKQALgKAAgWQAAgWgLgLQgJgJgSAAIgOAAg");
	this.shape_9.setTransform(-77.875,-163.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-177.9,189.5,31);


(lib.text3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhCB1IAAi6ICDAAIAAAwIhHAAIAAAVIBDAAIAAAvIhDAAIAAAVIBKAAIAAAxgAgehNIATgnIAvAAIgZAng");
	this.shape.setTransform(71.25,-191.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgdBdIAAiKIgsAAIAAgvICTAAIAAAvIgrAAIAACKg");
	this.shape_1.setTransform(55.725,-188.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdBdIAAi5IA8AAIAAC5g");
	this.shape_2.setTransform(43.9,-188.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgdBdIhGi5IBBAAIAiBrIAjhrIBBAAIhGC5g");
	this.shape_3.setTransform(29.825,-188.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgdBdIAAi5IA7AAIAAC5g");
	this.shape_4.setTransform(15.7,-188.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhLBHIAbguQAMAKAQAFQAOAFAHAAQAOAAAAgIQAAgFgNgFIgagIQgTgHgHgHQgRgOAAgZQAAgbAVgSQAUgQAiAAQAoAAAbAXIgYArQgJgJgPgFQgLgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQASAPAAAZQAAAegZATQgUAQgiAAQgmAAgigZg");
	this.shape_5.setTransform(3.5,-188.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag/BJQgVgUAAgpIAAhqIA9AAIAABtQAAAOAHAGQAGAHAKAAQALAAAHgHQAFgGAAgOIAAhtIA+AAIAABqQAAApgUAUQgWAWgrAAQgqAAgVgWg");
	this.shape_6.setTransform(-13.75,-188.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag9BdIAAi5IA8AAIAACHIA/AAIAAAyg");
	this.shape_7.setTransform(-29.35,-188.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag1BHQgdgaAAgtQAAgsAdgbQAbgYArAAQAqAAAUARIgQA0QgTgRgXAAQgTAAgKALQgNALAAAVQAAATAOAMQAKAKASAAQAcAAAQgRIASAwQgYAYgqAAQgrAAgbgZg");
	this.shape_8.setTransform(-45.15,-188.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAeBdIgeg7IgdA7IhJAAIA+hgIg6hZIBJAAIAZAyIAagyIBJAAIg7BZIA/Bgg");
	this.shape_9.setTransform(-62.625,-188.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBJAAIAAAwg");
	this.shape_10.setTransform(-79.9,-188.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-203.2,171,31);


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBJAAIAAAwg");
	this.shape.setTransform(135.9,-131.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AA1BdIgChpIgZBpIgzAAIgZhpIgCBpIg8AAIALi5IBOAAIAXBkIAYhkIBOAAIALC5g");
	this.shape_1.setTransform(115.725,-131.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA1BdIgChpIgZBpIgzAAIgZhpIgCBpIg8AAIALi5IBOAAIAXBkIAYhkIBOAAIALC5g");
	this.shape_2.setTransform(91.575,-131.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAgBdIgHgaIg0AAIgHAaIg/AAIBAi5IBCAAIBCC5gAAMAUIgMgxIgOAxIAaAAg");
	this.shape_3.setTransform(69.95,-131.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag9BIQgegZAAgvQAAguAegaQAcgXAoAAQAhAAAXAOQAKAGANANIgpAhQgQgQgWAAQgQAAgKAMQgLANAAAUQAAAVALANQAKAMAQAAQAWAAAEgHIAAgNIgcAAIAAgsIBYAAIAABQQgSAPgNAHQgYAMggAAQgoAAgbgYg");
	this.shape_4.setTransform(50.2,-131.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAhBdIgIgaIg0AAIgHAaIhAAAIBBi5IBDAAIBBC5gAAMAUIgMgxIgPAxIAbAAg");
	this.shape_5.setTransform(25.6,-131.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag9BdIAAi5IA8AAIAACHIA/AAIAAAyg");
	this.shape_6.setTransform(9.55,-131.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(0,-145.7,145.7,30.999999999999986), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhCBdIAAi5ICDAAIAAAwIhHAAIAAAUIBDAAIAAAvIhDAAIAAAWIBKAAIAAAwg");
	this.shape.setTransform(139.65,-194.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_1.setTransform(123.525,-194.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdBdIhGi5IBBAAIAiBrIAjhrIBBAAIhGC5g");
	this.shape_2.setTransform(104.075,-194.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag/BJQgVgUAAgpIAAhqIA9AAIAABtQABAOAFAGQAIAHAJAAQALAAAHgHQAFgGABgOIAAhtIA9AAIAABqQAAApgUAUQgWAWgrAAQgqAAgVgWg");
	this.shape_3.setTransform(84.65,-194.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhHBHQgdgaAAgtQAAgsAdgaQAbgaAsAAQAsAAAcAaQAdAaAAAsQAAAtgdAaQgcAZgsABQgsgBgbgZgAgcgfQgLALAAATQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgTgLgLQgLgMgSgBQgRABgLAMg");
	this.shape_4.setTransform(64.325,-194.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag1BHQgdgaAAgtQAAgsAdgbQAcgYAqAAQApAAAVARIgRA0QgSgRgXAAQgSAAgLALQgNALAAAVQAAATAOAMQAKAKASAAQAcAAARgRIARAwQgYAYgqAAQgqAAgcgZg");
	this.shape_5.setTransform(45.9,-194.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhCB1IAAi6ICDAAIAAAwIhHAAIAAAVIBCAAIAAAvIhCAAIAAAVIBKAAIAAAxgAgehNIATgnIAvAAIgZAng");
	this.shape_6.setTransform(29.5,-197.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhXBdIAAi5IBGAAQAvAAAbAUQAfAYAAAwQAAAxgfAYQgbAUgvAAgAgaAqIAOAAQASAAAJgKQALgKAAgWQAAgWgLgLQgJgJgSAAIgOAAg");
	this.shape_7.setTransform(12.125,-194.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(0,-209,149.4,31), null);


(lib.tear = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset1tearDBL();
	this.instance.setTransform(0,60,0.5441,0.5441);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tear, new cjs.Rectangle(0,60,303.1,606.2), null);


(lib.skate3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset4();
	this.instance.setTransform(-6,17,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate3, new cjs.Rectangle(-6,17,133.1,133.1), null);


(lib.skate2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset3();
	this.instance.setTransform(-22,1,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate2, new cjs.Rectangle(-22,1,133.1,133.1), null);


(lib.skate1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset2pngcopy();
	this.instance.setTransform(-24,18);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate1, new cjs.Rectangle(-24,18,131,130), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AD6W3QgngnAAg6QAAg3AqgkQAngkA3AAQA2AAAoAkQApAkAAA3QAAA6gmAnQgmAmg7AAQg7AAgmgmgAEqUpQgVATAAAaQAAAfAVAVQAUAVAdgBQAdABAUgVQAUgVAAgfQAAgagUgTQgVgUgcAAQgcAAgVAUgAjrXVQgVgGgLgLIAAAAIAAhAIACADQAMANAVAKQAVAJARAAQARAAAHgGQAIgEAAgKQAAgKgJgGQgGgFgagKQhAgYAAg3QAAgiAYgWQAYgXAmABQAWgBASAHQATAGAKAHIAAABIAAA/IgCgCQgJgLgRgJQgTgIgOAAQgOAAgHAFQgHAGAAAJQAAAKAIAGQAGAGAXAIQAfAMATATQATAUAAAbQAAAjgZAXQgZAWgsAAQgaAAgUgHgAqHXAQgQgQgGgZQgEgQAAgeIAAiLIBAAAIAACCQAAAfAHAOQAKAWAbAAQAcAAAJgWQAHgOAAgfIAAiCIBAAAIAACLQAAAegEAQQgGAZgQAQQgcAbg2ABQg2gBgcgbgAM9XVIAAjAIg1AAIAAg3ICqAAIAAA3Ig1AAIAADAgAKYXVIg+hfIAABfIhAAAIAAj3IBkAAQAVAAAPAGQAPAGALAKQAJAKAGAPQAFANAAAQQAAAdgOARQgMARgcAHIBOBlgAJaVMIANAAQATABAKgJQAKgHAAgPQAAgPgKgIQgKgHgTgBIgNAAgAggXVIAAj3IBlAAQApAAAXAVQAWAWAAAoQAAAngWAWQgWAVgqAAIgmAAIAABSgAAfVPIAVAAQAkAAAAgeQAAgfgkAAIgVAAgAuxXVIAAj3IBbAAQA0AAAkAkQAlAkAAAzQAAA1glAjQgkAkg0AAgAtxWeIAOAAQAfAAATgQQAVgTAAgiQAAgggTgSQgTgTggABIgPAAgAQmUEQgHgHAAgKQAAgJAHgHQAHgGAJAAQAFAAAFACIAAANQgEgEgGAAQgFgBgDAEQgDAEAAAEQAAAFADAEQADADAFAAQAFABAFgFIAAANIgBAAIgJACQgJAAgHgGgAQPUJIgEgYIgKAYIgEAAIgKgYIgEAYIgLAAIAHgrIALAAIAJAXIAJgXIALAAIAHArgAWOO/QgwgSgmgkQhQhHAAh0QAAg0ATgvQATgvAjgkQAlglAygWQAygWA0ABQA4AAA+AZIAACbQgTgbgfgPQgegOghABQg7gBglAoQglAnAAA7QAAA8AlAlQAmAmA8AAQAfAAAegOQAdgOAVgZIAACbQgnANgTADQgdAHgbAAQg0AAgwgTgAlFOGQhNhMAAh2QAAhsBThKQBPhGBtAAQBtAABOBGQBTBKAABsQAAB2hNBMQhLBMh2AAQh2AAhMhMgAjlJqQgoAnAAAzQAAA+AoArQAoApA6AAQA5AAApgpQAngrAAg+QAAgzgngnQgqgng4AAQg4AAgqAngAsNPDQgpgNgVgUIgBgBIAAh/IAEAGQAXAaAqATQAqASAhAAQAfABASgLIgBAAQARgMAAgTQAAgUgSgLIAAAAQgQgLgwgSIABAAQiAgvAAhvQAAhDAwgsQAugsBNAAQAqAAAlALIAAABQAkAMAWAPIABACIAAB8IgFgEQgTgWgigQQgigRgeAAQgbAAgPALQgOALAAASQAAATAPANQAQANAqAPQA/AWAlAnQAmAnAAA2QAABGgxAuQgyArhYABQgygBgqgNgAFuPCQgugOgdgdQghgfgLgxQgIghAAg8IAAkTICAAAIAAECQAAA/AMAcQATAqA3AAQA3AAATgqQANgcAAg/IAAkCIB/AAIAAETQAAA9gHAgQgLAxghAfQgdAdguAOQgoAMgwAAQgvAAgogMgAbjPBIAAnqIEXAAIAABsIiXAAIAABSICPAAIAABsIiPAAIAABUICXAAIAABsgAQUPBIh5i9IgBAAIAAC9Ih/AAIAAnqIC+AAQBNAAAsAkQAxAnAABMQAAA1gbAlQgdAngzAKICaDIgAOaKzIAMAAQAnAAAVgKQAdgPAAglQAAgjgdgPQgVgLgnAAIgMAAgA0DPBIgfhVIiwAAIgiBVIiHAAIC9nqICLAAIC4HqgA2vMLIBqAAIg0idIgBAAgA/5PBIAAnqIB/AAIAAF+ICZAAIAABsgAlHgKQh4g6hfhiIAAjkQBsB0BtA8QCYBUC0AAQCcAABohxQBfhoAAiJQAAiIhhhqQhohwiXAAQgvAAgfgfQgegfAAgwQAAgtAiggQAhgdApAAIALAAQB3AABpAtQBqAtBPBVQBJBPApBlQAoBmAABqQAADpilClQilCljpAAQi9gBifhNgAgUl0Qh3gBhqgsQhpguhPhUQhKhPgohlQgohmAAhrQAAjpClilQClilDpAAQEWACDMChIAADeQhrhehzgsQhzgtiEAAQicAAhnByQhfBoAACIQAACIBhBpQBoByCXAAQAugBAfAgQAfAfAAAvQAAAsgjAgQghAfgoAAg");
	this.shape.setTransform(182.7365,186.3146,1.2343,1.2343);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(-69.3,1.1,504.1,370.4), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgQAQQgGgGAAgKQAAgIAGgGQAHgGAJABQALgBAFAGQAHAGAAAIQAAAKgHAGQgFAEgLAAQgJAAgHgEg");
	this.shape.setTransform(210.6,13.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgsAzQgOgPAAgcIAAhJIArAAIAABLQAAAKAEAEQAFAFAGAAQAIAAAEgFQAEgDAAgLIAAhLIArAAIAABJQAAAcgOAPQgPAPgeAAQgdAAgPgPg");
	this.shape_1.setTransform(200.825,9.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBbAAIAAAiIgwAAIAAANIAuAAIAAAhIguAAIAAAPIAyAAIAAAig");
	this.shape_2.setTransform(188.8,9.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AASBBIgnhIIABAXIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_3.setTransform(166.125,9.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgxAxQgVgSABgfQgBgeAVgTQATgRAeAAQAfAAATARQAUATAAAeQAAAfgUASQgTASgfAAQgeAAgTgSgAgUgWQgHAIAAAOQAAAMAHAJQAJAIALAAQANAAAHgIQAIgIgBgNQABgOgIgIQgHgIgNAAQgLAAgJAIg");
	this.shape_4.setTransform(151.55,9.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgUBBIAAhgIgfAAIAAghIBnAAIAAAhIgfAAIAABgg");
	this.shape_5.setTransform(139.75,9.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBcAAIAAAiIgyAAIAAANIAuAAIAAAhIguAAIAAAPIAzAAIAAAig");
	this.shape_6.setTransform(125.65,9.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag0AxIATgfQAIAGAMAEQAJAEAFgBQAJABAAgGQAAgDgJgEIgSgGQgMgFgGgFQgMgJAAgRQAAgTAPgMQAOgMAYAAQAbAAATAQIgQAeQgHgGgKgEQgIgDgGAAQgKAAAAAGQAAADAIADIAQAFQAOAFAIAGQAMAJAAARQAAAWgRANQgPALgXAAQgaAAgYgSg");
	this.shape_7.setTransform(114.575,9.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUBBIAAiBIApAAIAACBg");
	this.shape_8.setTransform(106.275,9.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgqBBIAAiBIAqAAIAABeIArAAIAAAjg");
	this.shape_9.setTransform(98.725,9.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAXBBIgFgTIgkAAIgFATIgtAAIAuiBIAuAAIAtCBgAAJAOIgJgiIgJAiIASAAg");
	this.shape_10.setTransform(86.725,9.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AASBBIgnhIIABAXIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_11.setTransform(72.925,9.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AASBBIgnhIIABAXIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_12.setTransform(58.625,9.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgyAxQgTgSgBgfQABgeATgTQAUgRAeAAQAfAAAUARQATATABAeQgBAfgTASQgUASgfAAQgeAAgUgSgAgTgWQgIAIAAAOQAAAMAIAJQAIAIALAAQAMAAAIgIQAHgIAAgNQAAgOgHgIQgIgIgMAAQgLAAgIAIg");
	this.shape_13.setTransform(44.05,9.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag0AxIATgfQAIAGAMAEQAJAEAFgBQAJABAAgGQAAgDgJgEIgSgGQgMgFgGgFQgMgJAAgRQAAgTAPgMQAOgMAYAAQAbAAATAQIgQAeQgHgGgKgEQgIgDgGAAQgKAAAAAGQAAADAIADIAQAFQAOAFAIAGQAMAJAAARQAAAWgRANQgPALgXAAQgaAAgYgSg");
	this.shape_14.setTransform(31.175,9.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAKBBIgUgrIgFAAIAAArIgrAAIAAiBIA5AAQAXAAANAJQAQAMAAAVQAAAYgVAOIAdAxgAgPgKIAKAAQAGAAADgBQAFgEAAgFQAAgGgFgDQgDgDgGAAIgKAAg");
	this.shape_15.setTransform(20.325,9.15);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBcAAIAAAiIgyAAIAAANIAuAAIAAAhIguAAIAAAPIAzAAIAAAig");
	this.shape_16.setTransform(8.2,9.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag1BBIAAiBIA4AAQAXAAANAKQAPAMAAAXQAAAVgPAMQgNALgXAAIgNAAIAAAogAgKgHIAHAAQAGAAADgCQAFgDAAgHQAAgHgFgDQgDgDgGAAIgHAAg");
	this.shape_17.setTransform(-2.875,9.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AASBBIgnhIIABAXIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_18.setTransform(-19.975,9.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgyAxQgTgSAAgfQAAgeATgTQAUgRAeAAQAfAAATARQAVATgBAeQABAfgVASQgTASgfAAQgeAAgUgSgAgUgWQgHAIAAAOQAAAMAHAJQAJAIALAAQANAAAHgIQAIgIAAgNQAAgOgIgIQgHgIgNAAQgLAAgJAIg");
	this.shape_19.setTransform(-34.55,9.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AiwBBQgIgBgCgBIACgfQAGADAEAAQABAAABAAQABAAAAAAQABgBAAAAQABAAAAAAQACgCAAgFIAAhcIArAAIAABcQAAAUgJAKQgJAJgTAAIgPgBgACtguQgDgDAAgFQAAgFADgDQADgDAFAAIAGABIAAAGQgDgCgCAAQgGAAAAAGQAAAAAAABQAAABAAAAQABABAAAAQAAABABAAQAAABAAAAQABAAAAAAQABABAAAAQABAAABAAQACAAADgDIAAAHIgBAAIgFABQgFAAgDgDgACigrIgCgNIgGANIgBAAIgFgNIgCANIgGAAIAFgWIAEAAIAFAMIAEgMIAGAAIADAWg");
	this.shape_20.setTransform(195.15,9.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(-44.2,-1.6,260.6,23.3), null);


(lib.Ctext4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAOQgGgEAAgKQAAgIAGgGQAGgEAJgBQAKABAGAEQAGAGAAAIQAAAKgGAEQgGAGgKAAQgJAAgGgGg");
	this.shape.setTransform(132.65,-31.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgdBdIAAiKIgsAAIAAgvICTAAIAAAvIgrAAIAACKg");
	this.shape_1.setTransform(124.775,-38.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_2.setTransform(109.325,-38.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhHBHQgdgaAAgtQAAgsAdgaQAbgaAsAAQAsAAAcAaQAdAaAAAsQAAAtgdAaQgcAZgsAAQgsAAgbgZgAgcggQgLAMAAAUQAAASALAMQALAMARAAQASAAALgMQALgMAAgSQAAgUgLgMQgLgMgSABQgRgBgLAMg");
	this.shape_3.setTransform(88.925,-38.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgQgKIALAAQAJAAAEgDQAIgFgBgKQABgKgIgFQgEgDgJAAIgLAAg");
	this.shape_4.setTransform(70.45,-38.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhKBHIAbguQALAKARAFQANAFAHAAQAOAAAAgIQAAgFgOgFIgagIQgSgHgHgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgWArQgKgJgPgFQgMgEgIAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPAAAZQABAegYATQgWAQggAAQgnAAghgZg");
	this.shape_5.setTransform(53.6,-38.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag/BJQgVgUAAgpIAAhqIA9AAIAABtQABAOAFAGQAIAHAJAAQALAAAGgHQAGgGABgOIAAhtIA9AAIAABqQAAApgUAUQgWAWgrAAQgqAAgVgWg");
	this.shape_6.setTransform(31.1,-38.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhXBdIAAi5IBGAAQAvAAAbAUQAfAYAAAwQAAAxgfAYQgbAUgvAAgAgaAqIAOAAQASAAAJgKQALgKAAgWQAAgWgLgLQgJgJgSAAIgOAAg");
	this.shape_7.setTransform(12.125,-38.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext4, new cjs.Rectangle(0,-53.2,138,31.000000000000004), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgXAWQgJgIAAgOQAAgNAJgIQAJgHAOAAQAPAAAJAHQAJAIAAANQAAAOgJAIQgJAHgPAAQgOAAgJgHg");
	this.shape.setTransform(178.95,-158.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhKBHIAbguQALAKARAFQANAFAHAAQAOAAAAgIQAAgFgOgFIgagIQgSgHgHgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgWArQgKgJgPgFQgLgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPAAAZQAAAegXATQgWAQggAAQgnAAghgZg");
	this.shape_1.setTransform(166.45,-165.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdBdIAAiKIgsAAIAAgvICTAAIAAAvIgrAAIAACKg");
	this.shape_2.setTransform(151.875,-165.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBJAAIAAAwg");
	this.shape_3.setTransform(136.9,-165.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag9BIQgegaAAguQAAguAegaQAcgXApAAQAgAAAYAOQAJAFAMANIgoAiQgQgQgVAAQgRAAgKAMQgMAMAAAVQAAAWAMAMQAKAMARAAQAVAAAEgHIAAgOIgdAAIAAgsIBYAAIAABRQgRAQgMAGQgZAMggAAQgoAAgbgYg");
	this.shape_4.setTransform(118.65,-165.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhXBdIAAi5IBGAAQAvAAAbAUQAfAYAAAwQAAAxgfAYQgbAUgvAAgAgaAqIAOAAQASAAAJgKQALgKAAgWQAAgWgLgLQgJgJgSAAIgOAAg");
	this.shape_5.setTransform(99.575,-165.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhABJQgUgUAAgpIAAhqIA+AAIAABtQgBAOAHAGQAGAHAKAAQALAAAHgHQAFgGAAgOIAAhtIA+AAIAABqQAAApgUAUQgWAWgrAAQgpAAgXgWg");
	this.shape_6.setTransform(79.75,-165.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhPBdIAAi5IBMAAQAeAAAQAHQAMAEAHAKQAJALAAAPQAAAPgIAMQgIAKgKAFQAQADAKAMQAKALgBAQQAAAcgUAOQgTAMgdAAgAgTAwIAUAAQAHAAAGgDQAGgEAAgIQAAgIgGgDQgFgEgIAAIgUAAgAgTgVIANAAQAHAAAFgDQAFgEABgHQgBgHgFgDQgEgDgIAAIgNAAg");
	this.shape_7.setTransform(61.65,-165.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhKBHIAbguQALAKARAFQANAFAHAAQAOAAAAgIQAAgFgOgFIgagIQgSgHgHgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgWArQgKgJgPgFQgMgEgIAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPAAAZQABAegYATQgWAQggAAQgnAAghgZg");
	this.shape_8.setTransform(39.2,-165.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhCBdIAAi5ICDAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBKAAIAAAwg");
	this.shape_9.setTransform(24.1,-165.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag9BdIAAi5IA8AAIAACHIA/AAIAAAyg");
	this.shape_10.setTransform(9.55,-165.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(0,-179.7,185.9,31), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhKBHIAbguQALAKARAFQANAFAHAAQAOAAAAgIQAAgFgOgFIgagIQgSgHgHgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgWArQgKgJgPgFQgMgEgIAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPAAAZQABAegYATQgWAQggAAQgnAAghgZg");
	this.shape.setTransform(144.5,-190.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhABJQgUgUAAgpIAAhqIA+AAIAABtQAAAOAFAGQAIAHAJAAQALAAAGgHQAHgGgBgOIAAhtIA+AAIAABqQAAApgUAUQgWAWgrAAQgpAAgXgWg");
	this.shape_1.setTransform(127.25,-190.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhHBHQgdgbAAgsQAAgrAdgbQAbgaAsABQAsgBAcAaQAdAbAAArQAAAsgdAbQgcAZgsAAQgsAAgbgZgAgcggQgLANAAASQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgSgLgNQgLgLgSAAQgRAAgLALg");
	this.shape_2.setTransform(106.925,-190.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgdBdIAAiKIgsAAIAAgvICTAAIAAAvIgrAAIAACKg");
	this.shape_3.setTransform(90.025,-190.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_4.setTransform(69.325,-190.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhABJQgUgUAAgpIAAhqIA+AAIAABtQAAAOAFAGQAIAHAJAAQALAAAGgHQAHgGAAgOIAAhtIA9AAIAABqQAAApgUAUQgWAWgrAAQgpAAgXgWg");
	this.shape_5.setTransform(49.85,-190.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhHBHQgdgbAAgsQAAgrAdgbQAbgaAsABQAsgBAcAaQAdAbAAArQAAAsgdAbQgcAZgsAAQgsAAgbgZgAgcggQgLANAAASQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgSgLgNQgLgLgSAAQgRAAgLALg");
	this.shape_6.setTransform(29.525,-190.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgQgKIALAAQAJAAAEgDQAIgFgBgKQABgKgIgFQgEgDgJAAIgLAAg");
	this.shape_7.setTransform(11.05,-190.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(0,-205,154.5,31), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Isolation_Mode
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#221F20").s().p("AgOAtIAAhCIgVAAIAAgXIBHAAIAAAXIgVAAIAABCg");
	this.shape.setTransform(148.525,-13.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#221F20").s().p("AANAtIgbgxIABAPIAAAiIgdAAIAAhZIAgAAIAZAxIgBgPIAAgiIAdAAIAABZg");
	this.shape_1.setTransform(139.95,-13.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#221F20").s().p("AAQAtIgDgNIgZAAIgEANIgfAAIAfhZIAgAAIAgBZgAAGAKIgGgYIgGAYIAMAAg");
	this.shape_2.setTransform(130.3,-13.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#221F20").s().p("AAMAtIgagxIABAPIAAAiIgdAAIAAhZIAgAAIAZAxIgBgPIAAgiIAdAAIAABZg");
	this.shape_3.setTransform(120.7,-13.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#221F20").s().p("AggAtIAAhZIA/AAIAAAXIgiAAIAAAKIAhAAIAAAWIghAAIAAALIAkAAIAAAXg");
	this.shape_4.setTransform(112.05,-13.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#221F20").s().p("AgOAtIAAhCIgVAAIAAgXIBHAAIAAAXIgVAAIAABCg");
	this.shape_5.setTransform(104.525,-13.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#221F20").s().p("AAMAtIgagxIABAPIAAAiIgdAAIAAhZIAgAAIAZAxIgBgPIAAgiIAdAAIAABZg");
	this.shape_6.setTransform(95.95,-13.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#221F20").s().p("AgOAtIAAhZIAdAAIAABZg");
	this.shape_7.setTransform(88.85,-13.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#221F20").s().p("AAQAtIgDgNIgZAAIgEANIgfAAIAfhZIAgAAIAgBZgAAGAKIgGgYIgGAYIAMAAg");
	this.shape_8.setTransform(82.05,-13.825);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#221F20").s().p("AAaAtIgBgzIgMAzIgZAAIgMgzIgBAzIgdAAIAFhZIAnAAIAKAwIAMgwIAmAAIAFBZg");
	this.shape_9.setTransform(71.525,-13.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#221F20").s().p("AAHAtIgOgeIgDAAIAAAeIgeAAIAAhZIAnAAQAQAAAKAGQALAIAAAOQAAASgPAJIAUAigAgLgGIAIAAQADAAADgCQADgCAAgEQAAgEgDgCQgDgCgDAAIgIAAg");
	this.shape_10.setTransform(59.2,-13.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#221F20").s().p("AggAtIAAhZIA/AAIAAAXIghAAIAAAKIAfAAIAAAWIgfAAIAAALIAjAAIAAAXg");
	this.shape_11.setTransform(50.8,-13.825);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#221F20").s().p("AgOAtIAAhCIgVAAIAAgXIBHAAIAAAXIgVAAIAABCg");
	this.shape_12.setTransform(43.275,-13.825);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#221F20").s().p("AggAtIAAhZIA/AAIAAAXIgiAAIAAAKIAhAAIAAAWIghAAIAAALIAkAAIAAAXg");
	this.shape_13.setTransform(36,-13.825);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#221F20").s().p("AAMAtIAAghIgXAAIAAAhIgeAAIAAhZIAeAAIAAAgIAXAAIAAggIAeAAIAABZg");
	this.shape_14.setTransform(27.2,-13.825);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#221F20").s().p("AgZAjQgPgNAAgWQAAgVAPgNQANgMAVAAQATAAAKAJIgIAZQgIgIgMAAQgIAAgGAFQgFAGAAAJQgBAKAHAFQAEAFAJAAQANAAAJgIIAIAXQgLAMgUAAQgVAAgNgMg");
	this.shape_15.setTransform(18.3,-13.825);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#221F20").s().p("AAQAtIgDgNIgZAAIgEANIgfAAIAfhZIAhAAIAfBZgAAGAKIgGgYIgGAYIAMAAg");
	this.shape_16.setTransform(9.6,-13.825);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("ArxCCQgRAAgLgMQgMgMAAgRIAAiyQAAgQAMgMQALgMARAAIXjAAQAQAAANAMQALAMAAAQIAACyQAAARgLAMQgNAMgQAAg");
	this.shape_17.setTransform(79.4,-14.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(0,-27,158.8,26), null);


(lib.Btext22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhCBdIAAi5ICDAAIAAAwIhHAAIAAAUIBDAAIAAAvIhDAAIAAAWIBKAAIAAAwg");
	this.shape.setTransform(93.3,-214.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAaBdIg4hnIACAhIAABGIg8AAIAAi5IBCAAIA1BnIgBghIAAhGIA7AAIAAC5g");
	this.shape_1.setTransform(74.95,-214.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhABJQgUgUAAgpIAAhqIA9AAIAABtQAAAOAHAGQAGAHAKAAQALAAAHgHQAFgGAAgOIAAhtIA+AAIAABqQAAApgUAUQgWAWgrAAQgpAAgXgWg");
	this.shape_2.setTransform(55,-214.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgYAaIAQgzIAhAAIgUAzg");
	this.shape_3.setTransform(37.025,-205.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhXBdIAAi5IBGAAQAvAAAbAUQAfAYAAAwQAAAxgfAYQgbAUgvAAgAgaAqIAOAAQASAAAJgKQALgKAAgWQAAgWgLgLQgJgJgSAAIgOAAg");
	this.shape_4.setTransform(26.225,-214.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBKAAIAAAwg");
	this.shape_5.setTransform(8.55,-214.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBJAAIAAAwg");
	this.shape_6.setTransform(-7.1,-214.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgQgKIAKAAQAKAAAFgDQAGgFABgKQgBgKgGgFQgFgDgKAAIgKAAg");
	this.shape_7.setTransform(-23,-214.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhLBHIAbguQAMAKAQAFQAOAFAHAAQAOAAAAgIQAAgFgNgFIgagIQgSgHgIgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgXArQgJgJgOgFQgMgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPAAAZQAAAegYATQgUAQgiAAQgmAAgigZg");
	this.shape_8.setTransform(-39.85,-214.825);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgdBdIAAiKIgsAAIAAgvICTAAIAAAvIgrAAIAACKg");
	this.shape_9.setTransform(-54.425,-214.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhCBdIAAi5ICDAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBKAAIAAAwg");
	this.shape_10.setTransform(-69.4,-214.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgeBeQgLgBgDgDIADgsQAIAEAHAAQAFAAABgCQADgDAAgHIAAiFIA9AAIAACFQABAegOAPQgNANgaAAQgMAAgKgCg");
	this.shape_11.setTransform(-83,-214.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-229.2,193.1,31);


(lib.Btext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AA1BdIgChpIgZBpIgzAAIgZhpIgCBpIg8AAIALi5IBOAAIAXBkIAYhkIBOAAIALC5g");
	this.shape.setTransform(185.025,-221.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag1BHQgdgaAAgtQAAgsAdgbQAcgYAqAAQApAAAVARIgRA0QgSgRgXAAQgSAAgLALQgNALAAAVQAAATAOAMQAKAKASAAQAcAAARgRIARAwQgYAYgqAAQgqAAgcgZg");
	this.shape_1.setTransform(164.7,-221.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag1BHQgdgaAAgtQAAgsAdgbQAcgYAqAAQAqAAAUARIgRA0QgSgRgXAAQgTAAgKALQgNALAAAVQAAATANAMQALAKASAAQAcAAAQgRIASAwQgXAYgrAAQgqAAgcgZg");
	this.shape_2.setTransform(148.1,-221.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhLBHIAbguQAMAKAQAFQAOAFAHAAQAOAAAAgIQAAgFgNgFIgagIQgSgHgIgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgXArQgJgJgOgFQgMgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPAAAZQAAAegYATQgUAQgiAAQgmAAgigZg");
	this.shape_3.setTransform(126.2,-221.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAaBdIg4hnIACAhIAABGIg8AAIAAi5IBCAAIA1BnIgBghIAAhGIA7AAIAAC5g");
	this.shape_4.setTransform(108.4,-221.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdBdIAAi5IA8AAIAAC5g");
	this.shape_5.setTransform(93.75,-221.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgdBdIAAiKIgsAAIAAgvICTAAIAAAvIgrAAIAACKg");
	this.shape_6.setTransform(81.925,-221.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAhBdIgIgaIg0AAIgHAaIhAAAIBBi5IBCAAIBBC5gAAMAUIgNgxIgNAxIAaAAg");
	this.shape_7.setTransform(67.4,-221.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgQgKIAKAAQAKAAAFgDQAHgFAAgKQAAgKgHgFQgFgDgKAAIgKAAg");
	this.shape_8.setTransform(51.35,-221.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhCBdIAAi5ICDAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBKAAIAAAwg");
	this.shape_9.setTransform(29.5,-221.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhXBdIAAi5IBGAAQAvAAAbAUQAfAYAAAwQAAAxgfAYQgbAUgvAAgAgaAqIAOAAQASAAAJgKQALgKAAgWQAAgWgLgLQgJgJgSAAIgOAAg");
	this.shape_10.setTransform(12.125,-221.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btext1, new cjs.Rectangle(0,-235.5,199.3,31), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-111.8,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-281.5,145.7,31);


// stage content:
(lib.jetfam_300x600_fr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(132,467.2,1,1,0,0,0,62,18);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(309).to({_off:false},0).to({alpha:1},22,cjs.Ease.cubicInOut).wait(12));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(-130.95,369.5,1,1,0,0,0,84.2,10.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(292).to({_off:false},0).to({x:149.05},20,cjs.Ease.quartOut).wait(31));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(148.25,267.4,0.4,0.4,0,0,0,177.5,184.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(268).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(46));

	// skate3
	this.instance_3 = new lib.skate3();
	this.instance_3.setTransform(-57,502.5,1,1,0,0,0,57,61.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({x:98},20,cjs.Ease.quartOut).wait(187).to({x:-64.5},18,cjs.Ease.quintInOut).wait(70));

	// skate2
	this.instance_4 = new lib.skate2();
	this.instance_4.setTransform(358.5,445,1,1,0,0,0,57,62);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({_off:false},0).to({x:221},20,cjs.Ease.quartOut).wait(190).to({x:383.5},18,cjs.Ease.quintInOut).wait(71));

	// skate1
	this.instance_5 = new lib.skate1();
	this.instance_5.setTransform(-58,368.5,1,1,0,0,0,56,61.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(40).to({_off:false},0).to({x:97},20,cjs.Ease.quartOut).wait(193).to({x:-59.25},18,cjs.Ease.quintInOut).wait(72));

	// cta
	this.instance_6 = new lib.CTA();
	this.instance_6.setTransform(84.45,275.9,1,1,0,0,0,62,18);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(145).to({y:157.15},23,cjs.Ease.quartInOut).wait(81).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(76));

	// Ctext4
	this.instance_7 = new lib.Ctext4();
	this.instance_7.setTransform(-155.2,252.6,1,1,0,0,0,74.8,24);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(25).to({_off:false},0).to({x:94.8},22,cjs.Ease.quartOut).wait(93).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(185));

	// Ctet2
	this.instance_8 = new lib.Ctext2();
	this.instance_8.setTransform(-105.2,252.6,1,1,0,0,0,74.8,24);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(154).to({_off:false},0).to({x:94.8},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_9 = new lib.Ctext1();
	this.instance_9.setTransform(-92.7,252.6,1,1,0,0,0,74.8,24);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(151).to({_off:false},0).to({x:94.8},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// Btext6
	this.instance_10 = new lib.text6();
	this.instance_10.setTransform(-159.95,327.2);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(22).to({_off:false},0).to({x:110.05},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(189));

	// Btext2_copy
	this.instance_11 = new lib.text3();
	this.instance_11.setTransform(-159.95,327.2);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(19).to({_off:false},0).to({x:110.05},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(192));

	// Btext2
	this.instance_12 = new lib.Btext22();
	this.instance_12.setTransform(-139.55,327.2);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(17).to({_off:false},0).to({x:110.05},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(194));

	// Btext1
	this.instance_13 = new lib.Btext1();
	this.instance_13.setTransform(-132,333,1,1,0,0,0,74.8,24);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(13).to({_off:false},0).to({x:94.8,y:331.8},22,cjs.Ease.quartOut).wait(93).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(197));

	// text2
	this.instance_14 = new lib.Tween2("synched",0);
	this.instance_14.setTransform(-141.95,327.2);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(9).to({_off:false},0).to({x:110.05},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_15 = new lib.text1();
	this.instance_15.setTransform(-184.8,252.6,1,1,0,0,0,74.8,24);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(5).to({_off:false},0).to({x:94.8},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// rip
	this.instance_16 = new lib.tear();
	this.instance_16.setTransform(150.6,299,1,1,0,0,0,151.6,302);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(256).to({y:667.75,alpha:0},22,cjs.Ease.quartInOut).wait(65));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-109.6,300,547.2,731.9000000000001);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/jetfam_300x600_fr_atlas_P_1.png", id:"jetfam_300x600_fr_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;