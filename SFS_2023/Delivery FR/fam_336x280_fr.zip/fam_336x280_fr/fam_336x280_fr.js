(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"fam_336x280_fr_atlas_P_1", frames: [[0,0,558,1110],[560,251,112,123],[560,0,114,124],[560,126,114,123]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset1 = function() {
	this.initialize(ss["fam_336x280_fr_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset2pngcopy = function() {
	this.initialize(ss["fam_336x280_fr_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Asset3 = function() {
	this.initialize(ss["fam_336x280_fr_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Asset4 = function() {
	this.initialize(ss["fam_336x280_fr_atlas_P_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAoIg6AAIAAAQIA3AAIAAAmIg3AAIAAARIA8AAIAAAog");
	this.shape.setTransform(56.75,-198.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgrA6QgXgVgBglQABgkAXgVQAWgUAjAAQAiAAARAOIgOAqQgPgNgTAAQgPAAgIAIQgLAKABAQQAAAQAKAJQAIAJAPAAQAXAAAOgOIANAnQgTATgiAAQgjAAgWgUg");
	this.shape_1.setTransform(43.4,-198.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAMBMIgYgyIgGAAIAAAyIgyAAIAAiXIBCAAQAcAAAPALQATANAAAZQAAAdgZAPIAiA6gAgSgLIAMAAQAHAAADgDQAGgEAAgGQAAgHgGgEQgDgCgHAAIgMAAg");
	this.shape_2.setTransform(29.675,-198.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag0A7QgQgQAAghIAAhWIAyAAIAABYQAAAMAFAFQAFAFAIAAQAJAAAFgFQAFgFAAgMIAAhYIAyAAIAABWQAAAhgQAQQgSASgjAAQgiAAgSgSg");
	this.shape_3.setTransform(13.825,-198.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag6A6QgYgWABgkQgBgjAYgVQAXgWAjAAQAkAAAXAWQAYAVgBAjQABAkgYAWQgXAUgkABQgjgBgXgUgAgXgaQgJALAAAPQAAAPAJAKQAJAKAOAAQAPAAAJgKQAIgKAAgPQAAgPgIgLQgJgJgPAAQgOAAgJAJg");
	this.shape_4.setTransform(-2.75,-198.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag8A6IAVglQAKAHAOAFQALAEAFAAQALAAAAgGQAAgFgLgEIgVgHQgOgFgHgGQgNgLAAgUQAAgWARgPQAQgNAbAAQAhAAAWATIgTAjQgIgIgMgDQgJgEgHAAQgMAAAAAGQAAAEAKAEIASAFQARAFAIAIQAPALAAAUQgBAYgTAQQgRANgbAAQgfAAgbgUg");
	this.shape_5.setTransform(-17.8,-198.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAaBMIgGgWIgqAAIgGAWIgzAAIA0iXIA2AAIA1CXgAAKARIgKgoIgMAoIAWAAg");
	this.shape_6.setTransform(-35.975,-198.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgxBMIAAiXIAxAAIAABvIAyAAIAAAog");
	this.shape_7.setTransform(-49.05,-198.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAoIg6AAIAAAQIA2AAIAAAmIg2AAIAAARIA8AAIAAAog");
	this.shape_8.setTransform(-65.6,-198.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhHBMIAAiXIA6AAQAlAAAWAQQAZAUAAAnQAAAogZAUQgWAQglAAgAgVAiIALAAQAPAAAIgHQAIgJABgSQgBgSgIgIQgIgIgPAAIgLAAg");
	this.shape_9.setTransform(-79.75,-198.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-210.9,155.1,26);


(lib.text3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag2BfIAAiXIBrAAIAAAoIg6AAIAAAQIA2AAIAAAmIg2AAIAAASIA8AAIAAAngAgZg+IAQggIAmAAIgUAgg");
	this.shape.setTransform(41.7,-220.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYBMIAAhwIgjAAIAAgnIB3AAIAAAnIgjAAIAABwg");
	this.shape_1.setTransform(29.05,-218.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgYBMIAAiXIAxAAIAACXg");
	this.shape_2.setTransform(19.425,-218.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXBMIg5iXIA0AAIAcBXIAdhXIA0AAIg5CXg");
	this.shape_3.setTransform(7.975,-218.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgYBMIAAiXIAxAAIAACXg");
	this.shape_4.setTransform(-3.525,-218.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag9A6IAXglQAJAHANAFQALAEAGAAQALAAAAgGQAAgFgLgDIgVgIQgOgFgHgFQgOgMABgUQAAgWARgPQAQgNAcAAQAgAAAWATIgTAjQgIgHgLgFQgKgDgHAAQgMAAAAAGQAAAEAKADIASAGQARAGAIAGQAOAMABAUQAAAZgUAPQgRANgbAAQgfAAgcgUg");
	this.shape_5.setTransform(-13.45,-218.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag0A7QgQgQAAghIAAhWIAyAAIAABYQAAAMAFAFQAFAFAIAAQAJAAAFgFQAFgFAAgMIAAhYIAyAAIAABWQAAAhgQAQQgSASgjAAQgiAAgSgSg");
	this.shape_6.setTransform(-27.475,-218.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgyBMIAAiXIAyAAIAABvIAyAAIAAAog");
	this.shape_7.setTransform(-40.2,-218.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgrA6QgYgVAAglQAAgkAYgVQAXgUAiAAQAiAAARAOIgOAqQgPgNgTAAQgPAAgIAIQgKAKAAAQQgBAQALAJQAJAJAOAAQAXAAANgOIAOAnQgSATgjAAQgiAAgXgUg");
	this.shape_8.setTransform(-53.1,-218.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAYBMIgYgwIgXAwIg8AAIAzhOIgwhJIA7AAIAVApIAVgpIA8AAIgwBJIAzBOg");
	this.shape_9.setTransform(-67.325,-218.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAoIg6AAIAAAQIA3AAIAAAmIg3AAIAAASIA8AAIAAAng");
	this.shape_10.setTransform(-81.4,-218.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-230.9,140.1,26);


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAoIg6AAIAAAQIA3AAIAAAmIg3AAIAAASIA8AAIAAAng");
	this.shape.setTransform(112.55,-156.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhGBMIAAiXIA4AAQAnAAAVAQQAZAUABAnQgBAogZATQgVARgnAAgAgVAiIAMAAQAOAAAHgHQAKgKgBgRQABgSgKgIQgHgIgOAAIgMAAg");
	this.shape_1.setTransform(98.4,-156.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAoIg6AAIAAAQIA2AAIAAAmIg2AAIAAASIA8AAIAAAng");
	this.shape_2.setTransform(79.75,-156.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AArBMIgChWIgTBWIgqAAIgUhWIgCBWIgxAAIAJiXIBAAAIASBRIAThRIBAAAIAJCXg");
	this.shape_3.setTransform(63.325,-156.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AArBMIgChWIgTBWIgqAAIgUhWIgCBWIgxAAIAJiXIBAAAIASBRIAThRIBAAAIAJCXg");
	this.shape_4.setTransform(43.675,-156.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAaBMIgGgVIgqAAIgGAVIgzAAIA0iXIA2AAIA1CXgAAKAQIgKgnIgMAnIAWAAg");
	this.shape_5.setTransform(26.075,-156.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgxA7QgZgVAAgmQAAglAZgVQAWgTAhAAQAbAAATALQAHAFALAKIghAcQgNgOgSAAQgNAAgIAKQgJAKAAARQAAARAJALQAIAJANAAQASAAADgFIAAgLIgXAAIAAgkIBHAAIAABBQgOANgKAFQgTAKgbAAQggAAgWgTg");
	this.shape_6.setTransform(9.975,-156.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(0,-168.5,125.2,26), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAaBMIgGgWIgqAAIgGAWIgzAAIA0iXIA2AAIA1CXgAAKARIgKgoIgMAoIAWAAg");
	this.shape.setTransform(143.725,-203);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgxBMIAAiXIAxAAIAABvIAzAAIAAAog");
	this.shape_1.setTransform(130.65,-203);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAoIg5AAIAAAQIA2AAIAAAmIg2AAIAAARIA7AAIAAAog");
	this.shape_2.setTransform(114.1,-203);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAMBMIgYgyIgGAAIAAAyIgyAAIAAiXIBCAAQAcAAAPALQATANAAAZQAAAdgZAPIAiA6gAgSgLIAMAAQAHAAADgDQAGgEAAgGQAAgHgGgEQgDgCgHAAIgMAAg");
	this.shape_3.setTransform(100.975,-203);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgXBMIg5iXIA0AAIAcBXIAdhXIA0AAIg5CXg");
	this.shape_4.setTransform(85.125,-203);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag0A7QgQgQAAghIAAhWIAyAAIAABYQAAAMAFAFQAFAFAIAAQAJAAAFgFQAFgFAAgMIAAhYIAyAAIAABWQAAAhgQAQQgSASgjAAQgiAAgSgSg");
	this.shape_5.setTransform(69.325,-202.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag6A6QgYgWAAgkQAAgjAYgVQAWgWAkAAQAkAAAXAWQAXAVABAjQgBAkgXAWQgXAUgkABQgkgBgWgUgAgXgaQgIALgBAPQABAPAIAKQAJAKAOAAQAPAAAIgKQAJgKAAgPQAAgPgJgLQgIgJgPAAQgOAAgJAJg");
	this.shape_6.setTransform(52.75,-203);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgrA6QgYgVAAglQAAgkAYgVQAWgUAjAAQAiAAAQAOIgNAqQgPgNgTAAQgPAAgJAIQgKAKAAAQQAAAQALAJQAIAJAPAAQAXAAAOgOIANAnQgSATgjAAQgjAAgWgUg");
	this.shape_7.setTransform(37.75,-202.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag2BfIAAiXIBrAAIAAAoIg5AAIAAAQIA1AAIAAAmIg1AAIAAARIA7AAIAAAogAgYg+IAPggIAnAAIgVAgg");
	this.shape_8.setTransform(24.4,-204.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhHBMIAAiXIA6AAQAlAAAWAQQAZAUAAAnQAAAogZAUQgWAQglAAgAgVAiIALAAQAPAAAIgHQAIgJABgSQgBgSgIgIQgIgIgPAAIgLAAg");
	this.shape_9.setTransform(10.25,-203);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(0,-215,153.7,26), null);


(lib.skate3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset4();
	this.instance.setTransform(186,-276,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate3, new cjs.Rectangle(186,-276,62.69999999999999,67.69999999999999), null);


(lib.skate2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset3();
	this.instance.setTransform(62,-294,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate2, new cjs.Rectangle(62,-294,62.7,68.19999999999999), null);


(lib.skate1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset2pngcopy();
	this.instance.setTransform(187,-290,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate1, new cjs.Rectangle(187,-290,61.599999999999994,67.69999999999999), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AD6W3QgngnAAg6QAAg3AqgkQAngkA3AAQA2AAAoAkQApAkAAA3QAAA6gmAnQgmAmg7AAQg7AAgmgmgAEqUpQgVATAAAaQAAAfAVAVQAUAVAdgBQAdABAUgVQAUgVAAgfQAAgagUgTQgVgUgcAAQgcAAgVAUgAjrXVQgVgGgLgLIAAAAIAAhAIACADQAMANAVAKQAVAJARAAQARAAAHgGQAIgEAAgKQAAgKgJgGQgGgFgagKQhAgYAAg3QAAgiAYgWQAYgXAmABQAWgBASAHQATAGAKAHIAAABIAAA/IgCgCQgJgLgRgJQgTgIgOAAQgOAAgHAFQgHAGAAAJQAAAKAIAGQAGAGAXAIQAfAMATATQATAUAAAbQAAAjgZAXQgZAWgsAAQgaAAgUgHgAqHXAQgQgQgGgZQgEgQAAgeIAAiLIBAAAIAACCQAAAfAHAOQAKAWAbAAQAcAAAJgWQAHgOAAgfIAAiCIBAAAIAACLQAAAegEAQQgGAZgQAQQgcAbg2ABQg2gBgcgbgAM9XVIAAjAIg1AAIAAg3ICqAAIAAA3Ig1AAIAADAgAKYXVIg+hfIAABfIhAAAIAAj3IBkAAQAVAAAPAGQAPAGALAKQAJAKAGAPQAFANAAAQQAAAdgOARQgMARgcAHIBOBlgAJaVMIANAAQATABAKgJQAKgHAAgPQAAgPgKgIQgKgHgTgBIgNAAgAggXVIAAj3IBlAAQApAAAXAVQAWAWAAAoQAAAngWAWQgWAVgqAAIgmAAIAABSgAAfVPIAVAAQAkAAAAgeQAAgfgkAAIgVAAgAuxXVIAAj3IBbAAQA0AAAkAkQAlAkAAAzQAAA1glAjQgkAkg0AAgAtxWeIAOAAQAfAAATgQQAVgTAAgiQAAgggTgSQgTgTggABIgPAAgAQmUEQgHgHAAgKQAAgJAHgHQAHgGAJAAQAFAAAFACIAAANQgEgEgGAAQgFgBgDAEQgDAEAAAEQAAAFADAEQADADAFAAQAFABAFgFIAAANIgBAAIgJACQgJAAgHgGgAQPUJIgEgYIgKAYIgEAAIgKgYIgEAYIgLAAIAHgrIALAAIAJAXIAJgXIALAAIAHArgAWOO/QgwgSgmgkQhQhHAAh0QAAg0ATgvQATgvAjgkQAlglAygWQAygWA0ABQA4AAA+AZIAACbQgTgbgfgPQgegOghABQg7gBglAoQglAnAAA7QAAA8AlAlQAmAmA8AAQAfAAAegOQAdgOAVgZIAACbQgnANgTADQgdAHgbAAQg0AAgwgTgAlFOGQhNhMAAh2QAAhsBThKQBPhGBtAAQBtAABOBGQBTBKAABsQAAB2hNBMQhLBMh2AAQh2AAhMhMgAjlJqQgoAnAAAzQAAA+AoArQAoApA6AAQA5AAApgpQAngrAAg+QAAgzgngnQgqgng4AAQg4AAgqAngAsNPDQgpgNgVgUIgBgBIAAh/IAEAGQAXAaAqATQAqASAhAAQAfABASgLIgBAAQARgMAAgTQAAgUgSgLIAAAAQgQgLgwgSIABAAQiAgvAAhvQAAhDAwgsQAugsBNAAQAqAAAlALIAAABQAkAMAWAPIABACIAAB8IgFgEQgTgWgigQQgigRgeAAQgbAAgPALQgOALAAASQAAATAPANQAQANAqAPQA/AWAlAnQAmAnAAA2QAABGgxAuQgyArhYABQgygBgqgNgAFuPCQgugOgdgdQghgfgLgxQgIghAAg8IAAkTICAAAIAAECQAAA/AMAcQATAqA3AAQA3AAATgqQANgcAAg/IAAkCIB/AAIAAETQAAA9gHAgQgLAxghAfQgdAdguAOQgoAMgwAAQgvAAgogMgAbjPBIAAnqIEXAAIAABsIiXAAIAABSICPAAIAABsIiPAAIAABUICXAAIAABsgAQUPBIh5i9IgBAAIAAC9Ih/AAIAAnqIC+AAQBNAAAsAkQAxAnAABMQAAA1gbAlQgdAngzAKICaDIgAOaKzIAMAAQAnAAAVgKQAdgPAAglQAAgjgdgPQgVgLgnAAIgMAAgA0DPBIgfhVIiwAAIgiBVIiHAAIC9nqICLAAIC4HqgA2vMLIBqAAIg0idIgBAAgA/5PBIAAnqIB/AAIAAF+ICZAAIAABsgAlHgKQh4g6hfhiIAAjkQBsB0BtA8QCYBUC0AAQCcAABohxQBfhoAAiJQAAiIhhhqQhohwiXAAQgvAAgfgfQgegfAAgwQAAgtAiggQAhgdApAAIALAAQB3AABpAtQBqAtBPBVQBJBPApBlQAoBmAABqQAADpilClQilCljpAAQi9gBifhNgAgUl0Qh3gBhqgsQhpguhPhUQhKhPgohlQgohmAAhrQAAjpClilQClilDpAAQEWACDMChIAADeQhrhehzgsQhzgtiEAAQicAAhnByQhfBoAACIQAACIBhBpQBoByCXAAQAugBAfAgQAfAfAAAvQAAAsgjAgQghAfgoAAg");
	this.shape.setTransform(176.3876,-251.1586,0.8689,0.8689);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(-1,-381.5,354.9,260.7), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJAKQgFgEAAgGQAAgFAFgEQAEgDAFAAQAHAAADADQAFAEAAAFQAAAGgFAEQgDADgHAAQgFAAgEgDg");
	this.shape.setTransform(163.75,-195.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgcAgQgJgJAAgSIAAguIAbAAIAAAvQAAAHADACQADADAEAAQAEAAADgDQAEgCAAgHIAAgvIAbAAIAAAuQAAASgJAJQgKAKgTAAQgSAAgKgKg");
	this.shape_1.setTransform(157.5,-198.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAUIgfAAIAAAKIAdAAIAAAUIgdAAIAAAKIAgAAIAAAVg");
	this.shape_2.setTransform(149.775,-198.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAMApIgZgtIABAOIAAAfIgbAAIAAhRIAeAAIAXAsIgBgOIAAgeIAbAAIAABRg");
	this.shape_3.setTransform(135.275,-198.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgfAfQgNgLAAgUQAAgTANgMQAMgLATAAQAUAAAMALQANAMAAATQAAAUgNALQgMAMgUAAQgTAAgMgMgAgMgNQgFAFAAAIQAAAIAFAFQAFAGAHAAQAIAAAFgGQAFgFAAgIQAAgIgFgFQgFgGgIAAQgHAAgFAGg");
	this.shape_4.setTransform(125.975,-198.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgNApIAAg9IgTAAIAAgUIBBAAIAAAUIgTAAIAAA9g");
	this.shape_5.setTransform(118.425,-198.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAUIgfAAIAAAKIAdAAIAAAUIgdAAIAAAKIAgAAIAAAVg");
	this.shape_6.setTransform(109.375,-198.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AghAgIAMgVQAFAEAIADQAGACADAAQAGAAAAgDQAAgDgGgCIgLgEQgIgDgEgDQgIgFAAgLQAAgNAKgIQAJgHAPAAQARAAAMAKIgKATQgEgDgHgDIgJgBQgGAAAAADQAAACAFACIAKADQAJADAFAEQAIAFAAAMQAAANgLAJQgJAHgPAAQgRAAgPgLg");
	this.shape_7.setTransform(102.275,-198.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgNApIAAhRIAbAAIAABRg");
	this.shape_8.setTransform(96.975,-198.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgbApIAAhRIAbAAIAAA7IAcAAIAAAWg");
	this.shape_9.setTransform(92.125,-198.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAOApIgDgLIgXAAIgDALIgcAAIAdhRIAdAAIAdBRgAAFAJIgFgWIgGAWIALAAg");
	this.shape_10.setTransform(84.5,-198.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAMApIgZgtIABAOIAAAfIgbAAIAAhRIAeAAIAXAsIgBgOIAAgeIAbAAIAABRg");
	this.shape_11.setTransform(75.625,-198.45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAMApIgZgtIABAOIAAAfIgbAAIAAhRIAeAAIAXAsIgBgOIAAgeIAbAAIAABRg");
	this.shape_12.setTransform(66.475,-198.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgfAfQgNgLAAgUQAAgTANgMQAMgLATAAQAUAAAMALQANAMAAATQAAAUgNALQgMAMgUAAQgTAAgMgMgAgMgNQgFAFAAAIQAAAIAFAFQAFAGAHAAQAIAAAFgGQAFgFAAgIQAAgIgFgFQgFgGgIAAQgHAAgFAGg");
	this.shape_13.setTransform(57.175,-198.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AghAgIAMgVQAFAEAIADQAGACADAAQAGAAAAgDQAAgDgGgCIgLgEQgIgDgEgDQgIgFAAgLQAAgNAKgIQAJgHAPAAQARAAAMAKIgKATQgEgDgHgDIgJgBQgGAAAAADQAAACAFACIAKADQAJADAFAEQAIAFAAAMQAAANgLAJQgJAHgPAAQgRAAgPgLg");
	this.shape_14.setTransform(48.925,-198.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAGApIgMgbIgDAAIAAAbIgcAAIAAhRIAkAAQAPgBAJAHQAKAGAAAOQAAAQgOAIIATAfgAgKgFIAHAAQADgBACgBQADgCAAgEQAAgEgDgCQgCgBgDAAIgHAAg");
	this.shape_15.setTransform(41.975,-198.45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAUIgfAAIAAAKIAdAAIAAAUIgdAAIAAAKIAgAAIAAAVg");
	this.shape_16.setTransform(34.225,-198.45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgiApIAAhRIAjAAQAQAAAIAGQAJAHABAPQgBANgJAIQgIAGgQAAIgHAAIAAAagAgHgEIAFAAQAEAAACgBQADgCAAgFQAAgFgDgCQgCgBgEAAIgFAAg");
	this.shape_17.setTransform(27.15,-198.45);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAMApIgZgtIABAOIAAAfIgbAAIAAhRIAeAAIAXAsIgBgOIAAgeIAbAAIAABRg");
	this.shape_18.setTransform(16.175,-198.45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgfAfQgNgLAAgUQAAgTANgMQAMgLATAAQAUAAAMALQANAMAAATQAAAUgNALQgMAMgUAAQgTAAgMgMgAgMgNQgFAFAAAIQAAAIAFAFQAFAGAHAAQAIAAAFgGQAFgFAAgIQAAgIgFgFQgFgGgIAAQgHAAgFAGg");
	this.shape_19.setTransform(6.875,-198.45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhvAqIgGgBIABgUIAHABIADgBQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAgBIAAg6IAbAAIAAA6QAAANgGAHQgGAGgLAAIgKgBgABugeQgCgBAAgEQAAgDACgCQABAAAAgBQABAAAAAAQABgBABAAQAAAAABAAIADABIAAAEQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAgBgBAAQgBAAAAABQgBAAAAAAQgBABAAAAQAAABAAABIABADIACABIADgCIAAAFIgDABQgBAAAAgBQgBAAgBAAQAAAAgBgBQAAAAgBgBgABngbIgBgIIgEAIIgBAAIgDgIIgBAIIgEAAIADgPIADAAIADAIIADgIIADAAIACAPg");
	this.shape_20.setTransform(153.925,-198.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(0.7,-205.3,166.70000000000002,14.900000000000006), null);


(lib.Ctext5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgMAMQgFgEAAgIQAAgHAFgEQAFgEAHAAQAIAAAFAEQAFAEAAAHQAAAIgFAEQgFAEgIAAQgHAAgFgEg");
	this.shape.setTransform(55.825,-132.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAYBMIgYgxIgXAxIg8AAIAzhOIgwhJIA7AAIAVApIAVgpIA8AAIgwBJIAzBOg");
	this.shape_1.setTransform(45.325,-138.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgYBMIAAiXIAxAAIAACXg");
	this.shape_2.setTransform(33.825,-138.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAMBMIgYgzIgGAAIAAAzIgyAAIAAiXIBCAAQAcAAAPALQATAOAAAXQAAAegZAPIAiA6gAgSgLIAMAAQAHAAADgCQAGgFAAgGQAAgGgGgFQgDgDgHAAIgMAAg");
	this.shape_3.setTransform(23.725,-138.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag+BMIAAiXIBBAAQAbAAAPAMQASAOAAAbQAAAZgSANQgPANgbAAIgPAAIAAAvgAgMgIIAIAAQAHAAAEgDQAGgDAAgIQAAgJgGgEQgEgDgHAAIgIAAg");
	this.shape_4.setTransform(9.375,-138.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext5, new cjs.Rectangle(0,-150.2,60.7,25.999999999999986), null);


(lib.Ctext4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAMBMIgYgyIgGAAIAAAyIgyAAIAAiXIBCAAQAcAAAPALQATANAAAYQAAAegZAPIAiA6gAgSgLIAMAAQAHAAADgDQAGgEAAgGQAAgHgGgEQgDgCgHAAIgMAAg");
	this.shape.setTransform(135.975,-159.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag0A7QgQgQAAghIAAhWIAyAAIAABYQAAAMAFAFQAFAFAIAAQAJAAAFgFQAFgFAAgMIAAhYIAyAAIAABWQAAAhgQAQQgSASgjAAQgiAAgSgSg");
	this.shape_1.setTransform(120.125,-159.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAnIg6AAIAAARIA2AAIAAAmIg2AAIAAARIA8AAIAAAog");
	this.shape_2.setTransform(106.05,-159.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgxBMIAAiXIAxAAIAABuIAzAAIAAApg");
	this.shape_3.setTransform(94.2,-159.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgxBMIAAiXIAxAAIAABuIAyAAIAAApg");
	this.shape_4.setTransform(82.8,-159.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgYBMIAAiXIAxAAIAACXg");
	this.shape_5.setTransform(73.075,-159.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAnIg5AAIAAARIA2AAIAAAmIg2AAIAAARIA7AAIAAAog");
	this.shape_6.setTransform(63.35,-159.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AArBMIgChWIgTBWIgqAAIgUhWIgCBWIgxAAIAJiXIBAAAIASBSIAThSIBAAAIAJCXg");
	this.shape_7.setTransform(46.925,-159.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag0A7QgQgQAAghIAAhWIAyAAIAABYQAAAMAFAFQAFAFAIAAQAJAAAFgFQAFgFAAgMIAAhYIAyAAIAABWQAAAhgQAQQgSASgjAAQgiAAgSgSg");
	this.shape_8.setTransform(24.975,-159.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAaBMIgGgWIgqAAIgGAWIgzAAIA0iXIA2AAIA1CXgAAKARIgKgoIgMAoIAWAAg");
	this.shape_9.setTransform(9.825,-159.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext4, new cjs.Rectangle(0,-171.2,144.7,26), null);


(lib.Ctext3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgrBZIADgsQAIADAHAAQAJAAAAgLIAAiBIA8AAIAACBQAAAdgOAOQgNANgZAAQgaAAgJgEg");
	this.shape.setTransform(22.1271,-181.069,0.8291,0.8291);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYBMIAAhwIgjAAIAAgnIB3AAIAAAnIgjAAIAABwg");
	this.shape_1.setTransform(134.2,-181.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAVBMIgthTIABAaIAAA5IgwAAIAAiXIA2AAIAqBUIgBgaIAAg6IAxAAIAACXg");
	this.shape_2.setTransform(119.8,-181.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAoIg5AAIAAAQIA2AAIAAAmIg2AAIAAASIA7AAIAAAng");
	this.shape_3.setTransform(105.3,-181.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AArBMIgChWIgTBWIgqAAIgUhWIgCBWIgxAAIAJiXIBAAAIASBSIAThSIBAAAIAJCXg");
	this.shape_4.setTransform(88.875,-181.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAoIg5AAIAAAQIA1AAIAAAmIg1AAIAAASIA7AAIAAAng");
	this.shape_5.setTransform(72.9,-181.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgYBMIAAhwIgkAAIAAgnIB5AAIAAAnIgkAAIAABwg");
	this.shape_6.setTransform(60.25,-181.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag8A6IAVglQAKAHAOAFQAKAEAGAAQALAAAAgGQAAgFgLgDIgVgIQgPgFgFgFQgOgMgBgUQAAgWASgPQAQgNAbAAQAhAAAWATIgTAjQgIgHgLgFQgKgDgHAAQgLAAAAAGQAAAEAJAEIASAFQARAFAJAIQAOALgBAUQAAAZgTAPQgRANgbAAQggAAgagUg");
	this.shape_7.setTransform(48.05,-181.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag0A7QgQgQAAghIAAhWIAyAAIAABYQAAAMAFAFQAFAFAIAAQAJAAAFgFQAFgFAAgMIAAhYIAyAAIAABWQAAAhgQAQQgSASgjAAQgiAAgSgSg");
	this.shape_8.setTransform(34.025,-181.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAaBMIgGgVIgqAAIgGAVIgzAAIA0iXIA2AAIA1CXgAAKARIgKgoIgMAoIAWAAg");
	this.shape_9.setTransform(9.825,-181.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext3, new cjs.Rectangle(0,-193.5,142.5,26), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAVBMIgthTIABAaIAAA5IgwAAIAAiXIA2AAIArBUIgBgaIAAg6IAvAAIAACXg");
	this.shape.setTransform(70.6,-201.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag6A6QgYgVABgkQgBgkAYgWQAXgUAjgBQAkABAXAUQAYAWgBAkQABAkgYAVQgXAUgkABQgjgBgXgUgAgXgZQgJAKAAAPQAAAPAJAKQAJAKAOAAQAPAAAJgKQAIgKAAgPQAAgPgIgKQgJgKgPAAQgOAAgJAKg");
	this.shape_1.setTransform(53.6,-201.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhBBMIAAiXIA/AAQAYAAANAFQAKAFAGAHQAHAKAAAMQAAAMgHAJQgGAJgIADQANADAIAKQAIAJAAANQAAAXgRALQgPAKgZAAgAgPAnIAPAAQAHAAAEgCQAFgDAAgHQAAgGgFgDQgEgDgHAAIgPAAgAgPgRIAKAAQAGAAAEgCQAEgDAAgGQAAgGgEgDQgEgCgGAAIgKAAg");
	this.shape_2.setTransform(38.075,-201.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAoIg6AAIAAAQIA2AAIAAAmIg2AAIAAASIA8AAIAAAng");
	this.shape_3.setTransform(20,-201.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgyBMIAAiXIAyAAIAABvIAzAAIAAAog");
	this.shape_4.setTransform(8.15,-201.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(0,-213.7,81.2,26), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgMAMQgFgEAAgIQAAgHAFgEQAFgEAHAAQAIAAAFAEQAFAEAAAHQAAAIgFAEQgFAEgIAAQgHAAgFgEg");
	this.shape.setTransform(108.475,-73.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYBMIAAhwIgkAAIAAgnIB5AAIAAAnIgkAAIAABwg");
	this.shape_1.setTransform(102,-80);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAMBMIgYgzIgGAAIAAAzIgyAAIAAiXIBCAAQAcAAAPALQATAOAAAYQAAAdgZAQIAiA5gAgSgLIAMAAQAHAAADgDQAGgDAAgHQAAgGgGgEQgDgEgHAAIgMAAg");
	this.shape_2.setTransform(89.425,-80);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag6A6QgXgWgBgjQABgkAXgWQAWgUAkAAQAkAAAXAUQAYAWAAAkQAAAjgYAWQgXAUgkAAQgkAAgWgUgAgXgZQgIAJAAAQQAAAPAIAKQAJAKAOgBQAOABAKgKQAIgKAAgPQAAgQgIgJQgKgKgOAAQgOAAgJAKg");
	this.shape_3.setTransform(72.8,-80);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag+BMIAAiXIBBAAQAbAAAPANQASANAAAaQAAAagSANQgPAMgbABIgPAAIAAAvgAgMgHIAIAAQAHAAAEgEQAGgDAAgJQAAgIgGgDQgEgEgHAAIgIAAg");
	this.shape_4.setTransform(57.725,-80);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag8A6IAVgmQAKAJAOAEQAKAEAGAAQALAAAAgGQAAgFgLgDIgVgHQgPgGgFgFQgOgMgBgUQAAgWASgPQAQgNAbAAQAhAAAWATIgTAiQgIgGgLgFQgKgDgHAAQgLAAAAAGQAAAEAJADIASAGQARAGAJAGQAOAMgBAUQAAAZgTAPQgRANgbAAQggAAgagUg");
	this.shape_5.setTransform(44,-79.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag0A7QgQgQAAghIAAhWIAyAAIAABYQAAAMAFAFQAFAFAIAAQAJAAAFgFQAFgFAAgMIAAhYIAyAAIAABWQAAAhgQAQQgSASgjAAQgiAAgSgSg");
	this.shape_6.setTransform(25.725,-79.875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhHBMIAAiXIA6AAQAlAAAWAQQAZAUAAAnQAAAogZATQgWARglAAgAgVAiIALAAQAPAAAIgHQAIgKABgRQgBgSgIgIQgIgIgPAAIgLAAg");
	this.shape_7.setTransform(10.25,-80);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(0,-92,113.3,26), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgKAiIAAgyIgQAAIAAgRIA1AAIAAARIgQAAIAAAyg");
	this.shape.setTransform(113.525,-69.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AAJAiIgUglIABAMIAAAZIgWAAIAAhDIAYAAIATAlIAAgLIAAgaIAWAAIAABDg");
	this.shape_1.setTransform(107.075,-69.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AAMAiIgDgJIgSAAIgDAJIgXAAIAYhDIAXAAIAYBDgAAEAIIgEgSIgFASIAJAAg");
	this.shape_2.setTransform(99.825,-69.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AAJAiIgUglIABAMIAAAZIgWAAIAAhDIAYAAIATAlIAAgLIAAgaIAWAAIAABDg");
	this.shape_3.setTransform(92.575,-69.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AgYAiIAAhDIAwAAIAAASIgaAAIAAAHIAYAAIAAARIgYAAIAAAHIAbAAIAAASg");
	this.shape_4.setTransform(86.075,-69.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AgKAiIAAgyIgQAAIAAgRIA1AAIAAARIgQAAIAAAyg");
	this.shape_5.setTransform(80.375,-69.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AAJAiIgUglIABAMIAAAZIgWAAIAAhDIAYAAIATAlIAAgLIAAgaIAWAAIAABDg");
	this.shape_6.setTransform(73.925,-69.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgKAiIAAhDIAVAAIAABDg");
	this.shape_7.setTransform(68.575,-69.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AAMAiIgDgJIgSAAIgDAJIgXAAIAYhDIAXAAIAYBDgAAEAIIgEgSIgFASIAJAAg");
	this.shape_8.setTransform(63.475,-69.425);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#231F20").s().p("AATAiIAAgmIgJAmIgTAAIgJgmIAAAmIgWAAIAEhDIAcAAIAIAkIAJgkIAcAAIAEBDg");
	this.shape_9.setTransform(55.525,-69.425);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#231F20").s().p("AAFAiIgKgXIgCAAIAAAXIgXAAIAAhDIAeAAQALAAAHAFQAJAGAAALQAAAMgLAHIAPAagAgIgEIAGAAQACAAACgCQACgBAAgDQAAgDgCgCQgCgBgCAAIgGAAg");
	this.shape_10.setTransform(46.3,-69.425);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#231F20").s().p("AgYAiIAAhDIAwAAIAAASIgaAAIAAAHIAYAAIAAARIgYAAIAAAHIAbAAIAAASg");
	this.shape_11.setTransform(39.975,-69.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#231F20").s().p("AgKAiIAAgyIgQAAIAAgRIA1AAIAAARIgQAAIAAAyg");
	this.shape_12.setTransform(34.275,-69.425);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#231F20").s().p("AgYAiIAAhDIAwAAIAAASIgaAAIAAAHIAYAAIAAARIgYAAIAAAHIAbAAIAAASg");
	this.shape_13.setTransform(28.825,-69.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#231F20").s().p("AAJAiIAAgZIgRAAIAAAZIgXAAIAAhDIAXAAIAAAZIARAAIAAgZIAXAAIAABDg");
	this.shape_14.setTransform(22.225,-69.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#231F20").s().p("AgTAaQgKgJAAgRQAAgPAKgKQAKgJAPAAQAQAAAHAGIgGATQgHgGgJAAQgGAAgDAEQgFAEAAAHQAAAHAFAFQADADAGAAQALAAAGgGIAHASQgJAIgQAAQgPAAgKgJg");
	this.shape_15.setTransform(15.55,-69.425);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#231F20").s().p("AAMAiIgDgJIgSAAIgDAJIgXAAIAYhDIAXAAIAYBDgAAEAIIgEgSIgFASIAJAAg");
	this.shape_16.setTransform(9.125,-69.425);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AotBiQgQAAgMgMQgMgMAAgRIAAhyQAAgQAMgMQAMgMAQAAIRaAAQARAAAMAMQAMAMAAAQIAAByQAAARgMAMQgMAMgRAAg");
	this.shape_17.setTransform(60.775,-69.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(1,-79.3,119.6,19.5), null);


(lib.Btext22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAnIg5AAIAAARIA2AAIAAAmIg2AAIAAARIA7AAIAAAog");
	this.shape.setTransform(33.9,-239.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAVBMIgthUIABAbIAAA5IgxAAIAAiXIA3AAIArBUIgBgbIAAg5IAvAAIAACXg");
	this.shape_1.setTransform(18.95,-239.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag0A7QgQgQAAghIAAhWIAyAAIAABYQAAAMAFAFQAFAFAIAAQAJAAAFgFQAFgFAAgMIAAhYIAyAAIAABWQAAAhgQAQQgSASgjAAQgiAAgSgSg");
	this.shape_2.setTransform(2.725,-239.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgTAVIANgpIAaAAIgQApg");
	this.shape_3.setTransform(-11.925,-232.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAMBMIgYgzIgGAAIAAAzIgyAAIAAiXIBCAAQAcAAAPALQATANAAAYQAAAegZAPIAiA6gAgSgLIAMAAQAHAAADgCQAGgFAAgGQAAgGgGgFQgDgCgHAAIgMAAg");
	this.shape_4.setTransform(-20.525,-239.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag6A6QgXgVAAglQAAgjAXgVQAXgWAjAAQAkAAAXAWQAYAVAAAjQAAAlgYAVQgXAVgkAAQgjAAgXgVgAgXgaQgJAKAAAQQAAAPAJAKQAJAJAOAAQAPAAAIgJQAJgKAAgPQAAgQgJgKQgIgJgPAAQgOAAgJAJg");
	this.shape_5.setTransform(-37.15,-239.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag+BMIAAiXIBBAAQAbAAAPAMQASAOAAAbQAAAZgSANQgPAMgbAAIgPAAIAAAwgAgMgIIAIAAQAHAAAEgCQAGgEAAgIQAAgJgGgEQgEgCgHAAIgIAAg");
	this.shape_6.setTransform(-52.225,-239.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAaBMIgGgWIgqAAIgGAWIgzAAIA0iXIA2AAIA1CXgAAKAQIgKgnIgMAnIAWAAg");
	this.shape_7.setTransform(-67.375,-239.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgXBMIg5iXIA0AAIAcBXIAdhXIA0AAIg5CXg");
	this.shape_8.setTransform(-80.075,-239.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-251.7,132.3,26);


(lib.Btext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAMBMIgYgyIgGAAIAAAyIgyAAIAAiXIBCAAQAcAAAPALQATANAAAZQAAAdgZAPIAiA6gAgSgLIAMAAQAHAAADgDQAGgEAAgGQAAgHgGgEQgDgCgHAAIgMAAg");
	this.shape.setTransform(147.025,-240.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAoIg5AAIAAAQIA2AAIAAAmIg2AAIAAARIA7AAIAAAog");
	this.shape_1.setTransform(132.9,-240.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag0A7QgQgQAAghIAAhWIAyAAIAABYQAAAMAFAFQAFAFAIAAQAJAAAFgFQAFgFAAgMIAAhYIAyAAIAABWQAAAhgQAQQgSASgjAAQgiAAgSgSg");
	this.shape_2.setTransform(118.425,-240.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAaBMIgGgWIgqAAIgGAWIgzAAIA0iXIA2AAIA1CXgAAKARIgKgoIgMAoIAWAAg");
	this.shape_3.setTransform(103.275,-240.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhBBMIAAiXIA/AAQAYAAANAFQAKAEAGAIQAHAKAAAMQAAAMgHAJQgGAJgIAEQANACAIAJQAIAKAAANQAAAXgRALQgPAKgZAAgAgPAnIAPAAQAHAAAEgDQAFgCAAgHQAAgGgFgDQgEgDgHAAIgPAAgAgPgRIAKAAQAGAAAEgCQAEgEAAgFQAAgGgEgDQgEgCgGAAIgKAAg");
	this.shape_4.setTransform(88.625,-240.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag9A6IAXglQAJAHANAFQALAEAGAAQALAAAAgGQAAgFgLgEIgVgHQgPgFgFgGQgOgLgBgUQAAgWASgPQAQgNAcAAQAgAAAWATIgTAjQgIgIgLgDQgKgEgHAAQgMAAAAAGQAAAEAKAEIASAFQARAFAIAIQAOALABAUQAAAYgUAQQgRANgbAAQggAAgbgUg");
	this.shape_5.setTransform(70.35,-240.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAVBMIgthUIABAbIAAA5IgxAAIAAiXIA2AAIAsBUIgBgaIAAg6IAvAAIAACXg");
	this.shape_6.setTransform(55.85,-240.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgYBMIAAiXIAxAAIAACXg");
	this.shape_7.setTransform(43.925,-240.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgYBMIAAhwIgjAAIAAgnIB3AAIAAAnIgjAAIAABwg");
	this.shape_8.setTransform(34.3,-240.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAaBMIgGgWIgqAAIgGAWIgzAAIA0iXIA2AAIA1CXgAAKARIgKgoIgMAoIAWAAg");
	this.shape_9.setTransform(22.475,-240.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag+BMIAAiXIBBAAQAbAAAPANQASANAAAaQAAAagSAOQgPAMgbgBIgPAAIAAAwgAgMgIIAIAAQAHAAAEgCQAGgEAAgJQAAgIgGgEQgEgCgHAAIgIAAg");
	this.shape_10.setTransform(9.375,-240.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btext1, new cjs.Rectangle(0,-252.8,155.8,26), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-100.8,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-293.3,125.2,26);


// stage content:
(lib.fam_336x280_fr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(168,315,1.12,1.12,0,0,0,62,18.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(309).to({_off:false},0).to({alpha:1},22,cjs.Ease.cubicInOut).wait(12));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(-101.85,413.9,1.12,1.12,0,0,0,84.2,10.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(292).to({_off:false},0).to({x:166.9},20,cjs.Ease.quartOut).wait(31));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(166.05,299.5,0.448,0.448,0,0,0,177.6,184.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(268).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(46));

	// skate3
	this.instance_3 = new lib.skate3();
	this.instance_3.setTransform(196,562.8,1.12,1.12,0,0,0,57,61.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({x:109.75},20,cjs.Ease.quartOut).wait(187).to({x:196.55},18,cjs.Ease.quintInOut).wait(70));

	// skate2
	this.instance_4 = new lib.skate2();
	this.instance_4.setTransform(334.3,498.4,1.12,1.12,0,0,0,57,62);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({_off:false},0).to({x:247.5},20,cjs.Ease.quartOut).wait(190).to({x:334.3},18,cjs.Ease.quintInOut).wait(71));

	// skate1
	this.instance_5 = new lib.skate1();
	this.instance_5.setTransform(190.5,412.7,1.12,1.12,0,0,0,56.1,61.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(40).to({_off:false},0).to({x:108.75},20,cjs.Ease.quartOut).wait(193).to({x:202.55},18,cjs.Ease.quintInOut).wait(72));

	// cta
	this.instance_6 = new lib.CTA();
	this.instance_6.setTransform(94.65,320.25,1.12,1.12,0,0,0,62.1,18.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(145).to({y:274.35},23,cjs.Ease.quartInOut).wait(81).to({y:281.05,alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(76));

	// Ctext5
	this.instance_7 = new lib.Ctext5();
	this.instance_7.setTransform(-173.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(163).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(75));

	// Ctext4
	this.instance_8 = new lib.Ctext4();
	this.instance_8.setTransform(-173.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(160).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(78));

	// Ctext3
	this.instance_9 = new lib.Ctext3();
	this.instance_9.setTransform(-103.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(157).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(81));

	// Ctet2
	this.instance_10 = new lib.Ctext2();
	this.instance_10.setTransform(-117.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(154).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_11 = new lib.Ctext1();
	this.instance_11.setTransform(-103.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(25).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(91).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(187));

	// Btext6
	this.instance_12 = new lib.text6();
	this.instance_12.setTransform(-179.1,366.45,1.12,1.12);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(22).to({_off:false},0).to({x:123.25},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(189));

	// Btext2_copy
	this.instance_13 = new lib.text3();
	this.instance_13.setTransform(-179.1,366.45,1.12,1.12);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(19).to({_off:false},0).to({x:123.25},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(192));

	// Btext2
	this.instance_14 = new lib.Btext22();
	this.instance_14.setTransform(-156.25,366.45,1.12,1.12);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(17).to({_off:false},0).to({x:123.25},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(194));

	// Btext1
	this.instance_15 = new lib.Btext1();
	this.instance_15.setTransform(-147.8,372.95,1.12,1.12,0,0,0,74.8,24);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(13).to({_off:false},0).to({x:106.15,y:371.6},22,cjs.Ease.quartOut).wait(93).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(197));

	// text2
	this.instance_16 = new lib.Tween2("synched",0);
	this.instance_16.setTransform(-158.95,366.45,1.12,1.12);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(9).to({_off:false},0).to({x:123.25},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_17 = new lib.text1();
	this.instance_17.setTransform(-206.95,282.9,1.12,1.12,0,0,0,74.8,24);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(5).to({_off:false},0).to({x:106.15},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// bg
	this.instance_18 = new lib.Asset1();
	this.instance_18.setTransform(0,0,0.6021,0.6054);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("EgaPA0gMAAAho/MA0fAAAMAAABo/g");
	this.shape.setTransform(168,336);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_18}]}).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-122.7,140,540.9,532);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 336,
	height: 280,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/fam_336x280_fr_atlas_P_1.png", id:"fam_336x280_fr_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;