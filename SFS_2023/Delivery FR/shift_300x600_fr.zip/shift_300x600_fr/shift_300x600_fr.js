(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"shift_300x600_fr_atlas_1", frames: [[0,0,558,1110],[560,602,330,450],[560,0,521,600]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset1 = function() {
	this.initialize(ss["shift_300x600_fr_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset14shiftImage1DBL = function() {
	this.initialize(ss["shift_300x600_fr_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.ScreenShot20230707at100539AM = function() {
	this.initialize(ss["shift_300x600_fr_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhABJQgUgUAAgpIAAhqIA9AAIAABtQAAAOAHAGQAGAHAKAAQALAAAHgHQAFgGAAgOIAAhtIA+AAIAABqQAAApgUAUQgWAWgrAAQgpAAgXgWg");
	this.shape.setTransform(205.75,-135.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhXBdIAAi5IBGAAQAvAAAbAUQAfAYAAAwQAAAxgfAYQgbAUgvAAgAgaAqIAOAAQASAAAJgKQALgKAAgWQAAgWgLgLQgJgJgSAAIgOAAg");
	this.shape_1.setTransform(186.775,-135.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhCBdIAAi5ICDAAIAAAwIhHAAIAAAUIBDAAIAAAvIhDAAIAAAWIBKAAIAAAwg");
	this.shape_2.setTransform(163.85,-135.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag1BHQgdgaAAgtQAAgsAdgbQAcgYAqAAQApAAAVARIgRA0QgSgRgXAAQgSAAgLALQgNALAAAVQAAATANAMQALAKASAAQAbAAASgRIARAwQgYAYgqAAQgqAAgcgZg");
	this.shape_3.setTransform(147.5,-135.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_4.setTransform(130.625,-135.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhABJQgUgUAAgpIAAhqIA+AAIAABtQgBAOAHAGQAGAHAKAAQALAAAGgHQAHgGgBgOIAAhtIA+AAIAABqQAAApgUAUQgWAWgrAAQgpAAgXgWg");
	this.shape_5.setTransform(111.15,-135.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhHBHQgdgbAAgsQAAgrAdgbQAbgaAsABQAsgBAcAaQAdAbAAArQAAAsgdAbQgcAagsgBQgsABgbgagAgcgfQgLAMAAASQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgSgLgMQgLgMgSAAQgRAAgLAMg");
	this.shape_6.setTransform(90.825,-135.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhLBHIAcguQALAKAQAFQAOAFAHAAQAOAAAAgIQAAgFgNgFIgagIQgTgHgHgHQgRgOAAgZQAAgbAVgSQAUgQAiAAQAoAAAbAXIgYArQgJgJgPgFQgLgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQASAPAAAZQAAAegZATQgUAQghAAQgnAAgigZg");
	this.shape_7.setTransform(72.35,-135.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAhBdIgIgaIg0AAIgHAaIhAAAIBBi5IBDAAIBAC5gAAMAUIgMgxIgPAxIAbAAg");
	this.shape_8.setTransform(50,-135.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag9BdIAAi5IA9AAIAACHIA+AAIAAAyg");
	this.shape_9.setTransform(33.95,-135.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAgB1IgHgaIg0AAIgHAaIhAAAIBBi6IBCAAIBBC6gAAMAsIgNgxIgNAxIAaAAgAgShNIgZgnIAwAAIASAng");
	this.shape_10.setTransform(11.6,-137.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(0,-149.7,222.9,30.999999999999986), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhCB1IAAi6ICDAAIAAAwIhHAAIAAAVIBDAAIAAAvIhDAAIAAAVIBKAAIAAAxgAgehNIATgnIAvAAIgZAng");
	this.shape.setTransform(202.65,-193.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgdBdIAAiKIgsAAIAAgvICTAAIAAAvIgrAAIAACKg");
	this.shape_1.setTransform(187.125,-190.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdBdIAAi5IA8AAIAAC5g");
	this.shape_2.setTransform(175.3,-190.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgdBdIhGi5IBBAAIAiBrIAjhrIBBAAIhGC5g");
	this.shape_3.setTransform(161.225,-190.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgdBdIAAi5IA7AAIAAC5g");
	this.shape_4.setTransform(147.1,-190.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhLBHIAcguQALAKAQAFQAOAFAHAAQAOAAAAgIQAAgFgNgFIgagIQgTgHgHgHQgRgOAAgZQAAgbAVgSQAUgQAiAAQAoAAAbAXIgYArQgJgJgPgFQgLgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQASAPAAAZQAAAegZATQgUAQghAAQgnAAgigZg");
	this.shape_5.setTransform(134.9,-190.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag/BJQgVgUAAgpIAAhqIA9AAIAABtQAAAOAHAGQAGAHAKAAQALAAAHgHQAFgGAAgOIAAhtIA+AAIAABqQAAApgUAUQgWAWgrAAQgqAAgVgWg");
	this.shape_6.setTransform(117.65,-190.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag9BdIAAi5IA8AAIAACHIA/AAIAAAyg");
	this.shape_7.setTransform(102.05,-190.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag1BHQgdgaAAgtQAAgsAdgbQAbgYArAAQAqAAAUARIgQA0QgTgRgXAAQgTAAgKALQgNALAAAVQAAATAOAMQAKAKASAAQAcAAAQgRIASAwQgYAYgqAAQgrAAgbgZg");
	this.shape_8.setTransform(86.25,-190.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAeBdIgeg7IgdA7IhJAAIA+hgIg6hZIBJAAIAZAyIAagyIBJAAIg7BZIA/Bgg");
	this.shape_9.setTransform(68.775,-190.725);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBJAAIAAAwg");
	this.shape_10.setTransform(51.5,-190.725);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAaBdIg4hnIABAhIAABGIg7AAIAAi5IBCAAIA1BnIgBghIAAhGIA7AAIAAC5g");
	this.shape_11.setTransform(27.9,-190.725);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBJAAIAAAwg");
	this.shape_12.setTransform(10.1,-190.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(0,-205,212.4,31), null);


(lib.skate2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.ScreenShot20230707at100539AM();
	this.instance.setTransform(-186,-148,0.6735,0.6735);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate2, new cjs.Rectangle(-186,-148,350.9,404.1), null);


(lib.skate1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Asset14shiftImage1DBL();
	this.instance.setTransform(-42,-72,0.9233,0.9233);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate1, new cjs.Rectangle(-42,-72,304.7,415.5), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AD6W3QgngnAAg6QAAg3AqgkQAngkA3AAQA2AAAoAkQApAkAAA3QAAA6gmAnQgmAmg7AAQg7AAgmgmgAEqUpQgVATAAAaQAAAfAVAVQAUAVAdgBQAdABAUgVQAUgVAAgfQAAgagUgTQgVgUgcAAQgcAAgVAUgAjrXVQgVgGgLgLIAAAAIAAhAIACADQAMANAVAKQAVAJARAAQARAAAHgGQAIgEAAgKQAAgKgJgGQgGgFgagKQhAgYAAg3QAAgiAYgWQAYgXAmABQAWgBASAHQATAGAKAHIAAABIAAA/IgCgCQgJgLgRgJQgTgIgOAAQgOAAgHAFQgHAGAAAJQAAAKAIAGQAGAGAXAIQAfAMATATQATAUAAAbQAAAjgZAXQgZAWgsAAQgaAAgUgHgAqHXAQgQgQgGgZQgEgQAAgeIAAiLIBAAAIAACCQAAAfAHAOQAKAWAbAAQAcAAAJgWQAHgOAAgfIAAiCIBAAAIAACLQAAAegEAQQgGAZgQAQQgcAbg2ABQg2gBgcgbgAM9XVIAAjAIg1AAIAAg3ICqAAIAAA3Ig1AAIAADAgAKYXVIg+hfIAABfIhAAAIAAj3IBkAAQAVAAAPAGQAPAGALAKQAJAKAGAPQAFANAAAQQAAAdgOARQgMARgcAHIBOBlgAJaVMIANAAQATABAKgJQAKgHAAgPQAAgPgKgIQgKgHgTgBIgNAAgAggXVIAAj3IBlAAQApAAAXAVQAWAWAAAoQAAAngWAWQgWAVgqAAIgmAAIAABSgAAfVPIAVAAQAkAAAAgeQAAgfgkAAIgVAAgAuxXVIAAj3IBbAAQA0AAAkAkQAlAkAAAzQAAA1glAjQgkAkg0AAgAtxWeIAOAAQAfAAATgQQAVgTAAgiQAAgggTgSQgTgTggABIgPAAgAQmUEQgHgHAAgKQAAgJAHgHQAHgGAJAAQAFAAAFACIAAANQgEgEgGAAQgFgBgDAEQgDAEAAAEQAAAFADAEQADADAFAAQAFABAFgFIAAANIgBAAIgJACQgJAAgHgGgAQPUJIgEgYIgKAYIgEAAIgKgYIgEAYIgLAAIAHgrIALAAIAJAXIAJgXIALAAIAHArgAWOO/QgwgSgmgkQhQhHAAh0QAAg0ATgvQATgvAjgkQAlglAygWQAygWA0ABQA4AAA+AZIAACbQgTgbgfgPQgegOghABQg7gBglAoQglAnAAA7QAAA8AlAlQAmAmA8AAQAfAAAegOQAdgOAVgZIAACbQgnANgTADQgdAHgbAAQg0AAgwgTgAlFOGQhNhMAAh2QAAhsBThKQBPhGBtAAQBtAABOBGQBTBKAABsQAAB2hNBMQhLBMh2AAQh2AAhMhMgAjlJqQgoAnAAAzQAAA+AoArQAoApA6AAQA5AAApgpQAngrAAg+QAAgzgngnQgqgng4AAQg4AAgqAngAsNPDQgpgNgVgUIgBgBIAAh/IAEAGQAXAaAqATQAqASAhAAQAfABASgLIgBAAQARgMAAgTQAAgUgSgLIAAAAQgQgLgwgSIABAAQiAgvAAhvQAAhDAwgsQAugsBNAAQAqAAAlALIAAABQAkAMAWAPIABACIAAB8IgFgEQgTgWgigQQgigRgeAAQgbAAgPALQgOALAAASQAAATAPANQAQANAqAPQA/AWAlAnQAmAnAAA2QAABGgxAuQgyArhYABQgygBgqgNgAFuPCQgugOgdgdQghgfgLgxQgIghAAg8IAAkTICAAAIAAECQAAA/AMAcQATAqA3AAQA3AAATgqQANgcAAg/IAAkCIB/AAIAAETQAAA9gHAgQgLAxghAfQgdAdguAOQgoAMgwAAQgvAAgogMgAbjPBIAAnqIEXAAIAABsIiXAAIAABSICPAAIAABsIiPAAIAABUICXAAIAABsgAQUPBIh5i9IgBAAIAAC9Ih/AAIAAnqIC+AAQBNAAAsAkQAxAnAABMQAAA1gbAlQgdAngzAKICaDIgAOaKzIAMAAQAnAAAVgKQAdgPAAglQAAgjgdgPQgVgLgnAAIgMAAgA0DPBIgfhVIiwAAIgiBVIiHAAIC9nqICLAAIC4HqgA2vMLIBqAAIg0idIgBAAgA/5PBIAAnqIB/AAIAAF+ICZAAIAABsgAlHgKQh4g6hfhiIAAjkQBsB0BtA8QCYBUC0AAQCcAABohxQBfhoAAiJQAAiIhhhqQhohwiXAAQgvAAgfgfQgegfAAgwQAAgtAiggQAhgdApAAIALAAQB3AABpAtQBqAtBPBVQBJBPApBlQAoBmAABqQAADpilClQilCljpAAQi9gBifhNgAgUl0Qh3gBhqgsQhpguhPhUQhKhPgohlQgohmAAhrQAAjpClilQClilDpAAQEWACDMChIAADeQhrhehzgsQhzgtiEAAQicAAhnByQhfBoAACIQAACIBhBpQBoByCXAAQAugBAfAgQAfAfAAAvQAAAsgjAgQghAfgoAAg");
	this.shape.setTransform(182.7365,186.3146,1.2343,1.2343);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(-69.3,1.1,504.1,370.4), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgQAQQgGgGAAgKQAAgIAGgGQAHgGAJABQALgBAFAGQAHAGAAAIQAAAKgHAGQgFAEgLAAQgJAAgHgEg");
	this.shape.setTransform(210.6,13.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgsAzQgOgPAAgcIAAhJIArAAIAABLQAAAKAEAEQAFAFAGAAQAIAAAEgFQAEgDAAgLIAAhLIArAAIAABJQAAAcgOAPQgPAPgeAAQgdAAgPgPg");
	this.shape_1.setTransform(200.825,9.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBbAAIAAAiIgwAAIAAANIAuAAIAAAhIguAAIAAAPIAyAAIAAAig");
	this.shape_2.setTransform(188.8,9.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AASBBIgnhIIABAXIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_3.setTransform(166.125,9.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgxAxQgVgSABgfQgBgeAVgTQATgRAeAAQAfAAATARQAUATAAAeQAAAfgUASQgTASgfAAQgeAAgTgSgAgUgWQgHAIAAAOQAAAMAHAJQAJAIALAAQANAAAHgIQAIgIgBgNQABgOgIgIQgHgIgNAAQgLAAgJAIg");
	this.shape_4.setTransform(151.55,9.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgUBBIAAhgIgfAAIAAghIBnAAIAAAhIgfAAIAABgg");
	this.shape_5.setTransform(139.75,9.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBcAAIAAAiIgyAAIAAANIAuAAIAAAhIguAAIAAAPIAzAAIAAAig");
	this.shape_6.setTransform(125.65,9.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag0AxIATgfQAIAGAMAEQAJAEAFgBQAJABAAgGQAAgDgJgEIgSgGQgMgFgGgFQgMgJAAgRQAAgTAPgMQAOgMAYAAQAbAAATAQIgQAeQgHgGgKgEQgIgDgGAAQgKAAAAAGQAAADAIADIAQAFQAOAFAIAGQAMAJAAARQAAAWgRANQgPALgXAAQgaAAgYgSg");
	this.shape_7.setTransform(114.575,9.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUBBIAAiBIApAAIAACBg");
	this.shape_8.setTransform(106.275,9.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgqBBIAAiBIAqAAIAABeIArAAIAAAjg");
	this.shape_9.setTransform(98.725,9.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAXBBIgFgTIgkAAIgFATIgtAAIAuiBIAuAAIAtCBgAAJAOIgJgiIgJAiIASAAg");
	this.shape_10.setTransform(86.725,9.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AASBBIgnhIIABAXIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_11.setTransform(72.925,9.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AASBBIgnhIIABAXIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_12.setTransform(58.625,9.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgyAxQgTgSgBgfQABgeATgTQAUgRAeAAQAfAAAUARQATATABAeQgBAfgTASQgUASgfAAQgeAAgUgSgAgTgWQgIAIAAAOQAAAMAIAJQAIAIALAAQAMAAAIgIQAHgIAAgNQAAgOgHgIQgIgIgMAAQgLAAgIAIg");
	this.shape_13.setTransform(44.05,9.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag0AxIATgfQAIAGAMAEQAJAEAFgBQAJABAAgGQAAgDgJgEIgSgGQgMgFgGgFQgMgJAAgRQAAgTAPgMQAOgMAYAAQAbAAATAQIgQAeQgHgGgKgEQgIgDgGAAQgKAAAAAGQAAADAIADIAQAFQAOAFAIAGQAMAJAAARQAAAWgRANQgPALgXAAQgaAAgYgSg");
	this.shape_14.setTransform(31.175,9.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAKBBIgUgrIgFAAIAAArIgrAAIAAiBIA5AAQAXAAANAJQAQAMAAAVQAAAYgVAOIAdAxgAgPgKIAKAAQAGAAADgBQAFgEAAgFQAAgGgFgDQgDgDgGAAIgKAAg");
	this.shape_15.setTransform(20.325,9.15);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBcAAIAAAiIgyAAIAAANIAuAAIAAAhIguAAIAAAPIAzAAIAAAig");
	this.shape_16.setTransform(8.2,9.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag1BBIAAiBIA4AAQAXAAANAKQAPAMAAAXQAAAVgPAMQgNALgXAAIgNAAIAAAogAgKgHIAHAAQAGAAADgCQAFgDAAgHQAAgHgFgDQgDgDgGAAIgHAAg");
	this.shape_17.setTransform(-2.875,9.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AASBBIgnhIIABAXIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_18.setTransform(-19.975,9.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgyAxQgTgSAAgfQAAgeATgTQAUgRAeAAQAfAAATARQAVATgBAeQABAfgVASQgTASgfAAQgeAAgUgSgAgUgWQgHAIAAAOQAAAMAHAJQAJAIALAAQANAAAHgIQAIgIAAgNQAAgOgIgIQgHgIgNAAQgLAAgJAIg");
	this.shape_19.setTransform(-34.55,9.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AiwBBQgIgBgCgBIACgfQAGADAEAAQABAAABAAQABAAAAAAQABgBAAAAQABAAAAAAQACgCAAgFIAAhcIArAAIAABcQAAAUgJAKQgJAJgTAAIgPgBgACtguQgDgDAAgFQAAgFADgDQADgDAFAAIAGABIAAAGQgDgCgCAAQgGAAAAAGQAAAAAAABQAAABAAAAQABABAAAAQAAABABAAQAAABAAAAQABAAAAAAQABABAAAAQABAAABAAQACAAADgDIAAAHIgBAAIgFABQgFAAgDgDgACigrIgCgNIgGANIgBAAIgFgNIgCANIgGAAIAFgWIAEAAIAFAMIAEgMIAGAAIADAWg");
	this.shape_20.setTransform(195.15,9.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(-44.2,-1.6,260.6,23.3), null);


(lib.Ctext3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgQAPQgGgFAAgKQAAgIAGgHQAGgEAKgBQAKABAHAEQAGAHAAAIQAAAKgGAFQgGAGgLgBQgKABgGgGg");
	this.shape.setTransform(145.825,-130.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhKBHIAbguQALAKARAFQANAFAHAAQAOAAAAgIQAAgFgOgFIgagIQgRgHgIgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgWArQgKgJgPgFQgMgEgIAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPABAZQAAAegYATQgWAQggAAQgnAAghgZg");
	this.shape_1.setTransform(134.7,-138.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhABdIAAi5ICBAAIAAAwIhEAAIAAAdIBAAAIAAAvIhAAAIAAA9g");
	this.shape_2.setTransform(120.125,-138.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeBdIAAi5IA9AAIAAC5g");
	this.shape_3.setTransform(107.9,-138.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhLBHIAbguQAMAKARAFQANAFAHAAQAOAAAAgIQAAgFgOgFIgZgIQgSgHgIgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgWArQgKgJgOgFQgMgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPAAAZQAAAegXATQgVAQgiAAQgmAAgigZg");
	this.shape_4.setTransform(95.7,-138.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhHBHQgdgaAAgtQAAgrAdgbQAbgZAsgBQAsABAcAZQAdAbAAArQAAAtgdAaQgcAagsAAQgsAAgbgagAgcggQgLAMAAAUQAAASALAMQALAMARAAQASAAALgMQALgMAAgSQAAgUgLgMQgLgMgSAAQgRAAgLAMg");
	this.shape_5.setTransform(77.525,-138.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag9BdIAAi5IA8AAIAACHIA/AAIAAAyg");
	this.shape_6.setTransform(61.45,-138.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgPgKIAKAAQAJAAAFgDQAGgFAAgKQAAgKgGgFQgFgDgJAAIgKAAg");
	this.shape_7.setTransform(46.1,-138.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAeBdIgeg7IgdA7IhJAAIA+hgIg6hZIBJAAIAZAyIAagyIBJAAIg7BZIA/Bgg");
	this.shape_8.setTransform(27.375,-138.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBJAAIAAAwg");
	this.shape_9.setTransform(10.1,-138.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext3, new cjs.Rectangle(0,-152.5,151.4,31), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhKBHIAbguQALAKARAFQANAFAHAAQAOAAAAgIQAAgFgOgFIgagIQgSgHgHgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgWArQgKgJgPgFQgLgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPAAAZQAAAegXATQgWAQggAAQgnAAghgZg");
	this.shape.setTransform(164.65,-164.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhCBdIAAi5ICDAAIAAAwIhHAAIAAAUIBDAAIAAAvIhDAAIAAAWIBKAAIAAAwg");
	this.shape_1.setTransform(149.55,-164.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag9BIQgegagBguQABguAegaQAbgXApAAQAhAAAXAOQAKAFANANIgpAiQgQgQgWAAQgQAAgKAMQgLAMAAAVQAAAVALANQAKAMAQAAQAWAAAEgHIAAgOIgcAAIAAgsIBYAAIAABRQgSAQgNAGQgXAMghAAQgoAAgbgYg");
	this.shape_2.setTransform(131.3,-164.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAgBdIgHgaIg0AAIgHAaIg/AAIBAi5IBCAAIBBC5gAAMAUIgNgxIgNAxIAaAAg");
	this.shape_3.setTransform(112.5,-164.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_4.setTransform(94.875,-164.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdBdIAAi5IA8AAIAAC5g");
	this.shape_5.setTransform(80.7,-164.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgdBdIhGi5IBBAAIAiBrIAjhrIBBAAIhGC5g");
	this.shape_6.setTransform(66.625,-164.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhLBHIAbguQAMAKAQAFQAOAFAHAAQAOAAAAgIQAAgFgNgFIgagIQgSgHgIgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgXArQgJgJgOgFQgMgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPAAAZQAAAegYATQgUAQgiAAQgmAAgigZg");
	this.shape_7.setTransform(43.85,-164.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBDAAIAAAvIhDAAIAAAWIBJAAIAAAwg");
	this.shape_8.setTransform(28.75,-164.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhXBdIAAi5IBGAAQAvAAAbAUQAfAYAAAwQAAAxgfAYQgbAUgvAAgAgaAqIAOAAQASAAAJgKQALgKAAgWQAAgWgLgLQgJgJgSAAIgOAAg");
	this.shape_9.setTransform(11.375,-164.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(-6,-178.7,180.7,31), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape.setTransform(169.475,-190.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag/BJQgVgUAAgpIAAhqIA+AAIAABtQAAAOAFAGQAIAHAJAAQALAAAGgHQAHgGAAgOIAAhtIA9AAIAABqQAAApgUAUQgWAWgrAAQgpAAgWgWg");
	this.shape_1.setTransform(150,-190.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhHBHQgdgbAAgsQAAgrAdgbQAbgaAsABQAsgBAcAaQAdAbAAArQAAAsgdAbQgcAZgsAAQgsAAgbgZgAgcggQgLANAAASQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgSgLgNQgLgLgSAAQgRAAgLALg");
	this.shape_2.setTransform(129.675,-190.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgQgKIAKAAQAKAAAEgDQAIgFAAgKQAAgKgIgFQgEgDgKAAIgKAAg");
	this.shape_3.setTransform(111.2,-190.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhABJQgUgUAAgpIAAhqIA+AAIAABtQAAAOAFAGQAIAHAJAAQALAAAGgHQAHgGgBgOIAAhtIA+AAIAABqQAAApgUAUQgWAWgrAAQgpAAgXgWg");
	this.shape_4.setTransform(87.2,-190.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AggBzIAVgpQgcgGgSgTQgZgaAAgpQAAgtAdgaQAbgZArAAQAqAAAUASIgQAzQgTgQgXAAQgTAAgKAKQgNAMAAAVQAAATAOALQAKAKASAAQAcAAAQgRIASAxQgSATgdADIgRAng");
	this.shape_5.setTransform(69.25,-188.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAaBdIg4hnIABAhIAABGIg7AAIAAi5IBCAAIA1BnIgBghIAAhGIA7AAIAAC5g");
	this.shape_6.setTransform(50.15,-190.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhHBHQgdgbAAgsQAAgrAdgbQAbgaAsABQAsgBAcAaQAdAbAAArQAAAsgdAbQgcAZgsAAQgsAAgbgZgAgcggQgLANAAASQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgSgLgNQgLgLgSAAQgRAAgLALg");
	this.shape_7.setTransform(29.275,-190.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag1BHQgdgaAAgtQAAgsAdgbQAcgYAqAAQAqAAAUARIgQA0QgTgRgXAAQgTAAgKALQgNALAAAVQAAATANAMQALAKASAAQAcAAAQgRIASAwQgXAYgrAAQgqAAgcgZg");
	this.shape_8.setTransform(10.85,-190.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(0,-205,179.7,31), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Isolation_Mode
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgMApIAAg8IgUAAIAAgVIBBAAIAAAVIgTAAIAAA8g");
	this.shape.setTransform(133,-96.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AAMApIgZgtIABAOIAAAfIgbAAIAAhRIAdAAIAXAtIAAgOIAAgfIAaAAIAABRg");
	this.shape_1.setTransform(125.2,-96.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AAPApIgEgLIgXAAIgCALIgcAAIAchRIAdAAIAcBRgAAGAJIgGgVIgGAVIAMAAg");
	this.shape_2.setTransform(116.45,-96.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AALApIgYgtIABAOIAAAfIgaAAIAAhRIAdAAIAXAtIgBgOIAAgfIAbAAIAABRg");
	this.shape_3.setTransform(107.7,-96.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AgdApIAAhRIA6AAIAAAVIgfAAIAAAJIAdAAIAAAUIgdAAIAAAKIAgAAIAAAVg");
	this.shape_4.setTransform(99.825,-96.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AgNApIAAg8IgTAAIAAgVIBBAAIAAAVIgUAAIAAA8g");
	this.shape_5.setTransform(93,-96.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AALApIgYgtIABAOIAAAfIgaAAIAAhRIAdAAIAXAtIgBgOIAAgfIAbAAIAABRg");
	this.shape_6.setTransform(85.2,-96.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgMApIAAhRIAZAAIAABRg");
	this.shape_7.setTransform(78.75,-96.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AAPApIgEgLIgWAAIgEALIgcAAIAdhRIAdAAIAcBRgAAGAJIgGgVIgGAVIAMAAg");
	this.shape_8.setTransform(72.6,-96.775);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#231F20").s().p("AAYApIgBguIgMAuIgVAAIgLguIgCAuIgaAAIAFhRIAjAAIAJAsIAKgsIAjAAIAFBRg");
	this.shape_9.setTransform(63.05,-96.775);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#231F20").s().p("AAGApIgMgbIgDAAIAAAbIgbAAIAAhRIAkAAQAOAAAIAGQALAHAAANQAAAQgOAIIASAfgAgJgGIAGAAIAFgBQADgCAAgEQAAgDgDgCQgCgCgDAAIgGAAg");
	this.shape_10.setTransform(51.875,-96.775);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#231F20").s().p("AgdApIAAhRIA6AAIAAAVIgfAAIAAAJIAdAAIAAAUIgdAAIAAAKIAgAAIAAAVg");
	this.shape_11.setTransform(44.225,-96.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#231F20").s().p("AgMApIAAg8IgUAAIAAgVIBBAAIAAAVIgTAAIAAA8g");
	this.shape_12.setTransform(37.4,-96.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#231F20").s().p("AgdApIAAhRIA6AAIAAAVIgfAAIAAAJIAdAAIAAAUIgdAAIAAAKIAgAAIAAAVg");
	this.shape_13.setTransform(30.775,-96.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#231F20").s().p("AALApIAAgeIgVAAIAAAeIgbAAIAAhRIAbAAIAAAeIAVAAIAAgeIAbAAIAABRg");
	this.shape_14.setTransform(22.825,-96.775);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#231F20").s().p("AgXAfQgNgLAAgUQAAgTANgMQAMgLASABQATAAAJAHIgHAXQgJgIgKAAQgIABgEAFQgGAFAAAIQAAAJAGAEQAEAFAIAAQAMAAAIgHIAIAVQgLAKgTAAQgSABgMgMg");
	this.shape_15.setTransform(14.775,-96.75);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#231F20").s().p("AAPApIgEgLIgWAAIgEALIgcAAIAdhRIAdAAIAdBRgAAGAJIgGgVIgGAVIAMAAg");
	this.shape_16.setTransform(6.9,-96.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AqmB2QgRAAgMgMQgMgMAAgRIAAiZQAAgRAMgMQAMgMARAAIVNAAQARAAAMAMQAMAMAAARIAACZQAAARgMAMQgMAMgRAAg");
	this.shape_17.setTransform(70.025,-96.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(-1.9,-108.7,143.9,23.60000000000001), null);


(lib.Btext22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgQAQQgGgGAAgKQAAgIAGgHQAGgEAKAAQAKAAAHAEQAGAHAAAIQAAAKgGAGQgGAEgLAAQgKAAgGgEg");
	this.shape.setTransform(171.475,-202.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhHBHQgdgaAAgtQAAgsAdgaQAbgZAsAAQAsAAAcAZQAdAaAAAsQAAAtgdAaQgcAagsgBQgsABgbgagAgcgfQgLAMAAASQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgSgLgMQgLgNgSAAQgRAAgLANg");
	this.shape_1.setTransform(158.575,-209.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_2.setTransform(139.875,-209.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgPgKIAKAAQAJAAAEgDQAIgFgBgKQABgKgIgFQgEgDgJAAIgKAAg");
	this.shape_3.setTransform(122.3,-209.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgdBdIAAiKIgsAAIAAgvICTAAIAAAvIgrAAIAACKg");
	this.shape_4.setTransform(100.575,-209.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhABdIAAi5ICBAAIAAAwIhEAAIAAAdIBAAAIAAAvIhAAAIAAA9g");
	this.shape_5.setTransform(85.125,-209.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgeBdIAAi5IA9AAIAAC5g");
	this.shape_6.setTransform(72.9,-209.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAZBdIAAhFIgyAAIAABFIg9AAIAAi5IA9AAIAABDIAyAAIAAhDIA+AAIAAC5g");
	this.shape_7.setTransform(58.55,-209.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhKBHIAbguQALAKARAFQANAFAHAAQAOAAAAgIQAAgFgOgFIgagIQgRgHgIgHQgRgOAAgZQAAgbAVgSQAUgQAiAAQAoAAAbAXIgYArQgJgJgPgFQgMgEgIAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQASAPAAAZQAAAegZATQgVAQggAAQgnAAghgZg");
	this.shape_8.setTransform(40.75,-209.825);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAeBdIgeg7IgdA7IhJAAIA+hgIg6hZIBJAAIAZAyIAagyIBJAAIg7BZIA/Bgg");
	this.shape_9.setTransform(18.275,-209.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_10.setTransform(-4.725,-209.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhHBHQgdgaAAgtQAAgsAdgaQAbgZAsAAQAsAAAcAZQAdAaAAAsQAAAtgdAaQgcAagsgBQgsABgbgagAgcgfQgLAMAAASQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgSgLgMQgLgNgSAAQgRAAgLANg");
	this.shape_11.setTransform(-25.125,-209.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgQgKIAKAAQAKAAAEgDQAIgFAAgKQAAgKgIgFQgEgDgKAAIgKAAg");
	this.shape_12.setTransform(-43.6,-209.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAgBdIgHgaIg0AAIgHAaIhAAAIBBi5IBCAAIBBC5gAAMAUIgNgxIgNAxIAaAAg");
	this.shape_13.setTransform(-62.2,-209.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgdBdIhGi5IBBAAIAiBrIAjhrIBBAAIhGC5g");
	this.shape_14.setTransform(-78.275,-209.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-224.2,270.7,31);


(lib.Btext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBDQgJgIAAgPQAAgOAJgIQAKgIAOAAQAQAAAJAIQAJAIAAAOQAAAPgJAIQgJAIgQAAQgOAAgKgIgAgYgVQgJgIAAgOQAAgOAJgJQAKgIAOAAQAQAAAJAIQAJAJAAAOQAAAOgJAIQgJAJgQAAQgOAAgKgJg");
	this.shape.setTransform(99.875,-214.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_1.setTransform(230.375,-216.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBJAAIAAAwg");
	this.shape_2.setTransform(213.05,-216.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag/BJQgVgUAAgpIAAhqIA9AAIAABtQABAOAFAGQAIAHAJAAQALAAAHgHQAFgGABgOIAAhtIA9AAIAABqQAAApgUAUQgWAWgrAAQgqAAgVgWg");
	this.shape_3.setTransform(195.25,-216.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAgBdIgHgaIg0AAIgHAaIg/AAIBAi5IBDAAIBBC5gAAMAUIgMgxIgPAxIAbAAg");
	this.shape_4.setTransform(176.7,-216.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhPBdIAAi5IBMAAQAeAAARAHQALAEAIAKQAIALAAAPQAAAPgIAMQgHAKgLAFQARADAJAMQAKALAAAQQAAAcgVAOQgSAMgfAAgAgTAwIAUAAQAHAAAGgDQAFgEAAgIQAAgIgFgDQgFgEgIAAIgUAAgAgTgVIAMAAQAJAAAEgDQAFgEAAgHQAAgHgFgDQgEgDgJAAIgMAAg");
	this.shape_5.setTransform(158.7,-216.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhCBdIAAi5ICDAAIAAAwIhHAAIAAAUIBDAAIAAAvIhDAAIAAAWIBKAAIAAAwg");
	this.shape_6.setTransform(136.5,-216.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag9BdIAAi5IA8AAIAACHIA/AAIAAAyg");
	this.shape_7.setTransform(121.95,-216.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgdBdIAAiKIgsAAIAAgvICTAAIAAAvIgrAAIAACKg");
	this.shape_8.setTransform(80.725,-216.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_9.setTransform(65.275,-216.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhHBHQgdgaAAgtQAAgsAdgaQAbgaAsAAQAsAAAcAaQAdAaAAAsQAAAtgdAaQgcAZgsAAQgsAAgbgZgAgcggQgLAMAAAUQAAASALAMQALAMARAAQASAAALgMQALgMAAgSQAAgUgLgMQgLgMgSABQgRgBgLAMg");
	this.shape_10.setTransform(44.875,-216.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgPgKIAJAAQAKAAAFgDQAGgFABgKQgBgKgGgFQgFgDgKAAIgJAAg");
	this.shape_11.setTransform(26.4,-216.275);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhLBHIAbguQAMAKAQAFQAOAFAHAAQAOAAAAgIQAAgFgNgFIgagIQgTgHgHgHQgRgOAAgZQAAgbAVgSQAUgQAiAAQAoAAAbAXIgYArQgJgJgOgFQgMgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQASAPAAAZQAAAegZATQgUAQgiAAQgmAAgigZg");
	this.shape_12.setTransform(9.55,-216.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btext1, new cjs.Rectangle(0,-232,240.6,32.5), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-102.8,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-276.5,222.9,31);


// stage content:
(lib.shift_300x600_fr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(141,577.2,1,1,0,0,0,62,18);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(309).to({_off:false},0).to({alpha:1},22,cjs.Ease.cubicInOut).wait(12));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(-130.95,369.5,1,1,0,0,0,84.2,10.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(292).to({_off:false},0).to({x:149.05},20,cjs.Ease.quartOut).wait(31));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(148.25,267.4,0.4,0.4,0,0,0,177.5,184.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(268).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(46));

	// skate2
	this.instance_3 = new lib.skate2();
	this.instance_3.setTransform(488,383);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(165).to({_off:false},0).to({x:164},20,cjs.Ease.quartOut).wait(69).to({regX:57,regY:62,x:221,y:445},0).to({x:546},18,cjs.Ease.quintInOut).wait(71));

	// skate1
	this.instance_4 = new lib.skate1();
	this.instance_4.setTransform(-243,368.5,1,1,0,0,0,56,61.5);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(29).to({_off:false},0).to({x:97},22,cjs.Ease.quartOut).wait(202).to({x:-206.75},18,cjs.Ease.quintInOut).wait(72));

	// cta
	this.instance_5 = new lib.CTA();
	this.instance_5.setTransform(84.45,285.9,1,1,0,0,0,62,18);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(145).to({y:252.15},23,cjs.Ease.quartInOut).wait(81).to({y:250.9,alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(76));

	// Ctext3
	this.instance_6 = new lib.Ctext3();
	this.instance_6.setTransform(-92.7,252.6,1,1,0,0,0,74.8,24);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(157).to({_off:false},0).to({x:94.8},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(81));

	// Ctet2
	this.instance_7 = new lib.Ctext2();
	this.instance_7.setTransform(-105.2,252.6,1,1,0,0,0,74.8,24);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(154).to({_off:false},0).to({x:94.8},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_8 = new lib.Ctext1();
	this.instance_8.setTransform(-92.7,252.6,1,1,0,0,0,74.8,24);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(151).to({_off:false},0).to({x:94.8},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// Btext2
	this.instance_9 = new lib.Btext22();
	this.instance_9.setTransform(-139.55,327.2);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(17).to({_off:false},0).to({x:110.05},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(194));

	// Btext1
	this.instance_10 = new lib.Btext1();
	this.instance_10.setTransform(-132,333,1,1,0,0,0,74.8,24);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(13).to({_off:false},0).to({x:94.8,y:331.8},22,cjs.Ease.quartOut).wait(93).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(197));

	// text2
	this.instance_11 = new lib.Tween2("synched",0);
	this.instance_11.setTransform(-141.95,327.2);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(9).to({_off:false},0).to({x:110.05},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_12 = new lib.text1();
	this.instance_12.setTransform(-184.8,252.6,1,1,0,0,0,74.8,24);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(5).to({_off:false},0).to({x:94.8},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// bg
	this.instance_13 = new lib.Asset1();
	this.instance_13.setTransform(0,0,0.5376,0.5405);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_13}]}).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-191,300,844.9,350.5);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/shift_300x600_fr_atlas_1.jpg", id:"shift_300x600_fr_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;