(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"fam_728x90_fr_atlas_P_1", frames: [[116,0,112,123],[0,0,114,124],[0,126,114,123]]},
		{name:"fam_728x90_fr_atlas_NP_1", frames: [[0,0,558,1110]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset1 = function() {
	this.initialize(ss["fam_728x90_fr_atlas_NP_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset2pngcopy = function() {
	this.initialize(ss["fam_728x90_fr_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset3 = function() {
	this.initialize(ss["fam_728x90_fr_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Asset4 = function() {
	this.initialize(ss["fam_728x90_fr_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLALQgFgEAAgHQAAgGAFgEQAEgEAHAAQAIAAAFAEQAEAEAAAGQAAAHgEAEQgFAEgIAAQgHAAgEgEg");
	this.shape.setTransform(359.175,-150.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgTA8IAAhZIgcAAIAAgeIBfAAIAAAeIgcAAIAABZg");
	this.shape_1.setTransform(353.725,-155.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAJA8IgSgoIgFAAIAAAoIgoAAIAAh3IA1AAQAVAAANAIQAPALAAATQAAAXgUAMIAbAugAgOgJIAKAAQAFAAADgCQAEgDAAgFQAAgFgEgDQgDgDgFAAIgKAAg");
	this.shape_2.setTransform(343.675,-155.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AguAuQgTgRAAgdQAAgcATgRQASgQAcAAQAdAAASAQQATARAAAcQAAAdgTARQgSAQgdAAQgcAAgSgQgAgSgUQgHAIAAAMQAAAMAHAHQAHAIALAAQAMAAAHgIQAHgHAAgMQAAgMgHgIQgHgIgMAAQgLAAgHAIg");
	this.shape_3.setTransform(330.475,-155.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgxA8IAAh3IA0AAQAWAAALAJQAOALAAAVQAAAUgOALQgLAKgWAAIgMAAIAAAlgAgKgGIAHAAQAFAAAEgCQAEgDAAgHQAAgHgEgCQgEgDgFAAIgHAAg");
	this.shape_4.setTransform(318.5,-155.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgwAuIASgeQAHAHALADQAJADADABQAJgBAAgFQABgDgJgDIgRgFQgLgGgFgDQgMgJAAgQQAAgSAPgLQAMgLAXAAQAZAAASAOIgQAcQgGgFgJgEQgIgCgFAAQgJAAAAAFQAAADAHACIAOAFQAOAEAGAGQAMAJAAARQAAATgQAMQgNAKgVAAQgZAAgWgQg");
	this.shape_5.setTransform(307.6,-155);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgpAvQgNgNAAgaIAAhEIAnAAIAABFQAAAJAFAFQAEAEAGAAQAHAAAEgEQAEgEAAgKIAAhFIAoAAIAABEQAAAagNANQgOAOgcAAQgbAAgOgOg");
	this.shape_6.setTransform(293,-154.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag4A8IAAh3IAuAAQAeAAARANQAUAPAAAfQAAAggUAPQgRANgeAAgAgQAbIAJAAQALAAAGgGQAHgHAAgOQAAgOgHgHQgGgGgLAAIgJAAg");
	this.shape_7.setTransform(280.65,-155.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAfg");
	this.shape_8.setTransform(265.775,-155.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgiAuQgTgRAAgdQAAgcATgRQASgQAbAAQAbAAANALIgKAhQgMgKgPAAQgMAAgHAHQgIAHAAANQAAANAJAHQAGAHAMAAQARAAALgLIAMAfQgPAPgcAAQgbAAgSgQg");
	this.shape_9.setTransform(255.175,-155.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAJA8IgSgoIgFAAIAAAoIgoAAIAAh3IA1AAQAVAAANAIQAPALAAATQAAAXgUAMIAbAugAgOgJIAKAAQAFAAADgCQAEgDAAgFQAAgFgEgDQgDgDgFAAIgKAAg");
	this.shape_10.setTransform(244.225,-155.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgpAvQgNgNAAgaIAAhEIAnAAIAABFQAAAJAFAFQAEAEAGAAQAHAAAEgEQAEgEAAgKIAAhFIAoAAIAABEQAAAagNANQgOAOgcAAQgbAAgOgOg");
	this.shape_11.setTransform(231.6,-154.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AguAuQgTgRAAgdQAAgcATgRQASgQAcAAQAdAAASAQQATARAAAcQAAAdgTARQgSAQgdAAQgcAAgSgQgAgSgUQgHAIAAAMQAAAMAHAHQAHAIALAAQAMAAAHgIQAHgHAAgMQAAgMgHgIQgHgIgMAAQgLAAgHAIg");
	this.shape_12.setTransform(218.425,-155.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgwAuIASgeQAHAHALADQAJADADABQAJgBAAgFQABgDgJgDIgQgFQgMgGgFgDQgMgJAAgQQAAgSAOgLQANgLAXAAQAZAAASAOIgQAcQgGgFgJgEQgIgCgFAAQgJAAAAAFQAAADAHACIAOAFQAOAEAHAGQALAJAAARQAAATgQAMQgNAKgWAAQgZAAgVgQg");
	this.shape_13.setTransform(206.45,-155);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAVA8IgFgRIghAAIgFARIgpAAIAqh3IArAAIAqB3gAAIANIgIgfIgJAfIARAAg");
	this.shape_14.setTransform(191.975,-155.025);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgnA8IAAh3IAnAAIAABXIAoAAIAAAgg");
	this.shape_15.setTransform(181.525,-155.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAfg");
	this.shape_16.setTransform(168.325,-155.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag4A8IAAh3IAuAAQAeAAARANQAUAPAAAfQAAAggUAPQgRANgeAAgAgQAbIAJAAQALAAAGgGQAHgHAAgOQAAgOgHgHQgGgGgLAAIgJAAg");
	this.shape_17.setTransform(157.05,-155.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgrBMIAAh4IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAggAgTgxIAMgaIAfAAIgRAag");
	this.shape_18.setTransform(142.175,-156.575);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgTA8IAAhZIgcAAIAAgeIBfAAIAAAeIgcAAIAABZg");
	this.shape_19.setTransform(132.175,-155.025);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgTA8IAAh3IAnAAIAAB3g");
	this.shape_20.setTransform(124.5,-155.025);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgSA8Igth3IApAAIAWBEIAXhEIApAAIgtB3g");
	this.shape_21.setTransform(115.35,-155.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgTA8IAAh3IAnAAIAAB3g");
	this.shape_22.setTransform(106.2,-155.025);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgwAuIARgeQAIAHALADQAIADAFABQAIgBABgFQAAgDgJgDIgQgFQgMgGgGgDQgLgJABgQQgBgSAOgLQAOgLAVAAQAaAAARAOIgPAcQgGgFgJgEQgIgCgGAAQgIAAAAAFQAAADAHACIAPAFQANAEAHAGQALAJAAARQAAATgQAMQgOAKgVAAQgYAAgWgQg");
	this.shape_23.setTransform(98.3,-155);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgpAvQgNgNAAgaIAAhEIAoAAIAABFQAAAJADAFQAFAEAGAAQAHAAAFgEQADgEAAgKIAAhFIAoAAIAABEQAAAagNANQgOAOgcAAQgbAAgOgOg");
	this.shape_24.setTransform(87.1,-154.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgnA8IAAh3IAnAAIAABXIAoAAIAAAgg");
	this.shape_25.setTransform(76.975,-155.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgiAuQgTgRAAgdQAAgcATgRQASgQAbAAQAbAAANALIgKAhQgMgKgPAAQgMAAgHAHQgIAHAAANQAAANAJAHQAGAHAMAAQARAAALgLIAMAfQgPAPgcAAQgbAAgSgQg");
	this.shape_26.setTransform(66.725,-155.025);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AATA8IgTgmIgSAmIgvAAIAng+Iglg5IAvAAIAQAgIARggIAvAAIgmA5IAoA+g");
	this.shape_27.setTransform(55.4,-155.025);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAfg");
	this.shape_28.setTransform(44.175,-155.025);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAfg");
	this.shape_29.setTransform(30.625,-155.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AARA8IgkhCIABAVIAAAtIgnAAIAAh3IArAAIAiBCIAAgVIAAgtIAmAAIAAB3g");
	this.shape_30.setTransform(18.725,-155.025);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgpAvQgNgNAAgaIAAhEIAnAAIAABFQAAAJAFAFQAEAEAGAAQAHAAAEgEQAEgEAAgKIAAhFIAoAAIAABEQAAAagNANQgOAOgcAAQgbAAgOgOg");
	this.shape_31.setTransform(5.8,-154.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(-2.5,-165,366.4,21.5), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAOIAJgbIASAAIgLAbg");
	this.shape.setTransform(404.75,-192.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAJA8IgSgoIgFAAIAAAoIgoAAIAAh3IA1AAQAVAAANAIQAPALAAATQAAAXgUAMIAbAugAgOgJIAKAAQAFAAADgCQAEgDAAgFQAAgFgEgDQgDgDgFAAIgKAAg");
	this.shape_1.setTransform(398.075,-197.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AguAuQgTgRAAgdQAAgcATgRQASgQAcAAQAdAAASAQQATARAAAcQAAAdgTARQgSAQgdAAQgcAAgSgQgAgSgUQgHAIAAAMQAAAMAHAHQAHAIALAAQAMAAAHgIQAHgHAAgMQAAgMgHgIQgHgIgMAAQgLAAgHAIg");
	this.shape_2.setTransform(384.875,-197.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgxA8IAAh3IA0AAQAVAAANAJQANALAAAVQAAAUgNALQgNAKgVAAIgMAAIAAAlgAgJgGIAGAAQAFAAAEgCQAEgDAAgHQAAgHgEgCQgEgDgFAAIgGAAg");
	this.shape_3.setTransform(372.9,-197.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAVA8IgFgRIghAAIgFARIgpAAIAqh3IArAAIAqB3gAAIANIgIgfIgJAfIARAAg");
	this.shape_4.setTransform(360.875,-197.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgSA8Igth3IApAAIAWBEIAXhEIApAAIgtB3g");
	this.shape_5.setTransform(349.15,-197.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAJA8IgSgoIgFAAIAAAoIgoAAIAAh3IA1AAQAVAAANAIQAPALAAATQAAAXgUAMIAbAugAgOgJIAKAAQAFAAADgCQAEgDAAgFQAAgFgEgDQgDgDgFAAIgKAAg");
	this.shape_6.setTransform(334.225,-197.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAfg");
	this.shape_7.setTransform(322.975,-197.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgpAvQgNgNAAgaIAAhEIAnAAIAABFQAAAJAFAFQAEAEAGAAQAHAAAEgEQAEgEAAgKIAAhFIAoAAIAABEQAAAagNANQgOAOgcAAQgbAAgOgOg");
	this.shape_8.setTransform(311.45,-197.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAVA8IgFgRIghAAIgFARIgpAAIAqh3IArAAIAqB3gAAIANIgIgfIgJAfIARAAg");
	this.shape_9.setTransform(299.425,-197.975);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgzA8IAAh3IAyAAQATAAAKAEQAIADAFAGQAFAHAAAKQAAAKgFAIQgFAGgHADQALACAGAHQAGAIAAAKQAAASgNAJQgMAIgTAAgAgMAfIANAAQAFAAADgCQAEgDAAgFQAAgFgEgCQgDgCgFAAIgNAAgAgMgNIAIAAQAFAAADgCQAEgDAAgEQAAgFgEgCQgDgCgFAAIgIAAg");
	this.shape_10.setTransform(287.725,-197.975);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgwAuIASgdQAHAFALAEQAJADADAAQAKAAgBgEQAAgEgIgDIgRgGQgLgEgGgFQgKgIgBgQQABgSAOgMQANgKAWAAQAZAAARAPIgOAcQgHgGgJgDQgIgDgFAAQgJAAAAAFQAAADAHADIAOAEQAOAEAGAGQAMAJAAAQQAAAUgPAMQgPAKgUAAQgZAAgWgQg");
	this.shape_11.setTransform(273.2,-197.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AARA8IgkhCIABAVIAAAtIgnAAIAAh3IArAAIAiBCIAAgVIAAgtIAmAAIAAB3g");
	this.shape_12.setTransform(261.625,-197.975);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgTA8IAAh3IAnAAIAAB3g");
	this.shape_13.setTransform(252.15,-197.975);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgTA8IAAhZIgcAAIAAgeIBfAAIAAAeIgcAAIAABZg");
	this.shape_14.setTransform(244.525,-197.975);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAVA8IgFgRIghAAIgFARIgpAAIAqh3IArAAIAqB3gAAIANIgIgfIgJAfIARAAg");
	this.shape_15.setTransform(235.075,-197.975);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgxA8IAAh3IA0AAQAWAAAMAJQANALAAAVQAAAUgNALQgMAKgWAAIgMAAIAAAlgAgKgGIAHAAQAGAAADgCQAEgDAAgHQAAgHgEgCQgDgDgGAAIgHAAg");
	this.shape_16.setTransform(224.65,-197.975);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAfg");
	this.shape_17.setTransform(210.475,-197.975);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ag4A8IAAh3IAuAAQAeAAARANQAUAPAAAfQAAAggUAPQgRANgeAAgAgQAbIAJAAQALAAAGgGQAHgHAAgOQAAgOgHgHQgGgGgLAAIgJAAg");
	this.shape_18.setTransform(199.2,-197.975);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAfg");
	this.shape_19.setTransform(184.325,-197.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAiA8IgBhEIgQBEIghAAIgQhEIgBBEIgnAAIAHh3IAzAAIAOBAIAPhAIAzAAIAHB3g");
	this.shape_20.setTransform(171.275,-197.975);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAiA8IgBhEIgQBEIghAAIgQhEIgBBEIgnAAIAHh3IAzAAIAOBAIAPhAIAzAAIAHB3g");
	this.shape_21.setTransform(155.625,-197.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAVA8IgFgRIghAAIgFARIgpAAIAqh3IArAAIAqB3gAAIANIgIgfIgJAfIARAAg");
	this.shape_22.setTransform(141.625,-197.975);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgnAvQgUgRAAgeQAAgdAUgRQASgPAaAAQAVAAAPAJQAGADAJAJIgbAWQgKgLgOAAQgKAAgHAIQgIAIAAANQAAAOAIAIQAHAIAKAAQAOAAACgFIAAgIIgSAAIAAgdIA5AAIAAA0QgLAKgJAEQgPAIgVAAQgZAAgSgPg");
	this.shape_23.setTransform(128.8,-197.975);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAVA8IgFgRIghAAIgFARIgpAAIAqh3IArAAIAqB3gAAIANIgIgfIgJAfIARAAg");
	this.shape_24.setTransform(112.875,-197.975);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgnA8IAAh3IAnAAIAABXIAoAAIAAAgg");
	this.shape_25.setTransform(102.425,-197.975);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAfg");
	this.shape_26.setTransform(89.225,-197.975);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAJA8IgSgoIgFAAIAAAoIgoAAIAAh3IA1AAQAVAAANAIQAPALAAATQAAAXgUAMIAbAugAgOgJIAKAAQAFAAADgCQAEgDAAgFQAAgFgEgDQgDgDgFAAIgKAAg");
	this.shape_27.setTransform(78.775,-197.975);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgSA8Iguh3IAqAAIAWBEIAXhEIAqAAIgtB3g");
	this.shape_28.setTransform(66.15,-197.975);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgpAvQgNgNAAgaIAAhEIAoAAIAABFQAAAJADAFQAFAEAGAAQAHAAAFgEQADgEAAgKIAAhFIAoAAIAABEQAAAagNANQgOAOgcAAQgbAAgOgOg");
	this.shape_29.setTransform(53.55,-197.875);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AguAuQgTgRAAgdQAAgcATgRQASgQAcAAQAdAAASAQQATARAAAcQAAAdgTARQgSAQgdAAQgcAAgSgQgAgSgUQgHAIAAAMQAAAMAHAHQAHAIALAAQAMAAAHgIQAHgHAAgMQAAgMgHgIQgHgIgMAAQgLAAgHAIg");
	this.shape_30.setTransform(40.375,-197.975);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgiAuQgTgRAAgdQAAgcATgRQASgQAbAAQAbAAANALIgKAhQgMgKgPAAQgMAAgHAHQgIAHAAANQAAANAJAHQAGAHAMAAQARAAALgLIAMAfQgPAPgcAAQgbAAgSgQg");
	this.shape_31.setTransform(28.425,-197.975);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgrBMIAAh4IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAggAgTgxIAMgaIAfAAIgRAag");
	this.shape_32.setTransform(17.775,-199.525);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("Ag4A8IAAh3IAuAAQAeAAARANQAUAPAAAfQAAAggUAPQgRANgeAAgAgQAbIAJAAQALAAAGgGQAHgHAAgOQAAgOgHgHQgGgGgLAAIgJAAg");
	this.shape_33.setTransform(6.5,-197.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(-2,-207.9,410.7,21.5), null);


(lib.skate3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset4();
	this.instance.setTransform(186,-276,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate3, new cjs.Rectangle(186,-276,62.69999999999999,67.69999999999999), null);


(lib.skate2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset3();
	this.instance.setTransform(62,-294,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate2, new cjs.Rectangle(62,-294,62.7,68.19999999999999), null);


(lib.skate1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset2pngcopy();
	this.instance.setTransform(187,-290,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate1, new cjs.Rectangle(187,-290,61.599999999999994,67.69999999999999), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgoUALCQh4g7hfhiIAAjjQBtBzBtA8QCXBUC2AAQCcAABnhxQBfhoAAiJQAAiHhhhpQhohxiXAAQgwAAgegfQgfgfAAgvQAAguAjgfQAggeAqAAIALAAQB3AABpAtQBqAuBPBUQBKBPAoBlQAoBlAABrQAADpilClQilCljpAAQi+gBifhNgAQVHkQgngmAAg7QAAg2AqgkQAngkA3AAQA2AAAoAkQApAkAAA2QAAA7gmAmQgmAmg7AAQg7AAgmgmgARFFWQgVAUAAAZQAAAgAVAVQAUAVAdAAQAdAAAUgVQAUgVAAggQAAgZgUgUQgVgTgcAAQgcAAgVATgAIvIDQgVgGgLgLIAAhAIACADQANAOAUAJQAWAJAQAAQAQAAAIgGQAIgFAAgKQAAgJgJgGQgJgGgXgJQhAgXAAg4QAAgiAYgWQAXgWAnAAQAVAAATAFQARAGAMAIIABABIAAA/IgDgDQgKgLgQgIQgSgIgPAAQgOAAgHAFQgHAGAAAJQAAAKAIAGQAGAFAXAJQAgAMASATQATAUAAAbQAAAjgZAXQgYAWgtAAQgZAAgVgHgACTHuQgQgQgGgZQgEgQAAgeIAAiLIBAAAIAACCQAAAgAHAOQAJAVAcAAQAcAAAJgVQAHgPAAgfIAAiCIBAAAIAACLQAAAegEAQQgGAZgQAQQgcAbg2AAQg2AAgcgbgAZYIDIAAjBIg1AAIAAg2ICqAAIAAA2Ig1AAIAADBgAWzIDIg9hfIAABfIhBAAIAAj3IBkAAQAVAAAPAGQAPAGALALQAKAKAFAOQAFANAAAQQAAAdgOARQgNASgbAGIBOBlgAV2F6IAMAAQATAAAKgIQAKgHAAgPQAAgQgKgHQgLgIgSAAIgMAAgAL6IDIAAj3IBmAAQAqAAAWAWQAWAUAAAoQAAAogWAVQgWAWgqAAIgmAAIAABSgAM6F9IAVAAQAkAAAAgfQAAgegkAAIgVAAgAiWIDIAAj3IBbAAQA0AAAjAjQAlAkAAA0QAAA0glAkQgjAkg0AAgAhWHMIAOAAQAfAAATgQQAVgSAAgjQAAgggTgTQgTgSggAAIgPAAgEgjhAFXQh3AAhpgtQhqgthPhVQhJhOgphlQgohmAAhrQAAjpClilQClilDpAAQEYADDLCgIAADeQhrhdhzgtQhzgsiFAAQicAAhnBxQhfBoAACJQAACHBhBpQBoBxCXAAQAvAAAfAfQAfAfAAAvQAAAtgjAgQghAegpAAgAdBE0QgHgHAAgJQAAgKAHgHQAGgGAJAAQAGAAAFACIAAAOQgEgFgGAAQgLAAAAAMQAAAFADADQADAEAFAAQAFAAAFgFIAAANIgBABIgKABQgJAAgGgGgAcqE5IgEgZIgKAZIgFAAIgJgZIgEAZIgLAAIAHgrIALAAIAJAXIAJgXIALAAIAHArgEAipgASQgvgTgngjQhQhIAAh0QAAgzATgvQATgvAjgkQAlgmAygVQAygWA0AAQA4AAA+AZIAACbQgTgagfgPQgegOghAAQg7AAglAoQglAoAAA6QAAA7AlAmQAmAmA8AAQAfAAAegOQAdgOAVgZIAACbIg6ARQgdAFgbAAQg0AAgwgSgAHVhLQhNhMAAh3QAAhsBThJQBPhHBtAAQBtAABPBHQBTBJAABsQAAB3hNBMQhMBLh2AAQh2AAhMhLgAI2lnQgpAnAAAzQAAA+ApAqQAoAqA5AAQA6AAAogqQAogqAAg+QAAgzgognQgqgng4AAQg4AAgpAngAANgOQgpgOgUgTIgBgBIAAh/IAEAFQAXAbApATQAqASAhAAQAfAAASgLIgBAAQARgLAAgTQAAgTgSgMQgQgMgwgRIABAAQh/gvAAhvQAAhDAwgsQAtgsBNAAQAqAAAlALIAAABQAkAMAWAPIABABIAAB9IgFgEQgTgXgigQQgigQgeAAQgbAAgPALQgOALAAASQAAATAPAMQAQANAqAQQA/AWAlAnQAmAnAAA2QAABGgxAtQgyAshYAAQg1AAgngNgASJgPQgugOgdgdQghgggLgwQgIghAAg7IAAkUICAAAIAAECQAAA/AMAcQATAqA3AAQA3AAATgqQANgcAAg/IAAkCIB/AAIAAEUQAAA8gHAgQgLAwghAgQgdAdguAOQgoAMgwAAQgvAAgogMgEAn+gAQIAAnqIEXAAIAABsIiXAAIAABSICPAAIAABsIiPAAIAABUICXAAIAABsgAcvgQIh5i8IgBAAIAAC8Ih/AAIAAnqIC+AAQBNAAAsAkQAxAoAABLQAAA0gbAmQgdAngzAJICaDJgAa1keIAMAAQAnAAAVgLQAdgPAAgkQAAgkgdgOQgVgLgnAAIgMAAgAnogQIgfhVIiwAAIgiBVIiHAAIC9nqICLAAIC4HqgAqUjHIBqAAIg0icIgBAAgAzegQIAAnqIB/AAIAAF+ICZAAIAABsg");
	this.shape.setTransform(17.7954,-381.3555,0.6244,0.6244);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(-159.3,-430.3,354.3,97.90000000000003), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgQAQQgGgGAAgKQAAgJAGgFQAGgGAKABQAKgBAHAGQAGAFAAAJQAAAKgGAGQgHAEgKAAQgKAAgGgEg");
	this.shape.setTransform(369.5,-313.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgsAzQgOgOAAgdIAAhJIArAAIAABMQAAAJAEAEQAFAFAGAAQAIAAAEgFQAEgEAAgJIAAhMIArAAIAABJQAAAdgOAOQgPAPgeAAQgdAAgPgPg");
	this.shape_1.setTransform(359.725,-317.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBcAAIAAAiIgyAAIAAANIAvAAIAAAhIgvAAIAAAPIAzAAIAAAig");
	this.shape_2.setTransform(347.7,-317.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AASBBIgnhHIABAWIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_3.setTransform(325.025,-317.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgyAxQgTgSgBgfQABgeATgTQAUgRAeAAQAfAAAUARQATATABAeQgBAfgTASQgUASgfAAQgeAAgUgSgAgTgWQgIAIAAAOQAAAMAIAJQAIAIALAAQAMAAAIgIQAHgIAAgNQAAgOgHgIQgIgIgMAAQgLAAgIAIg");
	this.shape_4.setTransform(310.45,-317.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgVBBIAAhgIgeAAIAAghIBnAAIAAAhIgfAAIAABgg");
	this.shape_5.setTransform(298.65,-317.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBbAAIAAAiIgwAAIAAANIAuAAIAAAhIguAAIAAAPIAyAAIAAAig");
	this.shape_6.setTransform(284.55,-317.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag0AxIATgfQAIAGAMAEQAJADAFAAQAJABAAgGQAAgDgJgEIgSgGQgMgFgGgFQgMgIAAgSQAAgTAPgMQAOgMAYAAQAbAAATAQIgQAeQgHgGgKgDQgIgEgGAAQgKAAAAAGQAAADAIADIAQAEQAOAFAIAGQAMAKAAARQAAAWgRAMQgPAMgXAAQgaAAgYgSg");
	this.shape_7.setTransform(273.475,-317.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUBBIAAiBIApAAIAACBg");
	this.shape_8.setTransform(265.175,-317.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgqBBIAAiBIAqAAIAABeIArAAIAAAjg");
	this.shape_9.setTransform(257.625,-317.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAXBBIgFgSIgkAAIgFASIgtAAIAuiBIAuAAIAtCBgAAJAOIgJgiIgJAiIASAAg");
	this.shape_10.setTransform(245.625,-317.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AASBBIgnhHIABAWIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_11.setTransform(231.825,-317.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AASBBIgnhHIABAWIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_12.setTransform(217.525,-317.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgxAxQgVgSABgfQgBgeAVgTQATgRAeAAQAfAAATARQAVATgBAeQABAfgVASQgTASgfAAQgeAAgTgSgAgUgWQgHAIAAAOQAAAMAHAJQAJAIALAAQANAAAHgIQAIgIAAgNQAAgOgIgIQgHgIgNAAQgLAAgJAIg");
	this.shape_13.setTransform(202.95,-317.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag0AxIATgfQAIAGAMAEQAJADAFAAQAJABAAgGQAAgDgJgEIgSgGQgMgFgGgFQgMgIAAgSQAAgTAPgMQAOgMAYAAQAbAAATAQIgQAeQgHgGgKgDQgIgEgGAAQgKAAAAAGQAAADAIADIAQAEQAOAFAIAGQAMAKAAARQAAAWgRAMQgPAMgXAAQgaAAgYgSg");
	this.shape_14.setTransform(190.075,-317.75);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAKBBIgUgrIgFAAIAAArIgrAAIAAiBIA5AAQAXAAANAJQAQALAAAWQAAAZgVAMIAdAygAgPgKIAKAAQAGAAADgCQAFgDAAgGQAAgFgFgEQgDgCgGAAIgKAAg");
	this.shape_15.setTransform(179.225,-317.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBbAAIAAAiIgwAAIAAANIAuAAIAAAhIguAAIAAAPIAyAAIAAAig");
	this.shape_16.setTransform(167.1,-317.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag1BBIAAiBIA4AAQAXAAANAKQAPAMAAAXQAAAWgPALQgNAKgXAAIgNAAIAAApgAgKgGIAHAAQAGAAADgDQAFgDAAgHQAAgIgFgDQgDgCgGAAIgHAAg");
	this.shape_17.setTransform(156.025,-317.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AASBBIgnhHIABAWIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_18.setTransform(138.925,-317.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgxAxQgVgSAAgfQAAgeAVgTQATgRAeAAQAfAAAUARQATATAAAeQAAAfgTASQgUASgfAAQgeAAgTgSgAgTgWQgIAIAAAOQAAAMAIAJQAHAIAMAAQAMAAAIgIQAHgIAAgNQAAgOgHgIQgIgIgMAAQgMAAgHAIg");
	this.shape_19.setTransform(124.35,-317.775);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AiuBCIgKgDIACgfQAGADAFAAQADAAACgCQACgBAAgFIAAhcIAqAAIAABcQAAAVgJAJQgIAKgTAAIgQgBgACsgvQgDgDAAgFQAAgEADgEQADgDAFAAIAFABIAAAGQgCgCgDAAQgFAAAAAGQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQABABAAAAQAAAAABABQAAAAABAAQABAAAAAAQADAAACgDIAAAIIAAAAIgFAAQgFAAgDgDgAChgsIgCgMIgGAMIgCAAIgEgMIgCAMIgGAAIAEgVIAFAAIAFALIAEgLIAGAAIADAVg");
	this.shape_20.setTransform(354.175,-317.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(114.7,-328.6,260.6,23.30000000000001), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJAKQgFgEAAgGQAAgFAFgEQAEgDAFAAQAHAAAEADQAEAEAAAFQAAAGgEAEQgEADgHAAQgFAAgEgDg");
	this.shape.setTransform(156.975,-173.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUA8IgUgmIgSAmIgwAAIApg+Igng5IAwAAIAQAgIARggIAvAAIgmA5IApA+g");
	this.shape_1.setTransform(148.6,-178.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgTA8IAAh3IAnAAIAAB3g");
	this.shape_2.setTransform(139.45,-178.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAJA8IgSgoIgFAAIAAAoIgoAAIAAh3IA1AAQAVAAANAIQAPALAAATQAAAXgUAMIAbAugAgOgJIAKAAQAFAAADgCQAEgDAAgFQAAgFgEgDQgDgDgFAAIgKAAg");
	this.shape_3.setTransform(131.375,-178.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgxA8IAAh3IA0AAQAVAAANAJQANALAAAVQAAAUgNALQgNAKgVAAIgMAAIAAAlgAgJgGIAGAAQAFAAAEgCQAEgDAAgHQAAgHgEgCQgEgDgFAAIgGAAg");
	this.shape_4.setTransform(120,-178.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAJA8IgSgoIgFAAIAAAoIgoAAIAAh3IA1AAQAVAAANAIQAPALAAATQAAAXgUAMIAbAugAgOgJIAKAAQAFAAADgCQAEgDAAgFQAAgFgEgDQgDgDgFAAIgKAAg");
	this.shape_5.setTransform(105.525,-178.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgpAvQgNgNAAgaIAAhEIAnAAIAABFQABAJADAFQAFAEAGAAQAHAAAEgEQAEgEAAgKIAAhFIAoAAIAABEQAAAagNANQgOAOgcAAQgbAAgOgOg");
	this.shape_6.setTransform(92.9,-178.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAfg");
	this.shape_7.setTransform(81.675,-178.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgnA8IAAh3IAnAAIAABXIAoAAIAAAgg");
	this.shape_8.setTransform(72.225,-178.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgnA8IAAh3IAnAAIAABXIAoAAIAAAgg");
	this.shape_9.setTransform(63.125,-178.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgTA8IAAh3IAnAAIAAB3g");
	this.shape_10.setTransform(55.4,-178.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAfg");
	this.shape_11.setTransform(47.625,-178.575);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAiA8IgBhEIgQBEIghAAIgQhEIgBBEIgnAAIAHh3IAzAAIAOBAIAPhAIAzAAIAHB3g");
	this.shape_12.setTransform(34.575,-178.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgpAvQgNgNAAgaIAAhEIAnAAIAABFQAAAJAFAFQAEAEAGAAQAHAAAEgEQAEgEAAgKIAAhFIAoAAIAABEQAAAagNANQgOAOgcAAQgbAAgOgOg");
	this.shape_13.setTransform(17.05,-178.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAVA8IgFgRIghAAIgFARIgpAAIAqh3IArAAIAqB3gAAIANIgIgfIgJAfIARAAg");
	this.shape_14.setTransform(5.025,-178.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(-3.2,-188.5,164.5,21.5), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgrBZIADgsQAIADAHAAQAJAAAAgLIAAiBIA8AAIAACBQAAAdgOAOQgNANgZAAQgaAAgJgEg");
	this.shape.setTransform(79.4133,-197.9971,0.6545,0.6545);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgTA8IAAhZIgcAAIAAgeIBfAAIAAAeIgcAAIAABZg");
	this.shape_1.setTransform(158.425,-198.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AARA8IgkhCIABAVIAAAtIgnAAIAAh3IArAAIAiBCIAAgVIAAgtIAmAAIAAB3g");
	this.shape_2.setTransform(146.925,-198.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAfg");
	this.shape_3.setTransform(135.375,-198.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAiA8IgBhEIgQBEIghAAIgQhEIgBBEIgnAAIAHh3IAzAAIAOBAIAPhAIAzAAIAHB3g");
	this.shape_4.setTransform(122.325,-198.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgTA8IAAhZIgcAAIAAgeIBfAAIAAAeIgcAAIAABZg");
	this.shape_5.setTransform(109.725,-198.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgwAuIARgeQAIAHALADQAIAEAFAAQAIAAABgGQAAgDgJgDIgQgFQgMgFgFgEQgLgJAAgRQAAgRANgLQAOgLAVAAQAaAAARAOIgPAcQgGgFgJgEQgIgCgGAAQgIAAAAAFQAAADAHACIAPAFQANAFAHAFQALAJAAARQAAASgQANQgOAKgVAAQgZAAgVgQg");
	this.shape_6.setTransform(100,-198);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpAvQgNgNAAgaIAAhEIAnAAIAABFQABAJAEAFQAEAEAGAAQAHAAAEgEQAEgEAAgKIAAhFIAoAAIAABEQAAAagNANQgOAOgcAAQgbAAgOgOg");
	this.shape_7.setTransform(88.8,-197.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAVA8IgFgRIghAAIgFARIgpAAIAqh3IArAAIAqB3gAAIANIgIgfIgJAfIARAAg");
	this.shape_8.setTransform(69.525,-198.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AARA8IgkhCIABAVIAAAtIgnAAIAAh3IArAAIAiBCIAAgVIAAgtIAmAAIAAB3g");
	this.shape_9.setTransform(53.225,-198.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AguAuQgTgRAAgdQAAgcATgRQASgQAcAAQAdAAASAQQATARAAAcQAAAdgTARQgSAQgdAAQgcAAgSgQgAgSgUQgHAIAAAMQAAAMAHAHQAHAIALAAQAMAAAHgIQAHgHAAgMQAAgMgHgIQgHgIgMAAQgLAAgHAIg");
	this.shape_10.setTransform(39.725,-198.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgzA8IAAh3IAyAAQATAAAKAEQAIADAFAGQAFAHAAAKQAAAKgFAIQgFAGgHADQALACAGAHQAGAIAAAKQAAASgNAJQgMAIgTAAgAgMAfIANAAQAFAAADgCQAEgDAAgFQAAgFgEgCQgDgCgFAAIgNAAgAgMgNIAIAAQAFAAADgCQAEgDAAgEQAAgFgEgCQgDgCgFAAIgIAAg");
	this.shape_11.setTransform(27.325,-198.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgrA8IAAh3IBVAAIAAAfIgtAAIAAANIArAAIAAAeIgrAAIAAAOIAvAAIAAAfg");
	this.shape_12.setTransform(12.925,-198.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgnA8IAAh3IAnAAIAABXIAoAAIAAAgg");
	this.shape_13.setTransform(3.475,-198.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(-3.4,-208,168.8,21.5), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgPAwIAAhGIgWAAIAAgZIBLAAIAAAZIgWAAIAABGg");
	this.shape.setTransform(521.275,-221.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AANAwIgcg1IABARIAAAkIgfAAIAAhfIAiAAIAbA0IgBgQIAAgkIAfAAIAABfg");
	this.shape_1.setTransform(512.225,-221.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AARAwIgEgOIgaAAIgEAOIghAAIAihfIAhAAIAiBfgAAGAKIgGgYIgHAYIANAAg");
	this.shape_2.setTransform(502.025,-221.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AANAwIgcg1IABARIAAAkIgfAAIAAhfIAiAAIAbA0IgBgQIAAgkIAfAAIAABfg");
	this.shape_3.setTransform(491.875,-221.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AghAwIAAhfIBCAAIAAAZIgkAAIAAAKIAiAAIAAAYIgiAAIAAALIAlAAIAAAZg");
	this.shape_4.setTransform(482.75,-221.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AgPAwIAAhGIgWAAIAAgZIBLAAIAAAZIgWAAIAABGg");
	this.shape_5.setTransform(474.825,-221.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AANAwIgcg1IABARIAAAkIgfAAIAAhfIAiAAIAbA0IgBgQIAAgkIAfAAIAABfg");
	this.shape_6.setTransform(465.775,-221.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgPAwIAAhfIAfAAIAABfg");
	this.shape_7.setTransform(458.25,-221.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AARAwIgEgOIgaAAIgEAOIghAAIAihfIAhAAIAiBfgAAGAKIgGgYIgHAYIANAAg");
	this.shape_8.setTransform(451.125,-221.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#231F20").s().p("AAbAwIgBg2IgMA2IgaAAIgNg2IgBA2IgfAAIAGhfIAoAAIALAzIAMgzIAoAAIAGBfg");
	this.shape_9.setTransform(440,-221.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#231F20").s().p("AAHAwIgOggIgEAAIAAAgIgfAAIAAhfIApAAQARAAAKAHQAMAIAAAQQAAASgQAJIAVAlgAgLgHIAIAAQAEAAACgBQADgDAAgEQAAgEgDgCQgDgCgDAAIgIAAg");
	this.shape_10.setTransform(426.975,-221.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#231F20").s().p("AgiAwIAAhfIBEAAIAAAZIgkAAIAAAKIAhAAIAAAYIghAAIAAALIAlAAIAAAZg");
	this.shape_11.setTransform(418.1,-221.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#231F20").s().p("AgPAwIAAhGIgWAAIAAgZIBLAAIAAAZIgWAAIAABGg");
	this.shape_12.setTransform(410.175,-221.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#231F20").s().p("AghAwIAAhfIBCAAIAAAZIgkAAIAAAKIAiAAIAAAYIgiAAIAAALIAmAAIAAAZg");
	this.shape_13.setTransform(402.5,-221.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#231F20").s().p("AANAwIAAgkIgZAAIAAAkIgfAAIAAhfIAfAAIAAAjIAZAAIAAgjIAfAAIAABfg");
	this.shape_14.setTransform(393.225,-221.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#231F20").s().p("AgbAlQgPgOAAgXQAAgWAPgOQAPgMAVAAQAVAAALAJIgJAaQgKgIgMAAQgJAAgFAFQgGAGAAAKQgBAKAIAGQAFAFAIAAQAOAAAKgJIAJAZQgMAMgWAAQgVAAgPgMg");
	this.shape_15.setTransform(383.9,-221.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#231F20").s().p("AARAwIgEgOIgaAAIgEAOIghAAIAihfIAhAAIAiBfgAAGAKIgGgYIgHAYIANAAg");
	this.shape_16.setTransform(374.725,-221.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("As+CMQgQgBgMgLQgMgMAAgRIAAjGQAAgQAMgMQAMgMAQABIZ8AAQARgBAMAMQAMAMAAAQIAADGQAAARgMAMQgMALgRABg");
	this.shape_17.setTransform(447.125,-221.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(360.1,-235.4,174.10000000000002,27.900000000000006), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-98.6,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92.5,-287.6,366.4,21.5);


// stage content:
(lib.fam_728x90_fr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(184.8,315,1.12,1.12,0,0,0,62,18.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(290).to({_off:false},0).to({alpha:1},28,cjs.Ease.quartInOut).wait(25));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(166.9,413.9,1.12,1.12,0,0,0,84.2,10.6);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(273).to({_off:false},0).to({alpha:1},27,cjs.Ease.quartInOut).wait(43));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(166.05,299.5,0.448,0.448,0,0,0,177.6,184.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(256).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(58));

	// skate3
	this.instance_3 = new lib.skate3();
	this.instance_3.setTransform(592.95,386.15,1.12,1.12,0,0,0,57,61.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({x:499.95},20,cjs.Ease.quartOut).wait(176).to({x:592.95},18,cjs.Ease.quintInOut).wait(81));

	// skate2
	this.instance_4 = new lib.skate2();
	this.instance_4.setTransform(724.05,406.25,1.12,1.12,0,0,0,57,62);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({_off:false},0).to({x:564.4},20,cjs.Ease.quartOut).wait(179).to({x:727.15},18,cjs.Ease.quintInOut).wait(82));

	// skate1
	this.instance_5 = new lib.skate1();
	this.instance_5.setTransform(583.05,401.85,1.12,1.12,0,0,0,56.1,61.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(40).to({_off:false},0).to({x:350.55},20,cjs.Ease.quartOut).wait(182).to({x:583.05},18,cjs.Ease.quintInOut).wait(83));

	// Ctet2
	this.instance_6 = new lib.Ctext2();
	this.instance_6.setTransform(-97.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(154).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_7 = new lib.Ctext1();
	this.instance_7.setTransform(-132.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(151).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// text2
	this.instance_8 = new lib.Tween2("synched",0);
	this.instance_8.setTransform(-158.95,366.45,1.12,1.12);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(9).to({_off:false},0).to({x:123.25},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_9 = new lib.text1();
	this.instance_9.setTransform(-206.95,282.9,1.12,1.12,0,0,0,74.8,24);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(5).to({_off:false},0).to({x:106.15},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// bg
	this.instance_10 = new lib.Asset1();
	this.instance_10.setTransform(728,0,0.6198,0.6558,90);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(70.9,45,736.8000000000001,300.9);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/fam_728x90_fr_atlas_P_1.png", id:"fam_728x90_fr_atlas_P_1"},
		{src:"images/fam_728x90_fr_atlas_NP_1.jpg", id:"fam_728x90_fr_atlas_NP_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;