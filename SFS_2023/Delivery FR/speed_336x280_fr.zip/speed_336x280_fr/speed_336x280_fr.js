(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"speed_336x280_fr_atlas_P_1", frames: [[0,0,450,377]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset6tearBB = function() {
	this.initialize(ss["speed_336x280_fr_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOANQgGgEAAgJQAAgHAGgGQAGgEAIAAQAJAAAGAEQAGAGAAAHQAAAJgGAEQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(22.575,-203.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag0BPIAAidIA0AAIAABzIA1AAIAAAqg");
	this.shape_1.setTransform(14.075,-209.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAPAJALQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_2.setTransform(-1.425,-209.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgGgFgEQgEgDgHAAIgNAAg");
	this.shape_3.setTransform(-17.325,-209.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_4.setTransform(-31.975,-209.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAWBPIgwhXIABAcIAAA7IgyAAIAAidIA4AAIAtBXIgBgcIAAg7IAzAAIAACdg");
	this.shape_5.setTransform(-47,-209.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAPAJALQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_6.setTransform(-64.825,-209.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgtA8QgZgWAAgmQAAglAZgXQAYgVAjAAQAkAAARAPIgNAsQgQgOgUAAQgQAAgJAIQgKAKAAASQAAAQALAKQAJAJAPAAQAXAAAPgOIAPAoQgUAVglAAQgjAAgYgWg");
	this.shape_7.setTransform(-80.475,-209.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-221.9,117.8,27);


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag2A+QgRgSAAgiIAAhaIA0AAIAABcQAAANAFAEQAGAHAIAAQAJAAAGgHQAFgEAAgNIAAhcIA0AAIAABaQAAAigRASQgSATglAAQgjAAgTgTg");
	this.shape.setTransform(154.825,-149.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhKBPIAAidIA8AAQAoAAAWARQAbAUAAApQAAAqgbAUQgWARgoAAgAgWAkIAMAAQAPAAAIgJQAJgJAAgSQAAgTgJgJQgIgIgPAAIgMAAg");
	this.shape_1.setTransform(138.625,-150.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApg");
	this.shape_2.setTransform(119.15,-150.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgtA9QgZgXAAgmQAAgmAZgWQAYgVAjAAQAkAAARAPIgNArQgQgNgUAAQgQAAgJAJQgKAJAAASQAAARALAJQAJAJAPAAQAXAAAPgPIAPAqQgUAUglAAQgjAAgYgVg");
	this.shape_3.setTransform(105.175,-150);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgGgFgEQgEgDgHAAIgNAAg");
	this.shape_4.setTransform(90.825,-150.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag2A+QgRgSAAgiIAAhaIA0AAIAABcQAAANAFAEQAGAHAIAAQAJAAAGgHQAFgEAAgNIAAhcIA0AAIAABaQAAAigRASQgSATglAAQgjAAgTgTg");
	this.shape_5.setTransform(74.225,-149.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAPAJALQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_6.setTransform(56.875,-150.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag/A8IAWgnQALAJAOAFQALAEAGAAQALAAAAgHQAAgFgLgEIgWgHQgPgGgHgFQgPgMAAgVQAAgYATgPQARgOAdAAQAhAAAYAUIgUAkQgJgHgMgEQgKgEgHAAQgMAAAAAHQAAADAKAEIATAGQASAGAIAHQAPAMABAWQgBAZgUAQQgSAOgdAAQggAAgcgWg");
	this.shape_7.setTransform(41.15,-149.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAcBPIgHgWIgsAAIgGAWIg2AAIA3idIA5AAIA3CdgAAKARIgKgpIgMApIAWAAg");
	this.shape_8.setTransform(22.125,-150.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag0BPIAAidIA0AAIAABzIA1AAIAAAqg");
	this.shape_9.setTransform(8.425,-150.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(0,-162.5,165.3,27), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAcBjIgHgWIgsAAIgGAWIg2AAIA3idIA5AAIA3CdgAAKAlIgKgpIgMApIAWAAgAgPhBIgWgiIApAAIAQAig");
	this.shape.setTransform(191.825,-200.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag5BjIAAidIBwAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApgAgZhBIAPgiIApAAIgWAig");
	this.shape_1.setTransform(172.8,-200.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_2.setTransform(159.575,-198.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgZBPIAAidIAzAAIAACdg");
	this.shape_3.setTransform(149.55,-198.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgZBPIg7idIA3AAIAdBbIAehbIA3AAIg8Cdg");
	this.shape_4.setTransform(137.55,-198.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgZBPIAAidIAzAAIAACdg");
	this.shape_5.setTransform(125.55,-198.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag/A8IAWgnQALAJAOAFQALAEAGAAQALAAAAgHQAAgFgLgEIgWgHQgPgGgHgFQgPgMAAgVQABgYASgPQAQgOAeAAQAiAAAWAUIgTAkQgJgHgLgEQgLgEgHAAQgMAAAAAHQAAADAKAEIATAGQASAGAIAHQAQAMgBAWQAAAZgUAQQgSAOgcAAQghAAgcgWg");
	this.shape_6.setTransform(115.15,-198.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag2A+QgRgSAAgiIAAhaIA0AAIAABcQAAAMAFAFQAGAHAIgBQAJABAGgHQAFgFAAgMIAAhcIA0AAIAABaQAAAigRASQgSATglgBQgjABgTgTg");
	this.shape_7.setTransform(100.425,-198.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag0BPIAAidIA0AAIAABzIA1AAIAAAqg");
	this.shape_8.setTransform(87.125,-198.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgtA9QgZgXAAgmQAAglAZgXQAYgVAjAAQAkAAARAPIgNArQgQgNgUAAQgQAAgJAJQgKAKAAARQAAARALAJQAJAJAPAAQAXAAAPgPIAPAqQgUAUglAAQgjAAgYgVg");
	this.shape_9.setTransform(73.625,-198.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAZBPIgZgyIgYAyIg/AAIA1hSIgyhLIA+AAIAWAqIAWgqIA+AAIgyBLIA2BSg");
	this.shape_10.setTransform(58.8,-198.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApg");
	this.shape_11.setTransform(44.1,-198.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAWBPIgvhXIABAcIAAA7IgzAAIAAidIA5AAIAtBXIgBgcIAAg7IAyAAIAACdg");
	this.shape_12.setTransform(24.05,-198.525);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApg");
	this.shape_13.setTransform(8.9,-198.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(0,-211,202.2,27), null);


(lib.rip = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset6tearBB();
	this.instance.setTransform(-7,0,0.6673,0.6673);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rip, new cjs.Rectangle(-7,0,300.3,251.6), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AD6W3QgngnAAg6QAAg3AqgkQAngkA3AAQA2AAAoAkQApAkAAA3QAAA6gmAnQgmAmg7AAQg7AAgmgmgAEqUpQgVATAAAaQAAAfAVAVQAUAVAdgBQAdABAUgVQAUgVAAgfQAAgagUgTQgVgUgcAAQgcAAgVAUgAjrXVQgVgGgLgLIAAAAIAAhAIACADQAMANAVAKQAVAJARAAQARAAAHgGQAIgEAAgKQAAgKgJgGQgGgFgagKQhAgYAAg3QAAgiAYgWQAYgXAmABQAWgBASAHQATAGAKAHIAAABIAAA/IgCgCQgJgLgRgJQgTgIgOAAQgOAAgHAFQgHAGAAAJQAAAKAIAGQAGAGAXAIQAfAMATATQATAUAAAbQAAAjgZAXQgZAWgsAAQgaAAgUgHgAqHXAQgQgQgGgZQgEgQAAgeIAAiLIBAAAIAACCQAAAfAHAOQAKAWAbAAQAcAAAJgWQAHgOAAgfIAAiCIBAAAIAACLQAAAegEAQQgGAZgQAQQgcAbg2ABQg2gBgcgbgAM9XVIAAjAIg1AAIAAg3ICqAAIAAA3Ig1AAIAADAgAKYXVIg+hfIAABfIhAAAIAAj3IBkAAQAVAAAPAGQAPAGALAKQAJAKAGAPQAFANAAAQQAAAdgOARQgMARgcAHIBOBlgAJaVMIANAAQATABAKgJQAKgHAAgPQAAgPgKgIQgKgHgTgBIgNAAgAggXVIAAj3IBlAAQApAAAXAVQAWAWAAAoQAAAngWAWQgWAVgqAAIgmAAIAABSgAAfVPIAVAAQAkAAAAgeQAAgfgkAAIgVAAgAuxXVIAAj3IBbAAQA0AAAkAkQAlAkAAAzQAAA1glAjQgkAkg0AAgAtxWeIAOAAQAfAAATgQQAVgTAAgiQAAgggTgSQgTgTggABIgPAAgAQmUEQgHgHAAgKQAAgJAHgHQAHgGAJAAQAFAAAFACIAAANQgEgEgGAAQgFgBgDAEQgDAEAAAEQAAAFADAEQADADAFAAQAFABAFgFIAAANIgBAAIgJACQgJAAgHgGgAQPUJIgEgYIgKAYIgEAAIgKgYIgEAYIgLAAIAHgrIALAAIAJAXIAJgXIALAAIAHArgAWOO/QgwgSgmgkQhQhHAAh0QAAg0ATgvQATgvAjgkQAlglAygWQAygWA0ABQA4AAA+AZIAACbQgTgbgfgPQgegOghABQg7gBglAoQglAnAAA7QAAA8AlAlQAmAmA8AAQAfAAAegOQAdgOAVgZIAACbQgnANgTADQgdAHgbAAQg0AAgwgTgAlFOGQhNhMAAh2QAAhsBThKQBPhGBtAAQBtAABOBGQBTBKAABsQAAB2hNBMQhLBMh2AAQh2AAhMhMgAjlJqQgoAnAAAzQAAA+AoArQAoApA6AAQA5AAApgpQAngrAAg+QAAgzgngnQgqgng4AAQg4AAgqAngAsNPDQgpgNgVgUIgBgBIAAh/IAEAGQAXAaAqATQAqASAhAAQAfABASgLIgBAAQARgMAAgTQAAgUgSgLIAAAAQgQgLgwgSIABAAQiAgvAAhvQAAhDAwgsQAugsBNAAQAqAAAlALIAAABQAkAMAWAPIABACIAAB8IgFgEQgTgWgigQQgigRgeAAQgbAAgPALQgOALAAASQAAATAPANQAQANAqAPQA/AWAlAnQAmAnAAA2QAABGgxAuQgyArhYABQgygBgqgNgAFuPCQgugOgdgdQghgfgLgxQgIghAAg8IAAkTICAAAIAAECQAAA/AMAcQATAqA3AAQA3AAATgqQANgcAAg/IAAkCIB/AAIAAETQAAA9gHAgQgLAxghAfQgdAdguAOQgoAMgwAAQgvAAgogMgAbjPBIAAnqIEXAAIAABsIiXAAIAABSICPAAIAABsIiPAAIAABUICXAAIAABsgAQUPBIh5i9IgBAAIAAC9Ih/AAIAAnqIC+AAQBNAAAsAkQAxAnAABMQAAA1gbAlQgdAngzAKICaDIgAOaKzIAMAAQAnAAAVgKQAdgPAAglQAAgjgdgPQgVgLgnAAIgMAAgA0DPBIgfhVIiwAAIgiBVIiHAAIC9nqICLAAIC4HqgA2vMLIBqAAIg0idIgBAAgA/5PBIAAnqIB/AAIAAF+ICZAAIAABsgAlHgKQh4g6hfhiIAAjkQBsB0BtA8QCYBUC0AAQCcAABohxQBfhoAAiJQAAiIhhhqQhohwiXAAQgvAAgfgfQgegfAAgwQAAgtAiggQAhgdApAAIALAAQB3AABpAtQBqAtBPBVQBJBPApBlQAoBmAABqQAADpilClQilCljpAAQi9gBifhNgAgUl0Qh3gBhqgsQhpguhPhUQhKhPgohlQgohmAAhrQAAjpClilQClilDpAAQEWACDMChIAADeQhrhehzgsQhzgtiEAAQicAAhnByQhfBoAACIQAACIBhBpQBoByCXAAQAugBAfAgQAfAfAAAvQAAAsgjAgQghAfgoAAg");
	this.shape.setTransform(176.3876,-251.1586,0.8689,0.8689);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(-1,-381.5,354.9,260.7), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJAKQgFgEAAgGQAAgFAFgEQAEgDAFAAQAHAAADADQAFAEAAAFQAAAGgFAEQgDADgHAAQgFAAgEgDg");
	this.shape.setTransform(163.75,-195.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgcAgQgJgJAAgSIAAguIAbAAIAAAvQAAAHADACQADADAEAAQAEAAADgDQAEgCAAgHIAAgvIAbAAIAAAuQAAASgJAJQgKAKgTAAQgSAAgKgKg");
	this.shape_1.setTransform(157.5,-198.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAUIgfAAIAAAKIAdAAIAAAUIgdAAIAAAKIAgAAIAAAVg");
	this.shape_2.setTransform(149.775,-198.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAMApIgZgtIABAOIAAAfIgbAAIAAhRIAeAAIAXAsIgBgOIAAgeIAbAAIAABRg");
	this.shape_3.setTransform(135.275,-198.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgfAfQgNgLAAgUQAAgTANgMQAMgLATAAQAUAAAMALQANAMAAATQAAAUgNALQgMAMgUAAQgTAAgMgMgAgMgNQgFAFAAAIQAAAIAFAFQAFAGAHAAQAIAAAFgGQAFgFAAgIQAAgIgFgFQgFgGgIAAQgHAAgFAGg");
	this.shape_4.setTransform(125.975,-198.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgNApIAAg9IgTAAIAAgUIBBAAIAAAUIgTAAIAAA9g");
	this.shape_5.setTransform(118.425,-198.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAUIgfAAIAAAKIAdAAIAAAUIgdAAIAAAKIAgAAIAAAVg");
	this.shape_6.setTransform(109.375,-198.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AghAgIAMgVQAFAEAIADQAGACADAAQAGAAAAgDQAAgDgGgCIgLgEQgIgDgEgDQgIgFAAgLQAAgNAKgIQAJgHAPAAQARAAAMAKIgKATQgEgDgHgDIgJgBQgGAAAAADQAAACAFACIAKADQAJADAFAEQAIAFAAAMQAAANgLAJQgJAHgPAAQgRAAgPgLg");
	this.shape_7.setTransform(102.275,-198.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgNApIAAhRIAbAAIAABRg");
	this.shape_8.setTransform(96.975,-198.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgbApIAAhRIAbAAIAAA7IAcAAIAAAWg");
	this.shape_9.setTransform(92.125,-198.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAOApIgDgLIgXAAIgDALIgcAAIAdhRIAdAAIAdBRgAAFAJIgFgWIgGAWIALAAg");
	this.shape_10.setTransform(84.5,-198.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAMApIgZgtIABAOIAAAfIgbAAIAAhRIAeAAIAXAsIgBgOIAAgeIAbAAIAABRg");
	this.shape_11.setTransform(75.625,-198.45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAMApIgZgtIABAOIAAAfIgbAAIAAhRIAeAAIAXAsIgBgOIAAgeIAbAAIAABRg");
	this.shape_12.setTransform(66.475,-198.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgfAfQgNgLAAgUQAAgTANgMQAMgLATAAQAUAAAMALQANAMAAATQAAAUgNALQgMAMgUAAQgTAAgMgMgAgMgNQgFAFAAAIQAAAIAFAFQAFAGAHAAQAIAAAFgGQAFgFAAgIQAAgIgFgFQgFgGgIAAQgHAAgFAGg");
	this.shape_13.setTransform(57.175,-198.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AghAgIAMgVQAFAEAIADQAGACADAAQAGAAAAgDQAAgDgGgCIgLgEQgIgDgEgDQgIgFAAgLQAAgNAKgIQAJgHAPAAQARAAAMAKIgKATQgEgDgHgDIgJgBQgGAAAAADQAAACAFACIAKADQAJADAFAEQAIAFAAAMQAAANgLAJQgJAHgPAAQgRAAgPgLg");
	this.shape_14.setTransform(48.925,-198.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAGApIgMgbIgDAAIAAAbIgcAAIAAhRIAkAAQAPgBAJAHQAKAGAAAOQAAAQgOAIIATAfgAgKgFIAHAAQADgBACgBQADgCAAgEQAAgEgDgCQgCgBgDAAIgHAAg");
	this.shape_15.setTransform(41.975,-198.45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAUIgfAAIAAAKIAdAAIAAAUIgdAAIAAAKIAgAAIAAAVg");
	this.shape_16.setTransform(34.225,-198.45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgiApIAAhRIAjAAQAQAAAIAGQAJAHABAPQgBANgJAIQgIAGgQAAIgHAAIAAAagAgHgEIAFAAQAEAAACgBQADgCAAgFQAAgFgDgCQgCgBgEAAIgFAAg");
	this.shape_17.setTransform(27.15,-198.45);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAMApIgZgtIABAOIAAAfIgbAAIAAhRIAeAAIAXAsIgBgOIAAgeIAbAAIAABRg");
	this.shape_18.setTransform(16.175,-198.45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgfAfQgNgLAAgUQAAgTANgMQAMgLATAAQAUAAAMALQANAMAAATQAAAUgNALQgMAMgUAAQgTAAgMgMgAgMgNQgFAFAAAIQAAAIAFAFQAFAGAHAAQAIAAAFgGQAFgFAAgIQAAgIgFgFQgFgGgIAAQgHAAgFAGg");
	this.shape_19.setTransform(6.875,-198.45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhvAqIgGgBIABgUIAHABIADgBQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAgBIAAg6IAbAAIAAA6QAAANgGAHQgGAGgLAAIgKgBgABugeQgCgBAAgEQAAgDACgCQABAAAAgBQABAAAAAAQABgBABAAQAAAAABAAIADABIAAAEQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAgBgBAAQgBAAAAABQgBAAAAAAQgBABAAAAQAAABAAABIABADIACABIADgCIAAAFIgDABQgBAAAAgBQgBAAgBAAQAAAAgBgBQAAAAgBgBgABngbIgBgIIgEAIIgBAAIgDgIIgBAIIgEAAIADgPIADAAIADAIIADgIIADAAIACAPg");
	this.shape_20.setTransform(153.925,-198.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(0.7,-205.3,166.70000000000002,14.900000000000006), null);


(lib.Ctext3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOANQgGgEAAgJQAAgIAGgFQAGgEAIgBQAJABAGAEQAGAFAAAIQAAAJgGAEQgGAFgJABQgIgBgGgFg");
	this.shape.setTransform(160.425,-141.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_1.setTransform(151.05,-148.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgtA9QgZgXAAgmQAAgmAZgWQAYgVAjAAQAkAAARAPIgNArQgQgNgUAAQgQAAgJAJQgKAKAAARQAAARALAJQAJAJAPAAQAXAAAPgPIAPAqQgUAUglAAQgjAAgYgVg");
	this.shape_2.setTransform(137.075,-148);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAWBPIgwhXIABAcIAAA7IgyAAIAAidIA4AAIAtBXIgBgcIAAg7IAzAAIAACdg");
	this.shape_3.setTransform(120.85,-148.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAcBPIgHgWIgsAAIgGAWIg2AAIA3idIA5AAIA3CdgAAKARIgKgpIgMApIAWAAg");
	this.shape_4.setTransform(103.975,-148.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAtBPIgChaIgUBaIgsAAIgWhaIgBBaIgzAAIAJidIBDAAIATBVIAUhVIBDAAIAJCdg");
	this.shape_5.setTransform(85.55,-148.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAPAJALQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_6.setTransform(66.175,-148.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag2BPIAAidIBtAAIAAAoIg6AAIAAAZIA3AAIAAAoIg3AAIAAA0g");
	this.shape_7.setTransform(51.475,-148.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgGgFgEQgEgDgHAAIgNAAg");
	this.shape_8.setTransform(37.975,-148.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_9.setTransform(23.25,-148.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhBBPIAAidIBFAAQAcAAAQAMQASAPAAAbQAAAbgSAOQgQANgcAAIgQAAIAAAxgAgNgIIAJAAQAIAAADgDQAGgEAAgJQAAgJgGgDQgDgDgIAAIgJAAg");
	this.shape_10.setTransform(9.7,-148.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext3, new cjs.Rectangle(0,-160.5,165.6,27), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAcBPIgHgWIgsAAIgGAWIg2AAIA3idIA5AAIA3CdgAAKARIgKgpIgMApIAWAAg");
	this.shape.setTransform(164.925,-170.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag0BPIAAidIA0AAIAABzIA1AAIAAAqg");
	this.shape_1.setTransform(151.225,-170.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_2.setTransform(134.025,-170.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApg");
	this.shape_3.setTransform(121.3,-170.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_4.setTransform(103.625,-170.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgGgFgEQgEgDgHAAIgNAAg");
	this.shape_5.setTransform(90.475,-170.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAPAJALQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_6.setTransform(73.075,-170.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag2BPIAAidIBtAAIAAAoIg6AAIAAAZIA3AAIAAAoIg3AAIAAA0g");
	this.shape_7.setTransform(58.375,-170.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAWBPIgwhXIABAcIAAA7IgyAAIAAidIA4AAIAtBXIgBgcIAAg7IAzAAIAACdg");
	this.shape_8.setTransform(43,-170.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAPAJALQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_9.setTransform(25.175,-170.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgtA9QgZgXAAgmQAAgmAZgWQAYgVAjAAQAkAAARAPIgNArQgQgNgUAAQgQAAgJAJQgKAJAAASQAAARALAJQAJAJAPAAQAXAAAPgPIAPAqQgUAUglAAQgjAAgYgVg");
	this.shape_10.setTransform(9.525,-170.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(0,-182.7,175.3,27), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApg");
	this.shape.setTransform(200.95,-192.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag0BPIAAidIA0AAIAABzIA1AAIAAAqg");
	this.shape_1.setTransform(188.525,-192.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgGgFgEQgEgDgHAAIgNAAg");
	this.shape_2.setTransform(170.825,-192.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag2A+QgRgRAAgjIAAhZIA0AAIAABbQAAANAFAEQAGAGAIABQAJgBAGgGQAFgEAAgNIAAhbIA0AAIAABZQAAAjgRARQgSASglABQgjgBgTgSg");
	this.shape_3.setTransform(154.225,-192.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAPAJALQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_4.setTransform(136.875,-192.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhBBPIAAidIBEAAQAdAAAQAMQARAPABAbQgBAbgRAOQgQANgdAAIgQAAIAAAxgAgNgIIAJAAQAHAAAEgDQAGgEAAgJQAAgJgGgDQgEgDgHAAIgJAAg");
	this.shape_5.setTransform(121.15,-192.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag5BkIAAieIBwAAIAAApIg8AAIAAARIA4AAIAAAoIg4AAIAAASIA/AAIAAAqgAgZhBIAPghIApAAIgWAhg");
	this.shape_6.setTransform(102.6,-194.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag/A8IAWgnQALAJANAFQAMAEAGAAQALAAAAgHQAAgFgLgEIgWgHQgPgGgHgFQgPgMAAgVQABgYASgPQAQgOAeAAQAiAAAXAUIgUAkQgJgHgLgEQgLgEgHAAQgMAAAAAHQAAADAKAEIATAGQASAGAIAHQAQAMgBAWQAAAZgUAQQgSAOgcAAQghAAgcgWg");
	this.shape_7.setTransform(89.05,-192.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgZBPIAAidIAzAAIAACdg");
	this.shape_8.setTransform(78.9,-192.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAtBPIgChaIgVBaIgsAAIgUhaIgCBaIgzAAIAJidIBDAAIATBVIAUhVIBDAAIAJCdg");
	this.shape_9.setTransform(64.9,-192.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgZBPIAAidIAzAAIAACdg");
	this.shape_10.setTransform(50.9,-192.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_11.setTransform(40.825,-192.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhABPIAAidIBDAAQAdAAAPAMQATAPgBAbQABAbgTAOQgPANgdAAIgQAAIAAAxgAgNgIIAJAAQAHAAAFgDQAFgEAAgJQAAgJgFgDQgFgDgHAAIgJAAg");
	this.shape_12.setTransform(27.85,-192.525);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAPAJALQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_13.setTransform(11.075,-192.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(0,-205,209.6,27), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Isolation Mode
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#221F20").s().p("AgJAfIAAguIgPAAIAAgQIAxAAIAAAQIgPAAIAAAug");
	this.shape.setTransform(103.175,-93.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#221F20").s().p("AAJAfIgSgiIAAALIAAAXIgUAAIAAg+IAWAAIASAiIgBgKIAAgYIAUAAIAAA+g");
	this.shape_1.setTransform(97.175,-93.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#221F20").s().p("AALAfIgDgJIgRAAIgCAJIgWAAIAXg+IAVAAIAXA+gAAEAHIgEgQIgEAQIAIAAg");
	this.shape_2.setTransform(90.5,-93.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#221F20").s().p("AAJAfIgSgiIAAALIAAAXIgUAAIAAg+IAWAAIASAiIgBgKIAAgYIAUAAIAAA+g");
	this.shape_3.setTransform(83.775,-93.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#221F20").s().p("AgWAfIAAg+IAsAAIAAAQIgYAAIAAAIIAXAAIAAAPIgXAAIAAAHIAZAAIAAAQg");
	this.shape_4.setTransform(77.75,-93.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#221F20").s().p("AgJAfIAAguIgPAAIAAgQIAxAAIAAAQIgPAAIAAAug");
	this.shape_5.setTransform(72.525,-93.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#221F20").s().p("AAJAfIgSgiIAAALIAAAXIgUAAIAAg+IAWAAIASAiIgBgKIAAgYIAUAAIAAA+g");
	this.shape_6.setTransform(66.525,-93.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#221F20").s().p("AgJAfIAAg+IATAAIAAA+g");
	this.shape_7.setTransform(61.575,-93.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#221F20").s().p("AALAfIgCgJIgRAAIgDAJIgWAAIAWg+IAWAAIAWA+gAAEAHIgEgQIgEAQIAIAAg");
	this.shape_8.setTransform(56.9,-93.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#221F20").s().p("AASAfIgBgjIgIAjIgRAAIgIgjIgBAjIgUAAIAEg+IAaAAIAHAhIAIghIAbAAIADA+g");
	this.shape_9.setTransform(49.575,-93.85);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#221F20").s().p("AAFAfIgJgUIgDAAIAAAUIgVAAIAAg+IAcAAQALABAHAEQAHAGAAAJQAAAMgLAHIAPAXgAgHgEIAFAAIAEgBQADgCgBgCQABgEgDgBIgEgBIgFAAg");
	this.shape_10.setTransform(41.05,-93.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#221F20").s().p("AgWAfIAAg+IAsAAIAAAQIgYAAIAAAIIAXAAIAAAPIgXAAIAAAHIAZAAIAAAQg");
	this.shape_11.setTransform(35.2,-93.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#221F20").s().p("AgJAfIAAguIgPAAIAAgQIAxAAIAAAQIgPAAIAAAug");
	this.shape_12.setTransform(29.975,-93.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#221F20").s().p("AgWAfIAAg+IAsAAIAAAQIgXAAIAAAIIAVAAIAAAPIgVAAIAAAHIAYAAIAAAQg");
	this.shape_13.setTransform(24.9,-93.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#221F20").s().p("AAJAfIAAgXIgRAAIAAAXIgUAAIAAg+IAUAAIAAAXIARAAIAAgXIAUAAIAAA+g");
	this.shape_14.setTransform(18.775,-93.85);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#221F20").s().p("AgSAYQgJgJAAgPQAAgOAJgJQAKgJANAAQAPAAAGAHIgFARQgGgFgIgBQgGABgDADQgFADABAHQgBAHAFAEQADADAGAAQAJAAAGgGIAGAQQgIAIgPAAQgNABgKgJg");
	this.shape_15.setTransform(12.6,-93.85);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#221F20").s().p("AALAfIgDgJIgRAAIgCAJIgVAAIAWg+IAWAAIAVA+gAAEAHIgEgQIgEAQIAIAAg");
	this.shape_16.setTransform(6.55,-93.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AoBBaQgQABgMgMQgMgNAAgQIAAhkQAAgQAMgMQAMgMAQAAIQCAAQARAAAMAMQAMAMAAAQIAABkQAAAQgMANQgMAMgRgBg");
	this.shape_17.setTransform(55.375,-93.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(0,-103,110.8,18.099999999999994), null);


(lib.Btext22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhKBPIAAidIA8AAQAoAAAWARQAbAUAAApQAAAqgbAUQgWARgoAAgAgWAkIAMAAQAPAAAIgJQAJgJAAgSQAAgTgJgJQgIgIgPAAIgMAAg");
	this.shape.setTransform(62.875,-231.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA/AAIAAApg");
	this.shape_1.setTransform(47.85,-231.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApg");
	this.shape_2.setTransform(34.55,-231.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhABPIAAidIBDAAQAdAAAPAMQASAPAAAbQAAAbgSAOQgPANgdAAIgQAAIAAAxgAgNgIIAJAAQAHAAAFgDQAFgEAAgJQAAgJgFgDQgFgDgHAAIgJAAg");
	this.shape_3.setTransform(21,-231.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhAA8IAYgnQAKAJANAFQAMAEAGAAQAMAAAAgHQAAgFgMgEIgWgHQgPgGgHgFQgOgMAAgVQAAgYASgPQAQgOAeAAQAiAAAWAUIgUAkQgHgHgMgEQgLgEgHAAQgMAAAAAHQAAADAKAEIATAGQASAGAJAHQAPAMAAAWQAAAZgWAQQgRAOgdAAQggAAgdgWg");
	this.shape_4.setTransform(6.65,-231.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_5.setTransform(-5.775,-231.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_6.setTransform(-18.5,-231.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAtBPIgChaIgUBaIgsAAIgWhaIgBBaIgzAAIAJidIBDAAIATBVIAUhVIBDAAIAJCdg");
	this.shape_7.setTransform(-49,-231.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgtA8QgZgWAAgmQAAgmAZgWQAYgVAjAAQAkAAARAPIgNArQgQgNgUAAQgQAAgJAIQgKALAAARQAAAQALAKQAJAJAPAAQAXAAAPgOIAPAoQgUAVglAAQgjAAgYgWg");
	this.shape_8.setTransform(-66.375,-231.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgtA8QgZgWAAgmQAAgmAZgWQAYgVAjAAQAkAAARAPIgNArQgQgNgUAAQgQAAgJAIQgKALAAARQAAAQALAKQAJAJAPAAQAXAAAPgOIAPAoQgUAVglAAQgjAAgYgWg");
	this.shape_9.setTransform(-80.475,-231.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgZBPQgIgBgDgCIACglQAGACAHAAQADAAACgBQACgCAAgGIAAhvIAzAAIAABvQAAAZgLAMQgMALgUAAQgKAAgJgBg");
	this.shape_10.setTransform(-29.65,-231.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-243.7,163,27);


(lib.Btext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgTA3QgIgHAAgMQAAgLAIgHQAHgHAMAAQANAAAHAHQAIAHAAALQAAAMgIAHQgHAGgNAAQgMAAgHgGgAgTgRQgIgGAAgMQAAgMAIgHQAHgGAMAAQANAAAHAGQAIAHAAAMQAAAMgIAGQgHAHgNAAQgMAAgHgHg");
	this.shape.setTransform(82.875,-232.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApg");
	this.shape_1.setTransform(111.05,-233.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag0BPIAAidIA0AAIAABzIA1AAIAAAqg");
	this.shape_2.setTransform(98.625,-233.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_3.setTransform(68.075,-233.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgGgFgEQgEgDgHAAIgNAAg");
	this.shape_4.setTransform(54.925,-233.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAPAJALQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_5.setTransform(37.525,-233.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhBBPIAAidIBEAAQAdAAAPAMQASAPABAbQgBAbgSAOQgPANgdAAIgQAAIAAAxgAgNgIIAJAAQAHAAAFgDQAFgEAAgJQAAgJgFgDQgFgDgHAAIgJAAg");
	this.shape_6.setTransform(21.8,-233.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhAA8IAYgnQAJAJAOAFQAMAEAGAAQAMAAAAgHQAAgFgMgEIgWgHQgPgGgHgFQgOgMAAgVQAAgYASgPQARgOAdAAQAiAAAWAUIgUAkQgHgHgMgEQgLgEgHAAQgMAAAAAHQAAADAKAEIATAGQASAGAJAHQAOAMAAAWQABAZgWAQQgRAOgcAAQghAAgdgWg");
	this.shape_7.setTransform(7.45,-233.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btext1, new cjs.Rectangle(-1,-247.3,120.7,28.600000000000023), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-100.8,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-287.3,165.3,27);


// stage content:
(lib.speed_336x280_fr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(172.55,351.95,1.12,1.12,0,0,0,62.1,18.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(309).to({_off:false},0).to({alpha:1},22,cjs.Ease.cubicInOut).wait(12));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(-101.85,413.9,1.12,1.12,0,0,0,84.2,10.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(292).to({_off:false},0).to({x:166.9},20,cjs.Ease.quartOut).wait(31));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(166.05,299.5,0.448,0.448,0,0,0,177.6,184.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(268).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(46));

	// cta
	this.instance_3 = new lib.CTA();
	this.instance_3.setTransform(94.65,309.05,1.12,1.12,0,0,0,62.1,18.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(145).to({y:281.05},23,cjs.Ease.quartInOut).wait(81).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(76));

	// Ctext3
	this.instance_4 = new lib.Ctext3();
	this.instance_4.setTransform(-103.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(157).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(81));

	// Ctet2
	this.instance_5 = new lib.Ctext2();
	this.instance_5.setTransform(-117.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(154).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_6 = new lib.Ctext1();
	this.instance_6.setTransform(-103.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(151).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// Btext2_copy
	this.instance_7 = new lib.text3();
	this.instance_7.setTransform(-179.1,366.45,1.12,1.12);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(19).to({_off:false},0).to({x:123.25},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(192));

	// Btext2
	this.instance_8 = new lib.Btext22();
	this.instance_8.setTransform(-156.25,366.45,1.12,1.12);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(17).to({_off:false},0).to({x:123.25},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(194));

	// Btext1
	this.instance_9 = new lib.Btext1();
	this.instance_9.setTransform(-147.8,372.95,1.12,1.12,0,0,0,74.8,24);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(13).to({_off:false},0).to({x:106.15,y:371.6},22,cjs.Ease.quartOut).wait(93).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(197));

	// text2
	this.instance_10 = new lib.Tween2("synched",0);
	this.instance_10.setTransform(-158.95,366.45,1.12,1.12);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(9).to({_off:false},0).to({x:123.25},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_11 = new lib.text1();
	this.instance_11.setTransform(-206.95,282.9,1.12,1.12,0,0,0,74.8,24);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(5).to({_off:false},0).to({x:106.15},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// rip
	this.instance_12 = new lib.rip();
	this.instance_12.setTransform(177.95,140.25,1.12,1.12,0,0,0,151.9,126.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(253).to({x:379.55},21,cjs.Ease.quartInOut).wait(69));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(167.9993,335.9985,1.12,1.12);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-122.7,138.9,660.6,533.1);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 336,
	height: 280,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/speed_336x280_fr_atlas_P_1.png", id:"speed_336x280_fr_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;