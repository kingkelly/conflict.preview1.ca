(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"shift_336x280_fr_atlas_1", frames: [[0,0,558,1110],[0,1112,332,174],[334,1112,282,170]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset1 = function() {
	this.initialize(ss["shift_336x280_fr_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset16shiftImage1BB = function() {
	this.initialize(ss["shift_336x280_fr_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Asset17shiftImage2BB = function() {
	this.initialize(ss["shift_336x280_fr_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhABJQgUgUAAgpIAAhqIA9AAIAABtQAAAOAHAGQAGAHAKAAQALAAAHgHQAFgGAAgOIAAhtIA+AAIAABqQAAApgUAUQgWAWgrAAQgpAAgXgWg");
	this.shape.setTransform(205.75,-143.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhXBdIAAi5IBGAAQAvAAAbAUQAfAYAAAwQAAAxgfAYQgbAUgvAAgAgaAqIAOAAQASAAAJgKQALgKAAgWQAAgWgLgLQgJgJgSAAIgOAAg");
	this.shape_1.setTransform(186.775,-143.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhCBdIAAi5ICDAAIAAAwIhHAAIAAAUIBDAAIAAAvIhDAAIAAAWIBKAAIAAAwg");
	this.shape_2.setTransform(163.85,-143.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag1BHQgdgaAAgtQAAgsAdgbQAcgYAqAAQApAAAVARIgRA0QgSgRgXAAQgSAAgLALQgNALAAAVQAAATANAMQALAKASAAQAbAAASgRIARAwQgYAYgqAAQgqAAgcgZg");
	this.shape_3.setTransform(147.5,-143.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_4.setTransform(130.625,-143.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhABJQgUgUAAgpIAAhqIA+AAIAABtQgBAOAHAGQAGAHAKAAQALAAAGgHQAHgGgBgOIAAhtIA+AAIAABqQAAApgUAUQgWAWgrAAQgpAAgXgWg");
	this.shape_5.setTransform(111.15,-143.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhHBHQgdgbAAgsQAAgrAdgbQAbgZAsAAQAsAAAcAZQAdAbAAArQAAAsgdAbQgcAagsgBQgsABgbgagAgcgfQgLAMAAASQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgSgLgMQgLgNgSAAQgRAAgLANg");
	this.shape_6.setTransform(90.825,-143.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhLBHIAcguQALAKAQAFQAOAFAHAAQAOAAAAgIQAAgFgNgFIgagIQgTgHgHgHQgRgOAAgZQAAgbAVgSQAUgQAiAAQAoAAAbAXIgYArQgJgJgPgFQgLgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQASAPAAAZQAAAegZATQgUAQghAAQgnAAgigZg");
	this.shape_7.setTransform(72.35,-143.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAhBdIgIgaIg0AAIgHAaIhAAAIBBi5IBDAAIBAC5gAAMAUIgMgxIgPAxIAbAAg");
	this.shape_8.setTransform(50,-143.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag9BdIAAi5IA9AAIAACHIA+AAIAAAyg");
	this.shape_9.setTransform(33.95,-143.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAgB1IgHgaIg0AAIgHAaIhAAAIBBi6IBCAAIBBC6gAAMAsIgNgxIgNAxIAaAAgAgShNIgZgnIAwAAIASAng");
	this.shape_10.setTransform(11.6,-145.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(0,-157.5,222.9,31), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhCB1IAAi6ICDAAIAAAwIhHAAIAAAVIBDAAIAAAvIhDAAIAAAVIBKAAIAAAxgAgehNIATgnIAvAAIgZAng");
	this.shape.setTransform(202.65,-197.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgdBdIAAiKIgsAAIAAgvICTAAIAAAvIgrAAIAACKg");
	this.shape_1.setTransform(187.125,-195.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdBdIAAi5IA8AAIAAC5g");
	this.shape_2.setTransform(175.3,-195.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgdBdIhGi5IBBAAIAiBrIAjhrIBBAAIhGC5g");
	this.shape_3.setTransform(161.225,-195.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgdBdIAAi5IA7AAIAAC5g");
	this.shape_4.setTransform(147.1,-195.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhLBHIAcguQALAKAQAFQAOAFAHAAQAOAAAAgIQAAgFgNgFIgagIQgTgHgHgHQgRgOAAgZQAAgbAVgSQAUgQAiAAQAoAAAbAXIgYArQgJgJgPgFQgLgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQASAPAAAZQAAAegZATQgUAQghAAQgnAAgigZg");
	this.shape_5.setTransform(134.9,-195.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag/BJQgVgUAAgpIAAhqIA9AAIAABtQAAAOAHAGQAGAHAKAAQALAAAHgHQAFgGAAgOIAAhtIA+AAIAABqQAAApgUAUQgWAWgrAAQgqAAgVgWg");
	this.shape_6.setTransform(117.65,-195.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag9BdIAAi5IA8AAIAACHIA/AAIAAAyg");
	this.shape_7.setTransform(102.05,-195.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag1BHQgdgaAAgtQAAgsAdgbQAbgYArAAQAqAAAUARIgQA0QgTgRgXAAQgTAAgKALQgNALAAAVQAAATAOAMQAKAKASAAQAcAAAQgRIASAwQgYAYgqAAQgrAAgbgZg");
	this.shape_8.setTransform(86.25,-195.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAeBdIgeg7IgdA7IhJAAIA+hgIg6hZIBJAAIAZAyIAagyIBJAAIg7BZIA/Bgg");
	this.shape_9.setTransform(68.775,-195.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBJAAIAAAwg");
	this.shape_10.setTransform(51.5,-195.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAaBdIg4hnIABAhIAABGIg7AAIAAi5IBCAAIA1BnIgBghIAAhGIA7AAIAAC5g");
	this.shape_11.setTransform(27.9,-195.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBJAAIAAAwg");
	this.shape_12.setTransform(10.1,-195.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(0,-209.8,217.7,31), null);


(lib.skate2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AtWhEIAAyYIatAAIAASYg");
	mask.setTransform(53.525,-124.5087);

	// Layer_4
	this.instance = new lib.Asset17shiftImage2BB();
	this.instance.setTransform(-33,-251,0.6985,0.6985);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate2, new cjs.Rectangle(-32,-249,171.1,116.80000000000001), null);


(lib.skate1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlJEzIAAyHIZcAAIAASHg");
	mask.setTransform(129.925,-85.3228);

	// Layer_3
	this.instance = new lib.Asset16shiftImage1BB();
	this.instance.setTransform(66,-172,0.6767,0.6767);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate1, new cjs.Rectangle(97,-170.6,162.89999999999998,116), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AD6W3QgngnAAg6QAAg3AqgkQAngkA3AAQA2AAAoAkQApAkAAA3QAAA6gmAnQgmAmg7AAQg7AAgmgmgAEqUpQgVATAAAaQAAAfAVAVQAUAVAdgBQAdABAUgVQAUgVAAgfQAAgagUgTQgVgUgcAAQgcAAgVAUgAjrXVQgVgGgLgLIAAAAIAAhAIACADQAMANAVAKQAVAJARAAQARAAAHgGQAIgEAAgKQAAgKgJgGQgGgFgagKQhAgYAAg3QAAgiAYgWQAYgXAmABQAWgBASAHQATAGAKAHIAAABIAAA/IgCgCQgJgLgRgJQgTgIgOAAQgOAAgHAFQgHAGAAAJQAAAKAIAGQAGAGAXAIQAfAMATATQATAUAAAbQAAAjgZAXQgZAWgsAAQgaAAgUgHgAqHXAQgQgQgGgZQgEgQAAgeIAAiLIBAAAIAACCQAAAfAHAOQAKAWAbAAQAcAAAJgWQAHgOAAgfIAAiCIBAAAIAACLQAAAegEAQQgGAZgQAQQgcAbg2ABQg2gBgcgbgAM9XVIAAjAIg1AAIAAg3ICqAAIAAA3Ig1AAIAADAgAKYXVIg+hfIAABfIhAAAIAAj3IBkAAQAVAAAPAGQAPAGALAKQAJAKAGAPQAFANAAAQQAAAdgOARQgMARgcAHIBOBlgAJaVMIANAAQATABAKgJQAKgHAAgPQAAgPgKgIQgKgHgTgBIgNAAgAggXVIAAj3IBlAAQApAAAXAVQAWAWAAAoQAAAngWAWQgWAVgqAAIgmAAIAABSgAAfVPIAVAAQAkAAAAgeQAAgfgkAAIgVAAgAuxXVIAAj3IBbAAQA0AAAkAkQAlAkAAAzQAAA1glAjQgkAkg0AAgAtxWeIAOAAQAfAAATgQQAVgTAAgiQAAgggTgSQgTgTggABIgPAAgAQmUEQgHgHAAgKQAAgJAHgHQAHgGAJAAQAFAAAFACIAAANQgEgEgGAAQgFgBgDAEQgDAEAAAEQAAAFADAEQADADAFAAQAFABAFgFIAAANIgBAAIgJACQgJAAgHgGgAQPUJIgEgYIgKAYIgEAAIgKgYIgEAYIgLAAIAHgrIALAAIAJAXIAJgXIALAAIAHArgAWOO/QgwgSgmgkQhQhHAAh0QAAg0ATgvQATgvAjgkQAlglAygWQAygWA0ABQA4AAA+AZIAACbQgTgbgfgPQgegOghABQg7gBglAoQglAnAAA7QAAA8AlAlQAmAmA8AAQAfAAAegOQAdgOAVgZIAACbQgnANgTADQgdAHgbAAQg0AAgwgTgAlFOGQhNhMAAh2QAAhsBThKQBPhGBtAAQBtAABOBGQBTBKAABsQAAB2hNBMQhLBMh2AAQh2AAhMhMgAjlJqQgoAnAAAzQAAA+AoArQAoApA6AAQA5AAApgpQAngrAAg+QAAgzgngnQgqgng4AAQg4AAgqAngAsNPDQgpgNgVgUIgBgBIAAh/IAEAGQAXAaAqATQAqASAhAAQAfABASgLIgBAAQARgMAAgTQAAgUgSgLIAAAAQgQgLgwgSIABAAQiAgvAAhvQAAhDAwgsQAugsBNAAQAqAAAlALIAAABQAkAMAWAPIABACIAAB8IgFgEQgTgWgigQQgigRgeAAQgbAAgPALQgOALAAASQAAATAPANQAQANAqAPQA/AWAlAnQAmAnAAA2QAABGgxAuQgyArhYABQgygBgqgNgAFuPCQgugOgdgdQghgfgLgxQgIghAAg8IAAkTICAAAIAAECQAAA/AMAcQATAqA3AAQA3AAATgqQANgcAAg/IAAkCIB/AAIAAETQAAA9gHAgQgLAxghAfQgdAdguAOQgoAMgwAAQgvAAgogMgAbjPBIAAnqIEXAAIAABsIiXAAIAABSICPAAIAABsIiPAAIAABUICXAAIAABsgAQUPBIh5i9IgBAAIAAC9Ih/AAIAAnqIC+AAQBNAAAsAkQAxAnAABMQAAA1gbAlQgdAngzAKICaDIgAOaKzIAMAAQAnAAAVgKQAdgPAAglQAAgjgdgPQgVgLgnAAIgMAAgA0DPBIgfhVIiwAAIgiBVIiHAAIC9nqICLAAIC4HqgA2vMLIBqAAIg0idIgBAAgA/5PBIAAnqIB/AAIAAF+ICZAAIAABsgAlHgKQh4g6hfhiIAAjkQBsB0BtA8QCYBUC0AAQCcAABohxQBfhoAAiJQAAiIhhhqQhohwiXAAQgvAAgfgfQgegfAAgwQAAgtAiggQAhgdApAAIALAAQB3AABpAtQBqAtBPBVQBJBPApBlQAoBmAABqQAADpilClQilCljpAAQi9gBifhNgAgUl0Qh3gBhqgsQhpguhPhUQhKhPgohlQgohmAAhrQAAjpClilQClilDpAAQEWACDMChIAADeQhrhehzgsQhzgtiEAAQicAAhnByQhfBoAACIQAACIBhBpQBoByCXAAQAugBAfAgQAfAfAAAvQAAAsgjAgQghAfgoAAg");
	this.shape.setTransform(178.1376,-249.9586,0.8689,0.8689);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(0.7,-380.3,354.90000000000003,260.70000000000005), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJAKQgFgEAAgGQAAgFAFgEQAEgDAFAAQAHAAADADQAFAEAAAFQAAAGgFAEQgDADgHAAQgFAAgEgDg");
	this.shape.setTransform(163.75,-195.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgcAgQgJgJAAgSIAAguIAbAAIAAAvQAAAHADACQADADAEAAQAEAAADgDQAEgCAAgHIAAgvIAbAAIAAAuQAAASgJAJQgKAKgTAAQgSAAgKgKg");
	this.shape_1.setTransform(157.5,-198.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAUIgfAAIAAAKIAdAAIAAAUIgdAAIAAAKIAgAAIAAAVg");
	this.shape_2.setTransform(149.775,-198.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAMApIgZgtIABAOIAAAfIgbAAIAAhRIAeAAIAXAsIgBgOIAAgeIAbAAIAABRg");
	this.shape_3.setTransform(135.275,-198.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgfAfQgNgLAAgUQAAgTANgMQAMgLATAAQAUAAAMALQANAMAAATQAAAUgNALQgMAMgUAAQgTAAgMgMgAgMgNQgFAFAAAIQAAAIAFAFQAFAGAHAAQAIAAAFgGQAFgFAAgIQAAgIgFgFQgFgGgIAAQgHAAgFAGg");
	this.shape_4.setTransform(125.975,-198.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgNApIAAg9IgTAAIAAgUIBBAAIAAAUIgTAAIAAA9g");
	this.shape_5.setTransform(118.425,-198.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAUIgfAAIAAAKIAdAAIAAAUIgdAAIAAAKIAgAAIAAAVg");
	this.shape_6.setTransform(109.375,-198.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AghAgIAMgVQAFAEAIADQAGACADAAQAGAAAAgDQAAgDgGgCIgLgEQgIgDgEgDQgIgFAAgLQAAgNAKgIQAJgHAPAAQARAAAMAKIgKATQgEgDgHgDIgJgBQgGAAAAADQAAACAFACIAKADQAJADAFAEQAIAFAAAMQAAANgLAJQgJAHgPAAQgRAAgPgLg");
	this.shape_7.setTransform(102.275,-198.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgNApIAAhRIAbAAIAABRg");
	this.shape_8.setTransform(96.975,-198.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgbApIAAhRIAbAAIAAA7IAcAAIAAAWg");
	this.shape_9.setTransform(92.125,-198.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAOApIgDgLIgXAAIgDALIgcAAIAdhRIAdAAIAdBRgAAFAJIgFgWIgGAWIALAAg");
	this.shape_10.setTransform(84.5,-198.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAMApIgZgtIABAOIAAAfIgbAAIAAhRIAeAAIAXAsIgBgOIAAgeIAbAAIAABRg");
	this.shape_11.setTransform(75.625,-198.45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAMApIgZgtIABAOIAAAfIgbAAIAAhRIAeAAIAXAsIgBgOIAAgeIAbAAIAABRg");
	this.shape_12.setTransform(66.475,-198.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgfAfQgNgLAAgUQAAgTANgMQAMgLATAAQAUAAAMALQANAMAAATQAAAUgNALQgMAMgUAAQgTAAgMgMgAgMgNQgFAFAAAIQAAAIAFAFQAFAGAHAAQAIAAAFgGQAFgFAAgIQAAgIgFgFQgFgGgIAAQgHAAgFAGg");
	this.shape_13.setTransform(57.175,-198.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AghAgIAMgVQAFAEAIADQAGACADAAQAGAAAAgDQAAgDgGgCIgLgEQgIgDgEgDQgIgFAAgLQAAgNAKgIQAJgHAPAAQARAAAMAKIgKATQgEgDgHgDIgJgBQgGAAAAADQAAACAFACIAKADQAJADAFAEQAIAFAAAMQAAANgLAJQgJAHgPAAQgRAAgPgLg");
	this.shape_14.setTransform(48.925,-198.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAGApIgMgbIgDAAIAAAbIgcAAIAAhRIAkAAQAPgBAJAHQAKAGAAAOQAAAQgOAIIATAfgAgKgFIAHAAQADgBACgBQADgCAAgEQAAgEgDgCQgCgBgDAAIgHAAg");
	this.shape_15.setTransform(41.975,-198.45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAUIgfAAIAAAKIAdAAIAAAUIgdAAIAAAKIAgAAIAAAVg");
	this.shape_16.setTransform(34.225,-198.45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgiApIAAhRIAjAAQAQAAAIAGQAJAHABAPQgBANgJAIQgIAGgQAAIgHAAIAAAagAgHgEIAFAAQAEAAACgBQADgCAAgFQAAgFgDgCQgCgBgEAAIgFAAg");
	this.shape_17.setTransform(27.15,-198.45);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAMApIgZgtIABAOIAAAfIgbAAIAAhRIAeAAIAXAsIgBgOIAAgeIAbAAIAABRg");
	this.shape_18.setTransform(16.175,-198.45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgfAfQgNgLAAgUQAAgTANgMQAMgLATAAQAUAAAMALQANAMAAATQAAAUgNALQgMAMgUAAQgTAAgMgMgAgMgNQgFAFAAAIQAAAIAFAFQAFAGAHAAQAIAAAFgGQAFgFAAgIQAAgIgFgFQgFgGgIAAQgHAAgFAGg");
	this.shape_19.setTransform(6.875,-198.45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhvAqIgGgBIABgUIAHABIADgBQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAgBIAAg6IAbAAIAAA6QAAANgGAHQgGAGgLAAIgKgBgABugeQgCgBAAgEQAAgDACgCQABAAAAgBQABAAAAAAQABgBABAAQAAAAABAAIADABIAAAEQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAgBgBAAQgBAAAAABQgBAAAAAAQgBABAAAAQAAABAAABIABADIACABIADgCIAAAFIgDABQgBAAAAgBQgBAAgBAAQAAAAgBgBQAAAAgBgBgABngbIgBgIIgEAIIgBAAIgDgIIgBAIIgEAAIADgPIADAAIADAIIADgIIADAAIACAPg");
	this.shape_20.setTransform(153.925,-198.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(0.7,-205.3,166.70000000000002,14.900000000000006), null);


(lib.Ctext3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAOQgGgEAAgKQAAgIAGgGQAGgEAJAAQAKAAAGAEQAGAGAAAIQAAAKgGAEQgGAGgKgBQgJABgGgGg");
	this.shape.setTransform(145.65,-134.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhKBHIAbguQALAKARAFQANAFAHAAQAOAAAAgIQAAgFgOgFIgagIQgRgHgIgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgWArQgKgJgPgFQgMgEgIAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPABAZQAAAegYATQgWAQggAAQgnAAghgZg");
	this.shape_1.setTransform(134.7,-141.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhABdIAAi5ICBAAIAAAwIhEAAIAAAdIBAAAIAAAvIhAAAIAAA9g");
	this.shape_2.setTransform(120.125,-141.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeBdIAAi5IA9AAIAAC5g");
	this.shape_3.setTransform(107.9,-141.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhLBHIAbguQAMAKARAFQANAFAHAAQAOAAAAgIQAAgFgOgFIgZgIQgSgHgIgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgWArQgKgJgOgFQgMgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPAAAZQAAAegXATQgVAQgiAAQgmAAgigZg");
	this.shape_4.setTransform(95.7,-141.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhHBHQgdgaAAgtQAAgrAdgbQAbgZAsgBQAsABAcAZQAdAbAAArQAAAtgdAaQgcAagsAAQgsAAgbgagAgcggQgLAMAAAUQAAASALAMQALAMARAAQASAAALgMQALgMAAgSQAAgUgLgMQgLgMgSAAQgRAAgLAMg");
	this.shape_5.setTransform(77.525,-141.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag9BdIAAi5IA8AAIAACHIA/AAIAAAyg");
	this.shape_6.setTransform(61.45,-141.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgPgKIAKAAQAJAAAFgDQAGgFAAgKQAAgKgGgFQgFgDgJAAIgKAAg");
	this.shape_7.setTransform(46.1,-141.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAeBdIgeg7IgdA7IhJAAIA+hgIg6hZIBJAAIAZAyIAagyIBJAAIg7BZIA/Bgg");
	this.shape_8.setTransform(27.375,-141.825);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBJAAIAAAwg");
	this.shape_9.setTransform(10.1,-141.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext3, new cjs.Rectangle(0,-156.1,151,31), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhKBHIAbguQALAKAQAFQAOAFAHAAQAOAAAAgIQAAgFgOgFIgagIQgRgHgIgHQgRgOAAgZQAAgbAVgSQAUgQAiAAQAoAAAbAXIgXArQgKgJgPgFQgMgEgIAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQASAPAAAZQAAAegYATQgWAQggAAQgnAAghgZg");
	this.shape.setTransform(165.4,-168.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhCBdIAAi5ICDAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBKAAIAAAwg");
	this.shape_1.setTransform(150.3,-168.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag9BJQgfgaAAgvQAAguAfgaQAbgXAqAAQAgAAAYAOQAJAFAMAOIgoAhQgQgQgVAAQgRAAgKAMQgMANAAAUQAAAWAMAMQAKAMARAAQAVAAAEgHIAAgOIgdAAIAAgsIBZAAIAABRQgSAQgMAGQgZAMggAAQgoAAgbgXg");
	this.shape_2.setTransform(132.05,-168.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAgBdIgHgaIg0AAIgHAaIg/AAIBAi5IBDAAIBBC5gAAMAUIgMgxIgPAxIAbAAg");
	this.shape_3.setTransform(113.25,-168.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_4.setTransform(95.625,-168.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgeBdIAAi5IA9AAIAAC5g");
	this.shape_5.setTransform(81.45,-168.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgdBdIhGi5IBBAAIAiBrIAjhrIBBAAIhGC5g");
	this.shape_6.setTransform(67.375,-168.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhKBHIAbguQALAKARAFQANAFAHAAQAOAAAAgIQAAgFgOgFIgagIQgSgHgHgHQgRgOAAgZQAAgbAWgSQATgQAiAAQAoAAAaAXIgWArQgKgJgPgFQgMgEgIAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQARAPAAAZQABAegYATQgWAQggAAQgnAAghgZg");
	this.shape_7.setTransform(44.6,-168.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhCBdIAAi5ICDAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBKAAIAAAwg");
	this.shape_8.setTransform(29.5,-168.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhXBdIAAi5IBGAAQAvAAAbAUQAfAYAAAwQAAAxgfAYQgbAUgvAAgAgaAqIAOAAQASAAAJgKQALgKAAgWQAAgWgLgLQgJgJgSAAIgOAAg");
	this.shape_9.setTransform(12.125,-168.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(0,-182.9,175.4,31), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape.setTransform(169.475,-195.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag/BJQgVgUAAgpIAAhqIA+AAIAABtQAAAOAFAGQAIAHAJAAQALAAAGgHQAHgGAAgOIAAhtIA9AAIAABqQAAApgUAUQgWAWgrAAQgpAAgWgWg");
	this.shape_1.setTransform(150,-195.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhHBHQgdgaAAgtQAAgsAdgaQAbgZAsAAQAsAAAcAZQAdAaAAAsQAAAtgdAaQgcAagsgBQgsABgbgagAgcgfQgLAMAAASQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgSgLgMQgLgNgSAAQgRAAgLANg");
	this.shape_2.setTransform(129.675,-195.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgQgKIAKAAQAKAAAEgDQAIgFAAgKQAAgKgIgFQgEgDgKAAIgKAAg");
	this.shape_3.setTransform(111.2,-195.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhABJQgUgUAAgpIAAhqIA+AAIAABtQAAAOAFAGQAIAHAJAAQALAAAGgHQAHgGgBgOIAAhtIA+AAIAABqQAAApgUAUQgWAWgrAAQgpAAgXgWg");
	this.shape_4.setTransform(87.2,-195.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AggBzIAVgpQgcgGgSgTQgZgaAAgpQAAgtAdgaQAbgZArAAQAqAAAUASIgQAzQgTgQgXAAQgTAAgKAKQgNAMAAAVQAAATAOALQAKAKASAAQAcAAAQgRIASAxQgSATgdADIgRAng");
	this.shape_5.setTransform(69.25,-193.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAaBdIg4hnIABAhIAABGIg7AAIAAi5IBCAAIA1BnIgBghIAAhGIA7AAIAAC5g");
	this.shape_6.setTransform(50.15,-195.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhHBHQgdgaAAgtQAAgsAdgaQAbgZAsAAQAsAAAcAZQAdAaAAAsQAAAtgdAaQgcAagsgBQgsABgbgagAgcgfQgLAMAAASQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgSgLgMQgLgNgSAAQgRAAgLANg");
	this.shape_7.setTransform(29.275,-195.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag1BHQgdgaAAgtQAAgsAdgbQAcgYAqAAQAqAAAUARIgQA0QgTgRgXAAQgTAAgKALQgNALAAAVQAAATANAMQALAKASAAQAcAAAQgRIASAwQgXAYgrAAQgqAAgcgZg");
	this.shape_8.setTransform(10.85,-195.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(0,-209.8,185,31), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgJAfIAAgtIgPAAIAAgQIAxAAIAAAQIgPAAIAAAtg");
	this.shape.setTransform(101.175,-121.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AAIAfIgRghIAAAKIAAAXIgUAAIAAg9IAXAAIARAhIgBgKIAAgXIAUAAIAAA9g");
	this.shape_1.setTransform(95.3,-121.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AALAfIgDgJIgQAAIgDAJIgVAAIAWg9IAVAAIAWA9gAAEAHIgEgQIgEAQIAIAAg");
	this.shape_2.setTransform(88.725,-121.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AAIAfIgRghIAAAKIAAAXIgUAAIAAg9IAWAAIARAhIAAgKIAAgXIAUAAIAAA9g");
	this.shape_3.setTransform(82.15,-121.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AgWAfIAAg9IArAAIAAAQIgXAAIAAAHIAWAAIAAAPIgWAAIAAAHIAYAAIAAAQg");
	this.shape_4.setTransform(76.25,-121.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AgJAfIAAgtIgPAAIAAgQIAxAAIAAAQIgPAAIAAAtg");
	this.shape_5.setTransform(71.125,-121.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AAIAfIgRghIAAAKIAAAXIgUAAIAAg9IAXAAIARAhIgBgKIAAgXIAUAAIAAA9g");
	this.shape_6.setTransform(65.25,-121.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgJAfIAAg9IATAAIAAA9g");
	this.shape_7.setTransform(60.4,-121.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AALAfIgDgJIgQAAIgDAJIgVAAIAWg9IAVAAIAWA9gAAEAHIgEgQIgEAQIAIAAg");
	this.shape_8.setTransform(55.825,-121.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#231F20").s().p("AARAfIAAgjIgIAjIgRAAIgIgjIgBAjIgTAAIADg9IAaAAIAHAhIAIghIAaAAIADA9g");
	this.shape_9.setTransform(48.65,-121.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#231F20").s().p("AAFAfIgJgVIgDAAIAAAVIgUAAIAAg9IAbAAQALAAAGAEQAHAGABAKQgBALgKAHIAOAXgAgHgEIAFAAIADgBQABAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBQAAgDgDgCIgDgBIgFAAg");
	this.shape_10.setTransform(40.3,-121.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#231F20").s().p("AgVAfIAAg9IArAAIAAAQIgYAAIAAAHIAWAAIAAAPIgWAAIAAAHIAZAAIAAAQg");
	this.shape_11.setTransform(34.55,-121.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#231F20").s().p("AgJAfIAAgtIgPAAIAAgQIAxAAIAAAQIgPAAIAAAtg");
	this.shape_12.setTransform(29.425,-121.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#231F20").s().p("AgVAfIAAg9IArAAIAAAQIgXAAIAAAHIAVAAIAAAPIgVAAIAAAHIAYAAIAAAQg");
	this.shape_13.setTransform(24.45,-121.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#231F20").s().p("AAIAfIAAgXIgQAAIAAAXIgUAAIAAg9IAUAAIAAAWIAQAAIAAgWIAVAAIAAA9g");
	this.shape_14.setTransform(18.475,-121.55);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#231F20").s().p("AgRAYQgKgJAAgPQAAgOAKgJQAJgIAOAAQANAAAHAGIgFARQgHgGgHAAQgGAAgDAEQgFAEAAAGQAAAHAFADQADAEAGAAQAJAAAGgGIAFARQgHAHgOAAQgOAAgJgIg");
	this.shape_15.setTransform(12.4,-121.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#231F20").s().p("AALAfIgDgJIgQAAIgDAJIgVAAIAWg9IAVAAIAWA9gAAEAHIgEgQIgEAQIAIAAg");
	this.shape_16.setTransform(6.475,-121.55);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("An3BZQgQAAgLgMQgMgLAAgRIAAhhQAAgRAMgLQALgMAQAAIPuAAQARAAALAMQAMALAAARIAABhQAAARgMALQgLAMgRAAg");
	this.shape_17.setTransform(54.375,-121.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(0.1,-130.6,108.60000000000001,17.799999999999997), null);


(lib.Btext22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAPQgGgGAAgJQAAgIAGgFQAGgGAJAAQAKAAAGAGQAGAFAAAIQAAAJgGAGQgGAEgKAAQgJAAgGgEg");
	this.shape.setTransform(171.3,-206.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhHBHQgdgaAAgtQAAgsAdgaQAbgZAsAAQAsAAAcAZQAdAaAAAsQAAAtgdAaQgcAagsgBQgsABgbgagAgcgfQgLAMAAASQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgSgLgMQgLgNgSAAQgRAAgLANg");
	this.shape_1.setTransform(158.575,-214.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_2.setTransform(139.875,-214.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgPgKIAKAAQAJAAAEgDQAIgFgBgKQABgKgIgFQgEgDgJAAIgKAAg");
	this.shape_3.setTransform(122.3,-214.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgdBdIAAiKIgsAAIAAgvICTAAIAAAvIgrAAIAACKg");
	this.shape_4.setTransform(100.575,-214.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhABdIAAi5ICBAAIAAAwIhEAAIAAAdIBAAAIAAAvIhAAAIAAA9g");
	this.shape_5.setTransform(85.125,-214.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgeBdIAAi5IA9AAIAAC5g");
	this.shape_6.setTransform(72.9,-214.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAZBdIAAhFIgyAAIAABFIg9AAIAAi5IA9AAIAABDIAyAAIAAhDIA+AAIAAC5g");
	this.shape_7.setTransform(58.55,-214.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhKBHIAbguQALAKARAFQANAFAHAAQAOAAAAgIQAAgFgOgFIgagIQgRgHgIgHQgRgOAAgZQAAgbAVgSQAUgQAiAAQAoAAAbAXIgYArQgJgJgPgFQgMgEgIAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQASAPAAAZQAAAegZATQgVAQggAAQgnAAghgZg");
	this.shape_8.setTransform(40.75,-214.325);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAeBdIgeg7IgdA7IhJAAIA+hgIg6hZIBJAAIAZAyIAagyIBJAAIg7BZIA/Bgg");
	this.shape_9.setTransform(18.275,-214.425);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_10.setTransform(-4.725,-214.425);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhHBHQgdgaAAgtQAAgsAdgaQAbgZAsAAQAsAAAcAZQAdAaAAAsQAAAtgdAaQgcAagsgBQgsABgbgagAgcgfQgLAMAAASQAAATALAMQALAMARAAQASAAALgMQALgMAAgTQAAgSgLgMQgLgNgSAAQgRAAgLANg");
	this.shape_11.setTransform(-25.125,-214.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgQgKIAKAAQAKAAAEgDQAIgFAAgKQAAgKgIgFQgEgDgKAAIgKAAg");
	this.shape_12.setTransform(-43.6,-214.425);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAgBdIgHgaIg0AAIgHAaIhAAAIBBi5IBCAAIBBC5gAAMAUIgNgxIgNAxIAaAAg");
	this.shape_13.setTransform(-62.2,-214.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgdBdIhGi5IBBAAIAiBrIAjhrIBBAAIhGC5g");
	this.shape_14.setTransform(-78.275,-214.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-228.7,266.7,31);


(lib.Btext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape.setTransform(225.125,-222.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhCBdIAAi5ICDAAIAAAwIhHAAIAAAUIBCAAIAAAvIhCAAIAAAWIBKAAIAAAwg");
	this.shape_1.setTransform(207.8,-222.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhABJQgUgUAAgpIAAhqIA9AAIAABtQAAAOAHAGQAGAHAKAAQALAAAHgHQAFgGAAgOIAAhtIA+AAIAABqQAAApgUAUQgWAWgrAAQgpAAgXgWg");
	this.shape_2.setTransform(190,-221.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAgBdIgHgaIg0AAIgHAaIg/AAIBAi5IBCAAIBBC5gAAMAUIgNgxIgNAxIAaAAg");
	this.shape_3.setTransform(171.45,-222.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhPBdIAAi5IBMAAQAeAAAQAHQAMAEAHAKQAJALAAAPQAAAPgIAMQgIAKgKAFQAQADAKAMQAKALgBAQQAAAcgUAOQgTAMgdAAgAgTAwIAUAAQAHAAAGgDQAGgEAAgIQAAgIgGgDQgFgEgIAAIgUAAgAgTgVIANAAQAHAAAFgDQAFgEABgHQgBgHgFgDQgEgDgIAAIgNAAg");
	this.shape_4.setTransform(153.45,-222.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhDBdIAAi5ICEAAIAAAwIhHAAIAAAUIBDAAIAAAvIhDAAIAAAWIBJAAIAAAwg");
	this.shape_5.setTransform(131.25,-222.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag9BdIAAi5IA8AAIAACHIA/AAIAAAyg");
	this.shape_6.setTransform(116.7,-222.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgdBdIAAiKIgsAAIAAgvICTAAIAAAvIgrAAIAACKg");
	this.shape_7.setTransform(80.725,-222.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAOBdIgcg+IgIAAIAAA+Ig9AAIAAi5IBRAAQAhAAAUANQAXAQAAAeQAAAlgfASIApBHgAgXgOIAQAAQAIAAAEgDQAHgFAAgIQAAgIgHgFQgEgDgIAAIgQAAg");
	this.shape_8.setTransform(65.275,-222.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhHBHQgdgaAAgtQAAgsAdgaQAbgaAsAAQAsAAAcAaQAdAaAAAsQAAAtgdAaQgcAZgsAAQgsAAgbgZgAgcggQgLAMAAAUQAAASALAMQALAMARAAQASAAALgMQALgMAAgSQAAgUgLgMQgLgMgSABQgRgBgLAMg");
	this.shape_9.setTransform(44.875,-222.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhMBdIAAi5IBQAAQAhAAATAPQAVARAAAgQAAAfgVARQgTAPghAAIgTAAIAAA6gAgPgKIAJAAQAKAAAFgDQAGgFABgKQgBgKgGgFQgFgDgKAAIgJAAg");
	this.shape_10.setTransform(26.4,-222.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhLBHIAbguQAMAKAQAFQAOAFAHAAQAOAAAAgIQAAgFgNgFIgagIQgTgHgHgHQgRgOAAgZQAAgbAVgSQAUgQAiAAQAoAAAbAXIgYArQgJgJgOgFQgMgEgJAAQgOAAAAAHQAAAFAMAEIAWAHQAVAHAKAIQASAPAAAZQAAAegZATQgUAQgiAAQgmAAgigZg");
	this.shape_11.setTransform(9.55,-222.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgYBDQgJgIAAgPQAAgOAJgIQAKgIAOAAQAQAAAJAIQAJAIAAAOQAAAPgJAIQgJAIgQgBQgOABgKgIgAgYgUQgJgJAAgOQAAgOAJgIQAKgJAOABQAQgBAJAJQAJAIAAAOQAAAOgJAJQgJAHgQABQgOgBgKgHg");
	this.shape_12.setTransform(98.975,-220.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btext1, new cjs.Rectangle(0,-236.4,240.6,31), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-101,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-282.5,222.9,31);


// stage content:
(lib.shift_336x280_fr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(179.75,440.5,1.568,1.568,0,0,0,62,18.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(309).to({_off:false},0).to({alpha:1},22,cjs.Ease.cubicInOut).wait(12));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(-101.85,413.9,1.12,1.12,0,0,0,84.2,10.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(292).to({_off:false},0).to({x:166.9},20,cjs.Ease.quartOut).wait(31));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(166.05,299.5,0.448,0.448,0,0,0,177.6,184.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(268).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(46));

	// skate2
	this.instance_3 = new lib.skate2();
	this.instance_3.setTransform(439.1,498.4,1.12,1.12,0,0,0,57.1,62);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(167).to({_off:false},0).to({regX:57,x:257.5},20,cjs.Ease.quartOut).wait(67).to({regX:57.1,x:449.1},18,cjs.Ease.quintInOut).wait(71));

	// skate1
	this.instance_4 = new lib.skate1();
	this.instance_4.setTransform(291.3,410.55,1.12,1.12,0,0,0,56.1,61.6);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(34).to({_off:false},0).to({x:118.75},20,cjs.Ease.quartOut).to({_off:true},134).wait(155));

	// cta
	this.instance_5 = new lib.CTA();
	this.instance_5.setTransform(94.65,320.25,1.12,1.12,0,0,0,62.1,18.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(145).to({y:294.5},23,cjs.Ease.quartInOut).wait(81).to({y:293.4,alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(76));

	// Ctext3
	this.instance_6 = new lib.Ctext3();
	this.instance_6.setTransform(-103.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(157).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(81));

	// Ctet2
	this.instance_7 = new lib.Ctext2();
	this.instance_7.setTransform(-117.9,283.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(154).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({y:282.9,alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_8 = new lib.Ctext1();
	this.instance_8.setTransform(-103.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(151).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// Btext2
	this.instance_9 = new lib.Btext22();
	this.instance_9.setTransform(-156.25,366.45,1.12,1.12);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(17).to({_off:false},0).to({x:123.25},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(194));

	// Btext1
	this.instance_10 = new lib.Btext1();
	this.instance_10.setTransform(-147.8,372.95,1.12,1.12,0,0,0,74.8,24);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(13).to({_off:false},0).to({x:106.15,y:371.6},22,cjs.Ease.quartOut).wait(93).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(197));

	// text2
	this.instance_11 = new lib.Tween2("synched",0);
	this.instance_11.setTransform(-158.95,366.45,1.12,1.12);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(9).to({_off:false},0).to({x:123.25},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_12 = new lib.text1();
	this.instance_12.setTransform(-206.95,282.9,1.12,1.12,0,0,0,74.8,24);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(5).to({_off:false},0).to({x:106.15},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// bg
	this.instance_13 = new lib.Asset1();
	this.instance_13.setTransform(0,0,0.6021,0.6054);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("EgaPA0gMAAAho/MA0fAAAMAAABo/g");
	this.shape.setTransform(168,336);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_13}]}).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-122.7,140,691.5,532);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 336,
	height: 280,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/shift_336x280_fr_atlas_1.jpg", id:"shift_336x280_fr_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;