(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"speed_300x600_fr_atlas_P_1", frames: [[0,0,555,1110]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset1tearDBL = function() {
	this.initialize(ss["speed_300x600_fr_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAOQgGgEAAgKQAAgIAGgGQAGgEAJAAQAKAAAGAEQAGAGAAAIQAAAKgGAEQgGAGgKAAQgJAAgGgGg");
	this.shape.setTransform(36.8,-181.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag7BaIAAizIA7AAIAACDIA8AAIAAAwg");
	this.shape_1.setTransform(27.425,-188.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhEBFQgcgaAAgrQAAgqAcgZQAbgZApAAQArAAAbAZQAbAZAAAqQAAArgbAaQgbAYgrAAQgqAAgagYgAgbgeQgLALAAATQAAASALALQALAMAQAAQARAAALgMQALgLAAgSQAAgTgLgLQgLgMgRAAQgQAAgLAMg");
	this.shape_2.setTransform(9.9,-188.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAOBaIgcg8IgIAAIAAA8Ig6AAIAAizIBOAAQAgAAATANQAWAQAAAcQAAAkgeASIAoBEgAgWgNIAPAAQAIAAAEgDQAHgFAAgIQAAgHgHgFQgEgDgIAAIgPAAg");
	this.shape_3.setTransform(-8.075,-188.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgdBaIAAiFIgpAAIAAguICOAAIAAAuIgqAAIAACFg");
	this.shape_4.setTransform(-24.65,-188.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAZBaIg2hjIABAfIAABEIg5AAIAAizIBAAAIAzBjIgBgfIAAhEIA5AAIAACzg");
	this.shape_5.setTransform(-41.675,-188.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhFBFQgcgaAAgrQAAgqAcgZQAbgZAqAAQArAAAbAZQAcAZAAAqQAAArgcAaQgbAYgrAAQgqAAgbgYgAgbgeQgLALABATQgBASALALQALAMAQAAQASAAAKgMQAKgLAAgSQAAgTgKgLQgKgMgSAAQgQAAgLAMg");
	this.shape_6.setTransform(-61.8,-188.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgzBFQgcgaAAgrQAAgqAcgaQAbgYAoAAQApAAATARIgPAyQgSgQgXAAQgRAAgLAKQgMAMAAATQAAATANALQAKAJARAAQAbAAAQgQIARAvQgXAXgpgBQgoABgbgYg");
	this.shape_7.setTransform(-79.5,-188.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-202.2,132.2,30);


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag9BGQgUgTAAgnIAAhmIA7AAIAABoQAAAOAGAGQAGAGAKAAQALAAAGgGQAGgGgBgOIAAhoIA8AAIAABmQAAAngTATQgWAVgpAAQgoAAgVgVg");
	this.shape.setTransform(174.8,-142.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhTBaIAAizIBDAAQAtAAAZAUQAfAXAAAuQAAAvgfAXQgZAUgtAAgAgZAoIANAAQARAAAKgJQAKgKAAgVQAAgWgKgKQgKgJgRAAIgNAAg");
	this.shape_1.setTransform(156.5,-142.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhABaIAAizIB+AAIAAAvIhDAAIAAATIBAAAIAAAtIhAAAIAAAVIBGAAIAAAvg");
	this.shape_2.setTransform(134.45,-142.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgzBFQgcgaAAgrQAAgqAcgaQAbgYApAAQAnAAAUARIgPAyQgTgQgWAAQgSAAgJAKQgNAMAAATQAAATANALQAKAJARAAQAbAAAQgQIARAvQgWAXgpgBQgpABgbgYg");
	this.shape_3.setTransform(118.65,-142.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOBaIgcg8IgIAAIAAA8Ig6AAIAAizIBOAAQAgAAATANQAWAQAAAcQAAAkgeASIAoBEgAgWgNIAPAAQAIAAAEgDQAHgFAAgIQAAgHgHgFQgEgDgIAAIgPAAg");
	this.shape_4.setTransform(102.425,-142.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag9BGQgUgTAAgnIAAhmIA7AAIAABoQAAAOAGAGQAHAGAJAAQALAAAGgGQAGgGgBgOIAAhoIA8AAIAABmQAAAngTATQgVAVgqAAQgoAAgVgVg");
	this.shape_5.setTransform(83.65,-142.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhFBFQgcgaAAgrQAAgqAcgZQAcgZApAAQArAAAbAZQAbAZAAAqQAAArgbAaQgbAYgrAAQgqAAgbgYgAgbgeQgKALAAATQAAASAKALQALAMAQAAQARAAALgMQALgLgBgSQABgTgLgLQgLgMgRAAQgQAAgLAMg");
	this.shape_6.setTransform(64.05,-142.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhIBEIAagsQALAKAQAFQANAEAHAAQANAAAAgHQAAgFgNgFIgZgIQgRgGgHgHQgRgNAAgYQAAgaAVgRQATgQAhAAQAmAAAaAVIgWAqQgKgIgNgFQgMgEgIAAQgOAAAAAHQAAAFAMAEIAVAGQAUAHAKAIQARANAAAZQAAAcgXATQgVAPggAAQglAAgggYg");
	this.shape_7.setTransform(46.275,-142.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAfBaIgHgaIgyAAIgHAaIg9AAIA/izIA/AAIA/CzgAAMAUIgNgwIgNAwIAaAAg");
	this.shape_8.setTransform(24.75,-142.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag7BaIAAizIA7AAIAACDIA8AAIAAAwg");
	this.shape_9.setTransform(9.275,-142.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(0,-156.7,186.4,29.999999999999986), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfBxIgHgaIgyAAIgHAaIg9AAIA+izIBAAAIA/CzgAALArIgLgwIgOAwIAZAAgAgRhKIgZglIAuAAIASAlg");
	this.shape.setTransform(216.75,-193.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhABxIAAizIB+AAIAAAvIhDAAIAAATIBAAAIAAAtIhAAAIAAAUIBGAAIAAAwgAgdhKIASglIAuAAIgYAlg");
	this.shape_1.setTransform(195.2,-193.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgcBaIAAiFIgrAAIAAguICOAAIAAAuIgpAAIAACFg");
	this.shape_2.setTransform(180.25,-191.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgcBaIAAizIA5AAIAACzg");
	this.shape_3.setTransform(168.875,-191.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgcBaIhDizIA+AAIAhBnIAihnIA+AAIhDCzg");
	this.shape_4.setTransform(155.325,-191.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcBaIAAizIA5AAIAACzg");
	this.shape_5.setTransform(141.725,-191.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhIBEIAagsQALAKAQAFQANAEAHAAQANAAAAgHQAAgGgNgEIgZgIQgRgGgHgHQgRgNAAgZQAAgZAVgRQATgQAhAAQAmAAAaAVIgWAqQgKgIgNgFQgMgEgIAAQgOAAAAAHQAAAEAMAFIAVAGQAUAGAKAJQARANAAAZQAAAdgXASQgVAPggAAQglAAgggYg");
	this.shape_6.setTransform(129.975,-191.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag+BGQgTgTAAgnIAAhmIA7AAIAABoQAAAOAGAGQAHAGAJAAQALAAAGgGQAGgGgBgOIAAhoIA8AAIAABmQAAAngTATQgVAVgqAAQgoAAgWgVg");
	this.shape_7.setTransform(113.35,-191.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag7BaIAAizIA7AAIAACDIA8AAIAAAwg");
	this.shape_8.setTransform(98.325,-191.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgyBFQgdgaAAgrQAAgqAdgaQAagYAoAAQApAAATARIgQAyQgRgQgXAAQgRAAgLAKQgMAMAAATQAAATANALQAKAJARAAQAbAAAQgQIARAvQgXAXgpAAQgoAAgagYg");
	this.shape_9.setTransform(83.05,-191.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAdBaIgdg6IgcA6IhGAAIA8hdIg5hWIBGAAIAZAwIAZgwIBGAAIg4BWIA8Bdg");
	this.shape_10.setTransform(66.275,-191.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhABaIAAizIB+AAIAAAvIhEAAIAAATIBBAAIAAAtIhBAAIAAAVIBHAAIAAAvg");
	this.shape_11.setTransform(49.65,-191.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAZBaIg2hjIABAfIAABEIg5AAIAAizIBAAAIAzBjIgBgfIAAhEIA5AAIAACzg");
	this.shape_12.setTransform(26.925,-191.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhABaIAAizIB+AAIAAAvIhDAAIAAATIBAAAIAAAtIhAAAIAAAVIBGAAIAAAvg");
	this.shape_13.setTransform(9.8,-191.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(0,-205,228.2,30), null);


(lib.tear = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset1tearDBL();
	this.instance.setTransform(0,0,0.5441,0.5441);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tear, new cjs.Rectangle(0,0,302,604), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AD6W3QgngnAAg6QAAg3AqgkQAngkA3AAQA2AAAoAkQApAkAAA3QAAA6gmAnQgmAmg7AAQg7AAgmgmgAEqUpQgVATAAAaQAAAfAVAVQAUAVAdgBQAdABAUgVQAUgVAAgfQAAgagUgTQgVgUgcAAQgcAAgVAUgAjrXVQgVgGgLgLIAAAAIAAhAIACADQAMANAVAKQAVAJARAAQARAAAHgGQAIgEAAgKQAAgKgJgGQgGgFgagKQhAgYAAg3QAAgiAYgWQAYgXAmABQAWgBASAHQATAGAKAHIAAABIAAA/IgCgCQgJgLgRgJQgTgIgOAAQgOAAgHAFQgHAGAAAJQAAAKAIAGQAGAGAXAIQAfAMATATQATAUAAAbQAAAjgZAXQgZAWgsAAQgaAAgUgHgAqHXAQgQgQgGgZQgEgQAAgeIAAiLIBAAAIAACCQAAAfAHAOQAKAWAbAAQAcAAAJgWQAHgOAAgfIAAiCIBAAAIAACLQAAAegEAQQgGAZgQAQQgcAbg2ABQg2gBgcgbgAM9XVIAAjAIg1AAIAAg3ICqAAIAAA3Ig1AAIAADAgAKYXVIg+hfIAABfIhAAAIAAj3IBkAAQAVAAAPAGQAPAGALAKQAJAKAGAPQAFANAAAQQAAAdgOARQgMARgcAHIBOBlgAJaVMIANAAQATABAKgJQAKgHAAgPQAAgPgKgIQgKgHgTgBIgNAAgAggXVIAAj3IBlAAQApAAAXAVQAWAWAAAoQAAAngWAWQgWAVgqAAIgmAAIAABSgAAfVPIAVAAQAkAAAAgeQAAgfgkAAIgVAAgAuxXVIAAj3IBbAAQA0AAAkAkQAlAkAAAzQAAA1glAjQgkAkg0AAgAtxWeIAOAAQAfAAATgQQAVgTAAgiQAAgggTgSQgTgTggABIgPAAgAQmUEQgHgHAAgKQAAgJAHgHQAHgGAJAAQAFAAAFACIAAANQgEgEgGAAQgFgBgDAEQgDAEAAAEQAAAFADAEQADADAFAAQAFABAFgFIAAANIgBAAIgJACQgJAAgHgGgAQPUJIgEgYIgKAYIgEAAIgKgYIgEAYIgLAAIAHgrIALAAIAJAXIAJgXIALAAIAHArgAWOO/QgwgSgmgkQhQhHAAh0QAAg0ATgvQATgvAjgkQAlglAygWQAygWA0ABQA4AAA+AZIAACbQgTgbgfgPQgegOghABQg7gBglAoQglAnAAA7QAAA8AlAlQAmAmA8AAQAfAAAegOQAdgOAVgZIAACbQgnANgTADQgdAHgbAAQg0AAgwgTgAlFOGQhNhMAAh2QAAhsBThKQBPhGBtAAQBtAABOBGQBTBKAABsQAAB2hNBMQhLBMh2AAQh2AAhMhMgAjlJqQgoAnAAAzQAAA+AoArQAoApA6AAQA5AAApgpQAngrAAg+QAAgzgngnQgqgng4AAQg4AAgqAngAsNPDQgpgNgVgUIgBgBIAAh/IAEAGQAXAaAqATQAqASAhAAQAfABASgLIgBAAQARgMAAgTQAAgUgSgLIAAAAQgQgLgwgSIABAAQiAgvAAhvQAAhDAwgsQAugsBNAAQAqAAAlALIAAABQAkAMAWAPIABACIAAB8IgFgEQgTgWgigQQgigRgeAAQgbAAgPALQgOALAAASQAAATAPANQAQANAqAPQA/AWAlAnQAmAnAAA2QAABGgxAuQgyArhYABQgygBgqgNgAFuPCQgugOgdgdQghgfgLgxQgIghAAg8IAAkTICAAAIAAECQAAA/AMAcQATAqA3AAQA3AAATgqQANgcAAg/IAAkCIB/AAIAAETQAAA9gHAgQgLAxghAfQgdAdguAOQgoAMgwAAQgvAAgogMgAbjPBIAAnqIEXAAIAABsIiXAAIAABSICPAAIAABsIiPAAIAABUICXAAIAABsgAQUPBIh5i9IgBAAIAAC9Ih/AAIAAnqIC+AAQBNAAAsAkQAxAnAABMQAAA1gbAlQgdAngzAKICaDIgAOaKzIAMAAQAnAAAVgKQAdgPAAglQAAgjgdgPQgVgLgnAAIgMAAgA0DPBIgfhVIiwAAIgiBVIiHAAIC9nqICLAAIC4HqgA2vMLIBqAAIg0idIgBAAgA/5PBIAAnqIB/AAIAAF+ICZAAIAABsgAlHgKQh4g6hfhiIAAjkQBsB0BtA8QCYBUC0AAQCcAABohxQBfhoAAiJQAAiIhhhqQhohwiXAAQgvAAgfgfQgegfAAgwQAAgtAiggQAhgdApAAIALAAQB3AABpAtQBqAtBPBVQBJBPApBlQAoBmAABqQAADpilClQilCljpAAQi9gBifhNgAgUl0Qh3gBhqgsQhpguhPhUQhKhPgohlQgohmAAhrQAAjpClilQClilDpAAQEWACDMChIAADeQhrhehzgsQhzgtiEAAQicAAhnByQhfBoAACIQAACIBhBpQBoByCXAAQAugBAfAgQAfAfAAAvQAAAsgjAgQghAfgoAAg");
	this.shape.setTransform(182.7365,186.3146,1.2343,1.2343);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(-69.3,1.1,504.1,370.4), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgQAQQgGgGAAgKQAAgIAGgGQAHgGAJABQALgBAFAGQAHAGAAAIQAAAKgHAGQgFAEgLAAQgJAAgHgEg");
	this.shape.setTransform(210.6,13.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgsAzQgOgPAAgcIAAhJIArAAIAABLQAAAKAEAEQAFAFAGAAQAIAAAEgFQAEgDAAgLIAAhLIArAAIAABJQAAAcgOAPQgPAPgeAAQgdAAgPgPg");
	this.shape_1.setTransform(200.825,9.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBbAAIAAAiIgwAAIAAANIAuAAIAAAhIguAAIAAAPIAyAAIAAAig");
	this.shape_2.setTransform(188.8,9.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AASBBIgnhIIABAXIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_3.setTransform(166.125,9.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgxAxQgVgSABgfQgBgeAVgTQATgRAeAAQAfAAATARQAUATAAAeQAAAfgUASQgTASgfAAQgeAAgTgSgAgUgWQgHAIAAAOQAAAMAHAJQAJAIALAAQANAAAHgIQAIgIgBgNQABgOgIgIQgHgIgNAAQgLAAgJAIg");
	this.shape_4.setTransform(151.55,9.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgUBBIAAhgIgfAAIAAghIBnAAIAAAhIgfAAIAABgg");
	this.shape_5.setTransform(139.75,9.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBcAAIAAAiIgyAAIAAANIAuAAIAAAhIguAAIAAAPIAzAAIAAAig");
	this.shape_6.setTransform(125.65,9.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag0AxIATgfQAIAGAMAEQAJAEAFgBQAJABAAgGQAAgDgJgEIgSgGQgMgFgGgFQgMgJAAgRQAAgTAPgMQAOgMAYAAQAbAAATAQIgQAeQgHgGgKgEQgIgDgGAAQgKAAAAAGQAAADAIADIAQAFQAOAFAIAGQAMAJAAARQAAAWgRANQgPALgXAAQgaAAgYgSg");
	this.shape_7.setTransform(114.575,9.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUBBIAAiBIApAAIAACBg");
	this.shape_8.setTransform(106.275,9.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgqBBIAAiBIAqAAIAABeIArAAIAAAjg");
	this.shape_9.setTransform(98.725,9.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAXBBIgFgTIgkAAIgFATIgtAAIAuiBIAuAAIAtCBgAAJAOIgJgiIgJAiIASAAg");
	this.shape_10.setTransform(86.725,9.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AASBBIgnhIIABAXIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_11.setTransform(72.925,9.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AASBBIgnhIIABAXIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_12.setTransform(58.625,9.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgyAxQgTgSgBgfQABgeATgTQAUgRAeAAQAfAAAUARQATATABAeQgBAfgTASQgUASgfAAQgeAAgUgSgAgTgWQgIAIAAAOQAAAMAIAJQAIAIALAAQAMAAAIgIQAHgIAAgNQAAgOgHgIQgIgIgMAAQgLAAgIAIg");
	this.shape_13.setTransform(44.05,9.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag0AxIATgfQAIAGAMAEQAJAEAFgBQAJABAAgGQAAgDgJgEIgSgGQgMgFgGgFQgMgJAAgRQAAgTAPgMQAOgMAYAAQAbAAATAQIgQAeQgHgGgKgEQgIgDgGAAQgKAAAAAGQAAADAIADIAQAFQAOAFAIAGQAMAJAAARQAAAWgRANQgPALgXAAQgaAAgYgSg");
	this.shape_14.setTransform(31.175,9.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAKBBIgUgrIgFAAIAAArIgrAAIAAiBIA5AAQAXAAANAJQAQAMAAAVQAAAYgVAOIAdAxgAgPgKIAKAAQAGAAADgBQAFgEAAgFQAAgGgFgDQgDgDgGAAIgKAAg");
	this.shape_15.setTransform(20.325,9.15);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBcAAIAAAiIgyAAIAAANIAuAAIAAAhIguAAIAAAPIAzAAIAAAig");
	this.shape_16.setTransform(8.2,9.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag1BBIAAiBIA4AAQAXAAANAKQAPAMAAAXQAAAVgPAMQgNALgXAAIgNAAIAAAogAgKgHIAHAAQAGAAADgCQAFgDAAgHQAAgHgFgDQgDgDgGAAIgHAAg");
	this.shape_17.setTransform(-2.875,9.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AASBBIgnhIIABAXIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_18.setTransform(-19.975,9.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgyAxQgTgSAAgfQAAgeATgTQAUgRAeAAQAfAAATARQAVATgBAeQABAfgVASQgTASgfAAQgeAAgUgSgAgUgWQgHAIAAAOQAAAMAHAJQAJAIALAAQANAAAHgIQAIgIAAgNQAAgOgIgIQgHgIgNAAQgLAAgJAIg");
	this.shape_19.setTransform(-34.55,9.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AiwBBQgIgBgCgBIACgfQAGADAEAAQABAAABAAQABAAAAAAQABgBAAAAQABAAAAAAQACgCAAgFIAAhcIArAAIAABcQAAAUgJAKQgJAJgTAAIgPgBgACtguQgDgDAAgFQAAgFADgDQADgDAFAAIAGABIAAAGQgDgCgCAAQgGAAAAAGQAAAAAAABQAAABAAAAQABABAAAAQAAABABAAQAAABAAAAQABAAAAAAQABABAAAAQABAAABAAQACAAADgDIAAAHIgBAAIgFABQgFAAgDgDgACigrIgCgNIgGANIgBAAIgFgNIgCANIgGAAIAFgWIAEAAIAFAMIAEgMIAGAAIADAWg");
	this.shape_20.setTransform(195.15,9.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(-44.2,-1.6,260.6,23.3), null);


(lib.Ctext3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgRAQQgHgFAAgLQAAgJAHgGQAHgGAKAAQALAAAHAGQAHAGAAAJQAAALgHAFQgHAFgLAAQgKAAgHgFg");
	this.shape.setTransform(198.5,-131.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhABaIAAizIB/AAIAAAvIhEAAIAAATIA/AAIAAAtIg/AAIAAAVIBGAAIAAAvg");
	this.shape_1.setTransform(187.75,-138.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgzBFQgcgZAAgsQAAgrAcgZQAbgXApAAQAogBATASIgPAxQgTgQgWAAQgSAAgKAKQgMAMAAATQAAATANALQAKAJARAAQAbAAAQgQIARAvQgWAXgpgBQgpABgbgYg");
	this.shape_2.setTransform(171.95,-138.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAZBaIg2hjIABAfIAABEIg5AAIAAizIBAAAIAzBjIgBgfIAAhEIA5AAIAACzg");
	this.shape_3.setTransform(153.575,-138.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAfBaIgHgaIgyAAIgHAaIg9AAIA+izIBBAAIA+CzgAALAUIgLgwIgOAwIAZAAg");
	this.shape_4.setTransform(134.5,-138.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAzBaIgChmIgYBmIgxAAIgYhmIgCBmIg6AAIALizIBLAAIAWBhIAXhhIBLAAIALCzg");
	this.shape_5.setTransform(113.625,-138.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAOBaIgcg8IgIAAIAAA8Ig6AAIAAizIBOAAQAgAAATANQAWAQAAAcQAAAkgeASIAoBEgAgWgNIAPAAQAIAAAEgDQAHgFAAgIQAAgHgHgFQgEgDgIAAIgPAAg");
	this.shape_6.setTransform(94.275,-138.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhEBFQgcgaAAgrQAAgqAcgZQAbgZApAAQArAAAbAZQAcAZgBAqQABArgcAaQgbAYgrAAQgqAAgagYgAgbgeQgLALAAATQAAASALALQALAMAQAAQARAAALgMQALgLAAgSQAAgTgLgLQgLgMgRAAQgQAAgLAMg");
	this.shape_7.setTransform(74.6,-138.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag9BaIAAizIB7AAIAAAvIhBAAIAAAcIA+AAIAAAtIg+AAIAAA7g");
	this.shape_8.setTransform(57.975,-138.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAOBaIgcg8IgIAAIAAA8Ig6AAIAAizIBOAAQAgAAATANQAWAQAAAcQAAAkgeASIAoBEgAgWgNIAPAAQAIAAAEgDQAHgFAAgIQAAgHgHgFQgEgDgIAAIgPAAg");
	this.shape_9.setTransform(42.725,-138.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhABaIAAizIB/AAIAAAvIhFAAIAAATIBAAAIAAAtIhAAAIAAAVIBHAAIAAAvg");
	this.shape_10.setTransform(26.05,-138.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhJBaIAAizIBNAAQAgAAASAPQAUAQAAAfQAAAegUARQgSAOggAAIgSAAIAAA4gAgOgJIAJAAQAJAAAEgDQAHgFAAgKQAAgKgHgEQgEgDgJAAIgJAAg");
	this.shape_11.setTransform(10.7,-138.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext3, new cjs.Rectangle(0,-152.5,204.2,30), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfBaIgHgaIgyAAIgHAaIg9AAIA+izIBBAAIA+CzgAALAUIgLgwIgOAwIAZAAg");
	this.shape.setTransform(186.25,-164.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag7BaIAAizIA7AAIAACDIA8AAIAAAwg");
	this.shape_1.setTransform(170.775,-164.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdBaIAAiFIgpAAIAAguICOAAIAAAuIgqAAIAACFg");
	this.shape_2.setTransform(151.3,-164.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhABaIAAizIB/AAIAAAvIhEAAIAAATIA/AAIAAAtIg/AAIAAAVIBGAAIAAAvg");
	this.shape_3.setTransform(136.9,-164.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgdBaIAAiFIgqAAIAAguICOAAIAAAuIgpAAIAACFg");
	this.shape_4.setTransform(116.9,-164.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOBaIgcg8IgIAAIAAA8Ig6AAIAAizIBOAAQAgAAATANQAWAQAAAcQAAAkgeASIAoBEgAgWgNIAPAAQAIAAAEgDQAHgFAAgIQAAgHgHgFQgEgDgIAAIgPAAg");
	this.shape_5.setTransform(102.025,-164.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhEBFQgcgaAAgrQAAgqAcgZQAbgZApAAQArAAAbAZQAbAZAAAqQAAArgbAaQgbAYgrAAQgqAAgagYgAgbgeQgLALAAATQAAASALALQALAMAQAAQARAAALgMQALgLAAgSQAAgTgLgLQgLgMgRAAQgQAAgLAMg");
	this.shape_6.setTransform(82.35,-164.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag9BaIAAizIB7AAIAAAvIhBAAIAAAcIA+AAIAAAtIg+AAIAAA7g");
	this.shape_7.setTransform(65.725,-164.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAZBaIg2hjIABAfIAABEIg5AAIAAizIBAAAIAzBjIgBgfIAAhEIA5AAIAACzg");
	this.shape_8.setTransform(48.325,-164.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhFBFQgcgaAAgrQAAgqAcgZQAbgZAqAAQArAAAbAZQAcAZAAAqQAAArgcAaQgbAYgrAAQgqAAgbgYgAgbgeQgLALABATQgBASALALQALAMAQAAQASAAAKgMQAKgLAAgSQAAgTgKgLQgKgMgSAAQgQAAgLAMg");
	this.shape_9.setTransform(28.2,-164.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgzBFQgcgZAAgsQAAgqAcgZQAbgZAoAAQApABATARIgPAxQgSgQgXAAQgRAAgLALQgMAKAAAUQAAATANALQAKAKARAAQAbAAAQgRIARAvQgXAWgpABQgoAAgbgYg");
	this.shape_10.setTransform(10.5,-164.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(0,-178.7,197.7,30), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhABaIAAizIB+AAIAAAvIhDAAIAAATIBAAAIAAAtIhAAAIAAAVIBGAAIAAAvg");
	this.shape.setTransform(227.05,-189.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag7BaIAAizIA7AAIAACDIA8AAIAAAwg");
	this.shape_1.setTransform(213.025,-189.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOBaIgcg8IgIAAIAAA8Ig6AAIAAizIBOAAQAgAAATANQAWAQAAAcQAAAkgeASIAoBEgAgWgNIAPAAQAIAAAEgDQAHgFAAgIQAAgHgHgFQgEgDgIAAIgPAAg");
	this.shape_2.setTransform(192.975,-189.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag+BGQgTgTAAgnIAAhmIA7AAIAABoQAAAOAGAGQAGAGAKAAQAKAAAHgGQAGgGAAgOIAAhoIA7AAIAABmQAAAngUATQgVAVgpAAQgoAAgWgVg");
	this.shape_3.setTransform(174.2,-189.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhEBFQgdgaAAgrQAAgqAdgZQAbgZApAAQArAAAbAZQAcAZgBAqQABArgcAaQgbAYgrAAQgqAAgagYgAgbgeQgKALAAATQAAASAKALQALAMAQAAQARAAALgMQALgLAAgSQAAgTgLgLQgLgMgRAAQgQAAgLAMg");
	this.shape_4.setTransform(154.6,-189.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhJBaIAAizIBNAAQAgAAASAPQAUAQAAAfQAAAegUARQgSAOggAAIgSAAIAAA4gAgOgJIAJAAQAJAAAEgDQAHgFAAgKQAAgKgHgEQgEgDgJAAIgJAAg");
	this.shape_5.setTransform(136.8,-189.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhABwIAAiyIB+AAIAAAvIhEAAIAAATIBBAAIAAAtIhBAAIAAAUIBHAAIAAAvgAgdhKIATgmIAtAAIgZAmg");
	this.shape_6.setTransform(115.8,-192.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhIBEIAagsQALAJAQAGQANAEAHABQANgBAAgHQAAgGgNgEIgZgIQgRgGgHgHQgRgNAAgZQAAgaAVgQQATgQAhAAQAmAAAaAVIgWAqQgKgIgNgFQgMgEgIAAQgOAAAAAHQAAAFAMAEIAVAGQAUAGAKAJQARAOAAAYQAAAdgXASQgVAPggAAQglAAgggYg");
	this.shape_7.setTransform(100.475,-189.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgcBaIAAizIA5AAIAACzg");
	this.shape_8.setTransform(88.975,-189.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAzBaIgChmIgYBmIgxAAIgYhmIgCBmIg6AAIALizIBLAAIAWBhIAXhhIBLAAIALCzg");
	this.shape_9.setTransform(73.125,-189.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgcBaIAAizIA5AAIAACzg");
	this.shape_10.setTransform(57.275,-189.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgdBaIAAiFIgpAAIAAguICNAAIAAAuIgpAAIAACFg");
	this.shape_11.setTransform(45.9,-189.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhJBaIAAizIBNAAQAgAAASAPQAUAQAAAfQAAAegUARQgSAOggAAIgTAAIAAA4gAgPgJIAKAAQAJAAAEgDQAHgFAAgKQAAgKgHgEQgEgDgJAAIgKAAg");
	this.shape_12.setTransform(31.2,-189.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhEBFQgcgaAAgrQAAgqAcgZQAbgZApAAQArAAAbAZQAbAZAAAqQAAArgbAaQgbAYgrAAQgqAAgagYgAgbgeQgLALAAATQAAASALALQALAMAQAAQARAAALgMQALgLAAgSQAAgTgLgLQgLgMgRAAQgQAAgLAMg");
	this.shape_13.setTransform(12.25,-189.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(0,-203.7,236.5,30), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#221F20").s().p("AgMAnIAAg5IgTAAIAAgUIA+AAIAAAUIgSAAIAAA5g");
	this.shape.setTransform(129.9,-49.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#221F20").s().p("AALAnIgXgrIABAOIAAAdIgaAAIAAhNIAcAAIAWAqIAAgMIAAgeIAZAAIAABNg");
	this.shape_1.setTransform(122.375,-49.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#221F20").s().p("AAOAnIgEgLIgVAAIgDALIgbAAIAchNIAbAAIAcBNgAAFAJIgFgUIgGAUIALAAg");
	this.shape_2.setTransform(114.075,-49.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#221F20").s().p("AALAnIgXgrIABAOIAAAdIgaAAIAAhNIAcAAIAWAqIAAgMIAAgeIAZAAIAABNg");
	this.shape_3.setTransform(105.625,-49.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#221F20").s().p("AgcAnIAAhNIA4AAIAAAUIgeAAIAAAJIAcAAIAAATIgcAAIAAAJIAfAAIAAAUg");
	this.shape_4.setTransform(98.125,-49.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#221F20").s().p("AgMAnIAAg5IgSAAIAAgUIA+AAIAAAUIgTAAIAAA5g");
	this.shape_5.setTransform(91.6,-49.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#221F20").s().p("AALAnIgXgrIABAOIAAAdIgaAAIAAhNIAcAAIAWAqIAAgMIAAgeIAZAAIAABNg");
	this.shape_6.setTransform(84.075,-49.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#221F20").s().p("AgMAnIAAhNIAZAAIAABNg");
	this.shape_7.setTransform(77.9,-49.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#221F20").s().p("AAOAnIgEgLIgVAAIgDALIgbAAIAchNIAbAAIAcBNgAAFAJIgFgUIgGAUIALAAg");
	this.shape_8.setTransform(72.025,-49.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#221F20").s().p("AAWAnIgBgsIgKAsIgVAAIgLgsIAAAsIgaAAIAFhNIAhAAIAJApIAKgpIAhAAIAFBNg");
	this.shape_9.setTransform(62.875,-49.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#221F20").s().p("AAGAnIgLgaIgEAAIAAAaIgaAAIAAhNIAjAAQANAAAJAFQAJAHAAAMQAAAQgNAHIASAegAgJgFIAHAAQADAAABgCQADgCAAgDQAAgDgDgCQgBgCgDAAIgHAAg");
	this.shape_10.setTransform(52.125,-49.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#221F20").s().p("AgcAnIAAhNIA4AAIAAAUIgeAAIAAAJIAcAAIAAATIgcAAIAAAJIAfAAIAAAUg");
	this.shape_11.setTransform(44.825,-49.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#221F20").s().p("AgMAnIAAg5IgSAAIAAgUIA+AAIAAAUIgTAAIAAA5g");
	this.shape_12.setTransform(38.3,-49.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#221F20").s().p("AgcAnIAAhNIA4AAIAAAUIgeAAIAAAJIAcAAIAAATIgcAAIAAAJIAfAAIAAAUg");
	this.shape_13.setTransform(31.975,-49.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#221F20").s().p("AALAnIAAgdIgVAAIAAAdIgaAAIAAhNIAaAAIAAAcIAVAAIAAgcIAaAAIAABNg");
	this.shape_14.setTransform(24.325,-49.55);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#221F20").s().p("AgWAeQgMgLAAgTQAAgSAMgLQAMgLARAAQASAAAJAIIgHAVQgJgHgJAAQgIAAgEAFQgFAFAAAIQAAAIAGAFQAEAEAHAAQALAAAIgHIAHAVQgKAKgSAAQgRAAgMgLg");
	this.shape_15.setTransform(16.6,-49.525);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#221F20").s().p("AAOAnIgEgLIgVAAIgDALIgbAAIAchNIAbAAIAcBNgAAFAJIgFgUIgGAUIALAAg");
	this.shape_16.setTransform(9.075,-49.55);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("ApKBmQgQAAgMgLQgMgMAAgRIAAh7QAAgRAMgLQAMgMAQAAISVAAQARAAAMAMQALALAAARIAAB7QAAARgLAMQgMALgRAAg");
	this.shape_17.setTransform(69.7166,-49.7031,1.0999,1.0999);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(0.8,-60.9,137.89999999999998,22.5), null);


(lib.Btext22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhUBaIAAizIBEAAQAtAAAZAUQAfAXAAAuQAAAvgfAXQgZAUgtAAgAgZAoIANAAQARAAAKgJQAKgKAAgVQAAgWgKgKQgKgJgRAAIgNAAg");
	this.shape.setTransform(82.7,-213.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhABaIAAizIB+AAIAAAvIhDAAIAAATIA/AAIAAAtIg/AAIAAAVIBGAAIAAAvg");
	this.shape_1.setTransform(65.7,-213.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhABaIAAizIB+AAIAAAvIhDAAIAAATIBAAAIAAAtIhAAAIAAAVIBGAAIAAAvg");
	this.shape_2.setTransform(50.65,-213.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhJBaIAAizIBNAAQAgAAASAPQAUAQAAAfQAAAegUARQgSAOggAAIgSAAIAAA4gAgOgJIAJAAQAJAAAFgDQAGgFAAgKQAAgKgGgEQgFgDgJAAIgJAAg");
	this.shape_3.setTransform(35.3,-213.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhIBEIAagsQALAJAQAGQANAFAHgBQANABAAgIQAAgFgNgFIgZgHQgRgIgHgGQgRgNAAgYQAAgbAVgRQATgPAhAAQAmAAAaAWIgWApQgKgIgNgFQgMgEgIAAQgOAAAAAHQAAAFAMADIAVAHQAUAGAKAJQARAOAAAYQAAAcgXATQgVAPggAAQglAAgggYg");
	this.shape_4.setTransform(19.075,-213.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdBaIAAiFIgpAAIAAguICOAAIAAAuIgqAAIAACFg");
	this.shape_5.setTransform(5.05,-213.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhABaIAAizIB/AAIAAAvIhEAAIAAATIA/AAIAAAtIg/AAIAAAVIBGAAIAAAvg");
	this.shape_6.setTransform(-9.35,-213.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAzBaIgChmIgYBmIgxAAIgYhmIgCBmIg6AAIALizIBLAAIAWBhIAXhhIBLAAIALCzg");
	this.shape_7.setTransform(-43.925,-213.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgyBFQgdgZAAgsQAAgrAdgZQAagXAoAAQApgBATASIgQAxQgRgQgXAAQgRAAgLAKQgMAMAAATQAAATANALQAKAJARAAQAbAAAQgQIARAvQgXAXgpgBQgoABgagYg");
	this.shape_8.setTransform(-63.55,-213.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgzBFQgcgZAAgsQAAgrAcgZQAbgXAoAAQApgBATASIgPAxQgSgQgXAAQgRAAgLAKQgMAMAAATQAAATANALQAKAJARAAQAbAAAQgQIARAvQgXAXgpgBQgoABgbgYg");
	this.shape_9.setTransform(-79.5,-213.35);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgIBaIgUgCQgKgBgDgCIADgqQAHACAHAAIAGAAQADgDAAgGIAAh9IA5AAIAAB9QAAAcgNAOQgNAMgXAAIgBAAg");
	this.shape_10.setTransform(-22.125,-213.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-227.2,183.9,30);


(lib.Btext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgWA+QgJgIAAgNQAAgNAJgIQAJgHANAAQAPAAAIAHQAJAIAAANQAAANgJAIQgIAHgPAAQgNAAgJgHgAgWgTQgJgHAAgOQAAgNAJgIQAJgHANAAQAPAAAIAHQAJAIAAANQAAANgJAIQgIAHgPAAQgNAAgJgHg");
	this.shape.setTransform(94.575,-218.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhABaIAAizIB/AAIAAAvIhFAAIAAATIBBAAIAAAtIhBAAIAAAVIBHAAIAAAvg");
	this.shape_1.setTransform(126.5,-219.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag7BaIAAizIA7AAIAACDIA8AAIAAAwg");
	this.shape_2.setTransform(112.475,-219.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgdBaIAAiFIgpAAIAAguICNAAIAAAuIgpAAIAACFg");
	this.shape_3.setTransform(77.85,-219.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOBaIgcg8IgIAAIAAA8Ig6AAIAAizIBOAAQAgAAATANQAWAQAAAcQAAAkgeASIAoBEgAgWgNIAPAAQAIAAAEgDQAHgFAAgIQAAgHgHgFQgEgDgIAAIgPAAg");
	this.shape_4.setTransform(62.975,-219.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhEBFQgcgaAAgrQAAgqAcgZQAbgZApAAQArAAAbAZQAbAZAAAqQAAArgbAaQgbAYgrAAQgqAAgagYgAgbgeQgLALAAATQAAASALALQALAMAQAAQARAAALgMQALgLAAgSQAAgTgLgLQgLgMgRAAQgQAAgLAMg");
	this.shape_5.setTransform(43.3,-219.725);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhJBaIAAizIBNAAQAgAAASAPQAUAQAAAfQAAAegUARQgSAOggAAIgTAAIAAA4gAgPgJIAKAAQAJAAAFgDQAGgFAAgKQAAgKgGgEQgFgDgJAAIgKAAg");
	this.shape_6.setTransform(25.5,-219.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhIBEIAagsQALAJAQAGQANAEAHABQANAAAAgIQAAgGgNgDIgZgJQgRgHgHgGQgRgNAAgZQAAgZAVgSQATgPAhAAQAmAAAaAVIgWAqQgKgIgNgFQgMgEgIAAQgOAAAAAHQAAAEAMAFIAVAGQAUAGAKAJQARAOAAAYQAAAdgXASQgVAPggAAQglAAgggYg");
	this.shape_7.setTransform(9.275,-219.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btext1, new cjs.Rectangle(0,-234.5,136,31), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-97.8,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-278.5,186.4,30);


// stage content:
(lib.speed_300x600_fr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(142,530.95,1,1,0,0,0,62,18);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(309).to({_off:false},0).to({alpha:1},22,cjs.Ease.cubicInOut).wait(12));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(-130.95,369.5,1,1,0,0,0,84.2,10.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(292).to({_off:false},0).to({x:149.05},20,cjs.Ease.quartOut).wait(31));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(148.25,267.4,0.4,0.4,0,0,0,177.5,184.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(268).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(46));

	// cta
	this.instance_3 = new lib.CTA();
	this.instance_3.setTransform(84.45,259.65,1,1,0,0,0,62,18);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(145).to({y:214.65},23,cjs.Ease.quartInOut).wait(81).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(76));

	// Ctext3
	this.instance_4 = new lib.Ctext3();
	this.instance_4.setTransform(-92.7,252.6,1,1,0,0,0,74.8,24);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(157).to({_off:false},0).to({x:94.8},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(81));

	// Ctet2
	this.instance_5 = new lib.Ctext2();
	this.instance_5.setTransform(-105.2,252.6,1,1,0,0,0,74.8,24);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(154).to({_off:false},0).to({x:94.8,y:253.85},22,cjs.Ease.quartOut).wait(65).to({y:252.6,alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_6 = new lib.Ctext1();
	this.instance_6.setTransform(-92.7,252.6,1,1,0,0,0,74.8,24);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(151).to({_off:false},0).to({x:94.8,y:253.85},22,cjs.Ease.quartOut).wait(65).to({y:252.6,alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// Btext2_copy
	this.instance_7 = new lib.text3();
	this.instance_7.setTransform(-159.95,327.2);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(19).to({_off:false},0).to({x:110.05},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(192));

	// Btext2
	this.instance_8 = new lib.Btext22();
	this.instance_8.setTransform(-139.55,327.2);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(17).to({_off:false},0).to({x:110.05},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(194));

	// Btext1
	this.instance_9 = new lib.Btext1();
	this.instance_9.setTransform(-132,333,1,1,0,0,0,74.8,24);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(13).to({_off:false},0).to({x:94.8,y:331.8},22,cjs.Ease.quartOut).wait(93).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(197));

	// text2
	this.instance_10 = new lib.Tween2("synched",0);
	this.instance_10.setTransform(-141.95,327.2);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(9).to({_off:false},0).to({x:110.05},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_11 = new lib.text1();
	this.instance_11.setTransform(-184.8,252.6,1,1,0,0,0,74.8,24);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(5).to({_off:false},0).to({x:94.8},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// rip
	this.instance_12 = new lib.tear();
	this.instance_12.setTransform(150.6,636.5,1,1,0,0,0,151.6,302);
	this.instance_12.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({y:299,alpha:1},26,cjs.Ease.quartOut).wait(231).to({y:667.75,alpha:0},22,cjs.Ease.quartInOut).wait(64));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-109.6,297,410.6,672.8);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/speed_300x600_fr_atlas_P_1.png", id:"speed_300x600_fr_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;