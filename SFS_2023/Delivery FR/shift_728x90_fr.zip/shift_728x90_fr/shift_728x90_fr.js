(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"shift_728x90_fr_atlas_1", frames: [[0,0,558,1110],[0,1112,510,184]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset1 = function() {
	this.initialize(ss["shift_728x90_fr_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset2pngcopy = function() {
	this.initialize(ss["shift_728x90_fr_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgSAyQgHgGAAgLQAAgKAHgHQAHgGALAAQAMAAAHAGQAHAHAAAKQAAALgHAGQgHAGgMAAQgLAAgHgGgAgSgPQgHgGAAgLQAAgLAHgGQAHgGALAAQAMAAAHAGQAHAGAAALQAAAKgHAHQgHAFgMAAQgLAAgHgFg");
	this.shape.setTransform(75.975,-153.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPAOQgGgEAAgKQAAgIAGgGQAGgEAJgBQAKABAGAEQAGAGAAAIQAAAKgGAEQgGAGgKAAQgJAAgGgGg");
	this.shape_1.setTransform(386.7,-147.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag3A3QgXgUAAgjQAAgiAXgUQAWgUAhAAQAjAAAVAUQAXAUAAAiQAAAjgXAUQgVAUgjAAQgiAAgVgUgAgVgYQgJAJAAAPQAAAOAJAJQAIAKANAAQAOAAAJgKQAIgJAAgOQAAgPgIgJQgJgKgOAAQgNAAgIAKg");
	this.shape_2.setTransform(376.125,-153.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AALBJIgWgxIgGAAIAAAxIgwAAIAAiRIBAAAQAaAAAPALQASAMAAAYQAAAcgZAOIAhA4gAgSgLIANAAQAGABADgDQAGgEgBgGQABgGgGgEQgDgDgGAAIgNAAg");
	this.shape_3.setTransform(361.6,-153.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag7BJIAAiRIA+AAQAaAAAPAMQAQANAAAZQAAAZgQANQgPAMgaAAIgOAAIAAAtgAgMgHIAIAAQAHAAAEgDQAFgDAAgJQAAgIgFgDQgEgDgHAAIgIAAg");
	this.shape_4.setTransform(347.925,-153.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgXBJIAAhrIgiAAIAAgmIBzAAIAAAmIgiAAIAABrg");
	this.shape_5.setTransform(331.075,-153.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgxBJIAAiRIBkAAIAAAmIg1AAIAAAWIAxAAIAAAlIgxAAIAAAwg");
	this.shape_6.setTransform(318.85,-153.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgXBJIAAiRIAvAAIAACRg");
	this.shape_7.setTransform(309.375,-153.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAUBJIAAg2IgnAAIAAA2IgvAAIAAiRIAvAAIAAA1IAnAAIAAg1IAvAAIAACRg");
	this.shape_8.setTransform(298.225,-153.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag6A3IAVgkQAJAIANAFQALADAFAAQALAAAAgGQAAgEgLgEIgUgGQgOgGgGgFQgNgKAAgUQAAgVARgOQAPgMAaAAQAfAAAVARIgSAhQgHgGgMgEQgJgDgGAAQgLAAAAAGQAAADAJADIARAGQAQAFAIAHQAOAKAAAVQAAAWgTAPQgQAMgaAAQgeAAgagTg");
	this.shape_9.setTransform(284.375,-153.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAXBJIgXgvIgWAvIg5AAIAwhLIgthGIA4AAIAUAoIAUgoIA5AAIguBGIAxBLg");
	this.shape_10.setTransform(266.925,-153.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AALBJIgWgxIgGAAIAAAxIgwAAIAAiRIA/AAQAaAAAPALQASAMAAAYQABAcgZAOIAhA4gAgRgLIALAAQAHABADgDQAFgEABgGQgBgGgFgEQgDgDgHAAIgLAAg");
	this.shape_11.setTransform(249.05,-153.45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag3A3QgXgUAAgjQAAgiAXgUQAWgUAhAAQAjAAAVAUQAXAUAAAiQAAAjgXAUQgVAUgjAAQgiAAgVgUgAgVgYQgJAJAAAPQAAAOAJAJQAIAKANAAQAOAAAJgKQAIgJAAgOQAAgPgIgJQgJgKgOAAQgNAAgIAKg");
	this.shape_12.setTransform(233.175,-153.425);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag7BJIAAiRIA+AAQAaAAAPAMQAQANAAAZQAAAZgQANQgPAMgaAAIgOAAIAAAtgAgMgHIAIAAQAHAAAEgDQAFgDAAgJQAAgIgFgDQgEgDgHAAIgIAAg");
	this.shape_13.setTransform(218.825,-153.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAaBJIgHgVIgoAAIgFAVIgxAAIAyiRIA0AAIAyCRgAAJAQIgJgmIgKAmIATAAg");
	this.shape_14.setTransform(204.35,-153.45);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgWBJIg3iRIAzAAIAaBUIAbhUIAzAAIg3CRg");
	this.shape_15.setTransform(192.325,-153.45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AALBJIgWgxIgGAAIAAAxIgvAAIAAiRIA/AAQAaAAAOALQATAMgBAYQABAcgZAOIAgA4gAgRgLIALAAQAHABADgDQAFgEABgGQgBgGgFgEQgDgDgHAAIgLAAg");
	this.shape_16.setTransform(174.45,-153.45);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgzBJIAAiRIBmAAIAAAmIg3AAIAAAPIAzAAIAAAlIgzAAIAAAQIA4AAIAAAng");
	this.shape_17.setTransform(161,-153.45);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgxA5QgQgQAAggIAAhSIAvAAIAABUQABALAFAFQAEAFAIAAQAJAAAEgFQAFgEABgMIAAhUIAvAAIAABSQAAAggQAQQgRARghAAQggAAgRgRg");
	this.shape_18.setTransform(147.15,-153.325);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAaBJIgHgVIgoAAIgFAVIgyAAIAziRIA0AAIAxCRgAAJAQIgJgmIgKAmIATAAg");
	this.shape_19.setTransform(132.7,-153.45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("Ag+BJIAAiRIA8AAQAXAAANAGQAJADAFAIQAHAIAAANQAAALgGAKQgGAHgIADQANADAHAJQAIAJAAANQAAAWgRAKQgOAKgXAAgAgPAmIAPAAQAHAAAEgEQAEgCAAgGQAAgHgEgCQgEgCgHgBIgPAAgAgPgQIAKAAQAGAAADgDQAFgCAAgGQAAgFgFgDQgDgCgGAAIgKAAg");
	this.shape_20.setTransform(118.725,-153.45);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ag0BJIAAiRIBnAAIAAAmIg3AAIAAAPIAzAAIAAAlIgzAAIAAAQIA4AAIAAAng");
	this.shape_21.setTransform(101.5,-153.45);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgvBJIAAiRIAvAAIAABpIAwAAIAAAog");
	this.shape_22.setTransform(90.175,-153.45);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgXBJIAAhrIgiAAIAAgmIBzAAIAAAmIgiAAIAABrg");
	this.shape_23.setTransform(62.325,-153.45);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AALBJIgWgxIgGAAIAAAxIgwAAIAAiRIA/AAQAbAAAPALQARAMABAYQgBAcgYAOIAhA4gAgSgLIANAAQAGABADgDQAGgEgBgGQABgGgGgEQgDgDgGAAIgNAAg");
	this.shape_24.setTransform(50.3,-153.45);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("Ag3A3QgXgUAAgjQAAgiAXgUQAWgUAhAAQAjAAAVAUQAXAUAAAiQAAAjgXAUQgVAUgjAAQgiAAgVgUgAgVgYQgJAJAAAPQAAAOAJAJQAIAKANAAQAOAAAJgKQAIgJAAgOQAAgPgIgJQgJgKgOAAQgNAAgIAKg");
	this.shape_25.setTransform(34.425,-153.425);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("Ag7BJIAAiRIA+AAQAaAAAPAMQAQANAAAZQAAAZgQANQgPAMgaAAIgOAAIAAAtgAgMgHIAIAAQAHAAAEgDQAFgDAAgJQAAgIgFgDQgEgDgHAAIgIAAg");
	this.shape_26.setTransform(20.075,-153.45);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("Ag6A3IAVgkQAJAIANAFQALADAFAAQALAAAAgGQAAgEgLgEIgUgGQgOgGgGgFQgNgKAAgUQAAgVARgOQAPgMAaAAQAfAAAVARIgSAhQgHgGgMgEQgJgDgGAAQgLAAAAAGQAAADAJADIARAGQAQAFAIAHQAOAKAAAVQAAAWgTAPQgQAMgaAAQgeAAgagTg");
	this.shape_27.setTransform(6.975,-153.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(-0.9,-166.7,393,26.69999999999999), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgyA5QgPgQAAggIAAhSIAwAAIAABUQgBALAGAFQAEAFAIAAQAIAAAGgFQAEgEAAgMIAAhUIAwAAIAABSQAAAggPAQQgSARghAAQggAAgSgRg");
	this.shape.setTransform(324.95,-196.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhDBIIAAiQIA2AAQAlABAUAPQAYATAAAlQAAAmgYATQgUAPglAAgAgUAhIALAAQAOgBAHgHQAIgIAAgRQAAgRgIgIQgHgIgOABIgLAAg");
	this.shape_1.setTransform(310.175,-196.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgzBIIAAiQIBlAAIAAAmIg2AAIAAAPIAzAAIAAAlIgzAAIAAAQIA4AAIAAAmg");
	this.shape_2.setTransform(292.4,-196.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgpA4QgXgVAAgjQAAgiAXgVQAWgTAgAAQAhAAAPAOIgMAoQgPgNgSAAQgOAAgIAIQgKAJAAAQQAAAPAKAJQAJAIANAAQAWAAANgNIAOAlQgTATghAAQggAAgWgTg");
	this.shape_3.setTransform(279.675,-196.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AALBIIgWgwIgGAAIAAAwIgvAAIAAiQIA/AAQAZAAAQALQASAMAAAYQAAAcgZAOIAgA3gAgSgLIAMAAQAHAAADgCQAGgEgBgGQABgGgGgEQgDgCgHgBIgMAAg");
	this.shape_4.setTransform(266.55,-196.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgyA5QgPgQAAggIAAhSIAwAAIAABUQAAALAEAFQAGAFAHAAQAJAAAEgFQAGgEAAgMIAAhUIAvAAIAABSQAAAggQAQQgQARgiAAQghAAgRgRg");
	this.shape_5.setTransform(251.4,-196.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag3A3QgXgUAAgjQAAgiAXgUQAWgUAhAAQAjAAAVAUQAXAUAAAiQAAAjgXAUQgVAUgjAAQgiAAgVgUgAgVgYQgJAJAAAPQAAAOAJAJQAIAKANAAQAOAAAJgKQAIgJAAgOQAAgPgIgJQgJgKgOAAQgNAAgIAKg");
	this.shape_6.setTransform(235.575,-196.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag6A3IAVgkQAJAIANAEQALAFAFAAQALgBAAgGQAAgEgLgEIgUgGQgOgGgGgFQgNgKAAgTQAAgWARgOQAPgMAaAAQAfAAAVARIgSAhQgHgGgMgEQgJgDgGAAQgLAAAAAFQAAAEAJADIARAGQAQAFAIAHQAOAKAAAVQAAAWgTAPQgQAMgaAAQgeABgagUg");
	this.shape_7.setTransform(221.225,-196.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAZBIIgFgUIgpAAIgFAUIgyAAIAziQIAzAAIAzCQgAAKAQIgKgmIgLAmIAVAAg");
	this.shape_8.setTransform(203.85,-196.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgvBIIAAiQIAvAAIAABpIAwAAIAAAng");
	this.shape_9.setTransform(191.375,-196.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAaBbIgHgVIgoAAIgFAVIgyAAIAziQIA0AAIAxCQgAAKAiIgKgmIgKAmIAUAAgAgNg7IgUgfIAkAAIAQAfg");
	this.shape_10.setTransform(174,-198.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag0BbIAAiQIBnAAIAAAlIg4AAIAAAQIA0AAIAAAkIg0AAIAAARIA6AAIAAAmgAgXg7IAOgfIAlAAIgUAfg");
	this.shape_11.setTransform(156.65,-198.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgXBIIAAhrIgiAAIAAglIBzAAIAAAlIgiAAIAABrg");
	this.shape_12.setTransform(144.575,-196.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgXBIIAAiQIAvAAIAACQg");
	this.shape_13.setTransform(135.425,-196.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgWBIIg3iQIAzAAIAaBUIAbhUIAzAAIg3CQg");
	this.shape_14.setTransform(124.475,-196.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgXBIIAAiQIAvAAIAACQg");
	this.shape_15.setTransform(113.525,-196.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ag6A3IAVgkQAJAIANAEQALAFAFAAQALgBAAgGQAAgEgLgEIgUgGQgOgGgGgFQgNgKAAgTQAAgWARgOQAPgMAaAAQAfAAAVARIgSAhQgHgGgMgEQgJgDgGAAQgLAAAAAFQAAAEAJADIARAGQAQAFAIAHQAOAKAAAVQAAAWgTAPQgQAMgaAAQgeABgagUg");
	this.shape_16.setTransform(104.025,-196.35);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgxA5QgQgQAAggIAAhSIAvAAIAABUQAAALAGAFQAEAFAIAAQAIAAAGgFQAEgEAAgMIAAhUIAwAAIAABSQAAAggPAQQgRARgiAAQghAAgQgRg");
	this.shape_17.setTransform(90.6,-196.275);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgvBIIAAiQIAvAAIAABpIAwAAIAAAng");
	this.shape_18.setTransform(78.475,-196.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgpA4QgXgVAAgjQAAgiAXgVQAWgTAgAAQAhAAAPAOIgMAoQgPgNgSAAQgOAAgIAIQgKAJAAAQQAAAPAKAJQAJAIANAAQAWAAANgNIAOAlQgTATghAAQggAAgWgTg");
	this.shape_19.setTransform(66.175,-196.375);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAXBIIgXguIgWAuIg5AAIAwhKIgthGIA4AAIAUAoIAUgoIA5AAIguBGIAxBKg");
	this.shape_20.setTransform(52.625,-196.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ag0BIIAAiQIBnAAIAAAmIg4AAIAAAPIA0AAIAAAlIg0AAIAAAQIA6AAIAAAmg");
	this.shape_21.setTransform(39.2,-196.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAUBIIgrhQIABAaIAAA2IguAAIAAiQIAzAAIApBQIgBgZIAAg3IAuAAIAACQg");
	this.shape_22.setTransform(20.875,-196.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("Ag0BIIAAiQIBmAAIAAAmIg3AAIAAAPIA0AAIAAAlIg0AAIAAAQIA6AAIAAAmg");
	this.shape_23.setTransform(7.05,-196.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(-1.2,-207.9,340,25), null);


(lib.skate1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset2pngcopy();
	this.instance.setTransform(163,-299,0.4516,0.4516);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate1, new cjs.Rectangle(163,-299,230.3,83.1), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A5LG4QhLgkg7g+IAAiNQBEBIBEAmQBeA0ByAAQBhAABBhGQA7hCAAhVQAAhVg9hBQhBhGheAAQgeAAgTgUQgTgTAAgdQAAgdAWgTQAVgTAZAAIAHAAQBKAABDAcQBBAcAyA1QAtAxAaA/QAZA/AABDQAACShnBmQhoBoiRAAQh3gBhjgxgAKNEvQgZgYAAgmQAAghAagXQAZgWAiAAQAiAAAZAWQAaAXAAAhQAAAmgZAYQgYAXgkAAQglAAgXgXgAKrDVQgOANAAAPQAAAVAOANQALANATgBQASABANgNQAMgNAAgVQAAgPgMgNQgNgLgSAAQgSAAgMALgAFdFBQgNgDgHgHIAAgoIACACQAHAIAMAGQAOAGALAAQAJAAAFgEQAGgDAAgGQgBgGgFgEQgGgDgOgGQgogPAAgiQAAgWAPgNQAOgOAZAAQAMAAAMADQAMAEAGAFIABAAIAAAnIgCgBQgFgHgLgFQgLgFgJAAQgJAAgEADQgFAEAAAFQABAGAEAFQAEADAOAGQAUAGALANQANAMAAARQgBAWgPAOQgPAOgcAAQgQAAgNgFgABcE0QgLgKgDgPQgDgLAAgSIAAhXIApAAIAABSQAAATADAJQAHAOARAAQASAAAFgOQAEgJAAgTIAAhSIAoAAIAABXQAAASgDALQgCAPgLAKQgRARgiAAQgiAAgRgRgAP2FBIAAh4IghAAIAAgiIBqAAIAAAiIghAAIAAB4gAOPFBIgmg7IAAA7IgoAAIAAiaIA+AAQANAAAKAEQAIAEAIAGQAGAHADAIQACAJAAAKQABASgJAKQgIAMgRADIAxA/gANpDsIAHAAQAMAAAHgFQAFgEABgKQgBgJgFgFQgIgFgLAAIgHAAgAHcFBIAAiaIBAAAQAaAAANAOQAOANAAAZQAAAYgOAOQgNANgaAAIgYAAIAAAzgAIEDuIANAAQAWAAAAgTQAAgUgWAAIgNAAgAhdFBIAAiaIA5AAQAgAAAVAWQAYAXAAAgQAAAggYAXQgVAXgggBgAg2EfIAKAAQATAAALgKQAOgLAAgWQAAgUgMgLQgMgMgUAAIgKAAgA2LDWQhKAAhCgcQhCgcgxg1Qgugxgag/QgZg/AAhDQAAiRBohoQBnhmCRAAQCvABB/BkIAACLQhDg6hIgcQhHgchUAAQhhAAhBBHQg6BBAABVQgBBUA9BBQBBBHBeAAQAdAAAUAUQATATAAAdQAAAcgWAUQgVATgZAAgASIDAQgFgEAAgGQAAgGAFgEQADgEAGAAQADAAAEABIAAAIQgCgCgEAAQgIgBAAAIQAAADACACQADACADAAQACAAAEgDIAAAJIgBAAIgGABQgGAAgDgEgAR5DDIgCgPIgHAPIgDAAIgGgPIgCAPIgHAAIAFgbIAHAAIAFAPIAGgPIAHAAIAEAbgAVpgLQgegLgYgXQgzgtAAhIQAAggANgdQALgdAWgXQAXgYAfgNQAggOAhAAQAiAAAnAQIAABhQgMgRgTgIQgTgJgVAAQglAAgXAYQgWAZAAAlQAAAkAWAYQAYAYAlAAQAUAAASgJQATgIANgQIAABhIgkAKQgSADgRAAQghAAgdgLgAElgvQgwgvAAhKQAAhEAzgtQAygsBEgBQBEABAxAsQA0AtAABEQAABKgwAvQgvAvhKAAQhKAAgvgvgAFhjgQgaAZAAAfQAAAnAaAbQAZAaAkAAQAkAAAZgaQAZgbAAgnQAAgfgZgZQgagYgjAAQgjAAgaAYgAAIgJQgZgIgNgMIAAgBIAAhPIADADQANARAZAMQAbALAVABQATAAALgIQAKgHAAgMQAAgLgLgIQgKgHgegLIAAAAQhOgeAAhEQAAgqAegcQAcgbAvgBQAbAAAXAIIAAAAQAWAIAOAJIAAABIAABOIgCgDQgMgOgWgKQgVgLgSAAQgSABgJAGQgJAIABALQAAAMAJAHQAKAIAbAKQAnAOAXAYQAXAZAAAhQAAAsgeAcQgfAcg4AAQggAAgZgJgALVgJQgdgJgSgSQgVgUgHgeQgEgUAAgmIAAisIBQAAIAAChQgBAoAIARQAMAbAjgBQAhABANgbQAHgRABgoIAAihIBPAAIAACsQAAAmgFAUQgHAegUAUQgTASgcAJQgZAHgdAAQgeAAgZgHgAY+gKIAAkyICuAAIAABEIhfAAIAAAzIBZAAIAABEIhZAAIAAA0IBfAAIAABDgAR8gKIhLh1IgBAAIAAB1IhQAAIAAkyIB4AAQAvAAAcAXQAfAYgBAwQABAggSAYQgRAYggAGIBgB9gAQwizIAIAAQAYABANgHQASgKAAgWQAAgXgSgIQgNgHgYAAIgIAAgAkwgKIgUg1IhtAAIgWA1IhUAAIB1kyIBYAAIBzEygAmch8IBDAAIghhhIgBAAgAsKgKIAAkyIBPAAIAADvIBgAAIAABDg");
	this.shape.setTransform(17.8,-381.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(-159.3,-430.3,354.3,97.90000000000003), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgQAQQgGgGAAgKQAAgJAGgFQAHgGAJABQALgBAFAGQAHAFAAAJQAAAKgHAGQgFAEgLAAQgJAAgHgEg");
	this.shape.setTransform(361.45,-313.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgsAzQgOgOAAgdIAAhJIArAAIAABMQAAAJAEAEQAFAFAGAAQAIAAAEgFQAEgEAAgJIAAhMIArAAIAABJQAAAdgOAOQgPAPgeAAQgdAAgPgPg");
	this.shape_1.setTransform(351.675,-317.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBbAAIAAAiIgwAAIAAANIAtAAIAAAhIgtAAIAAAPIAyAAIAAAig");
	this.shape_2.setTransform(339.65,-317.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AASBBIgnhHIABAWIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_3.setTransform(316.975,-317.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgxAxQgVgSABgfQgBgeAVgTQATgRAeAAQAfAAATARQAVATgBAeQABAfgVASQgTASgfAAQgeAAgTgSgAgUgWQgHAIAAAOQAAAMAHAJQAJAIALAAQANAAAHgIQAIgIAAgNQAAgOgIgIQgHgIgNAAQgLAAgJAIg");
	this.shape_4.setTransform(302.4,-317.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgVBBIAAhgIgeAAIAAghIBnAAIAAAhIgfAAIAABgg");
	this.shape_5.setTransform(290.6,-317.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBcAAIAAAiIgyAAIAAANIAuAAIAAAhIguAAIAAAPIAzAAIAAAig");
	this.shape_6.setTransform(276.5,-317.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag0AxIATgfQAIAGAMAEQAJADAFAAQAJABAAgGQAAgDgJgEIgSgGQgMgFgGgFQgMgIAAgSQAAgTAPgMQAOgMAYAAQAbAAATAQIgQAeQgHgGgKgDQgIgEgGAAQgKAAAAAGQAAADAIADIAQAEQAOAFAIAGQAMAKAAARQAAAWgRAMQgPAMgXAAQgaAAgYgSg");
	this.shape_7.setTransform(265.425,-317.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUBBIAAiBIApAAIAACBg");
	this.shape_8.setTransform(257.125,-317.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgqBBIAAiBIAqAAIAABeIArAAIAAAjg");
	this.shape_9.setTransform(249.575,-317.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAXBBIgFgSIgkAAIgFASIgtAAIAuiBIAuAAIAtCBgAAJAOIgJgiIgJAiIASAAg");
	this.shape_10.setTransform(237.575,-317.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AASBBIgnhHIABAWIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_11.setTransform(223.775,-317.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AASBBIgnhHIABAWIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_12.setTransform(209.475,-317.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgyAxQgTgSgBgfQABgeATgTQAUgRAeAAQAfAAAUARQATATABAeQgBAfgTASQgUASgfAAQgeAAgUgSgAgTgWQgIAIAAAOQAAAMAIAJQAHAIAMAAQAMAAAIgIQAHgIAAgNQAAgOgHgIQgIgIgMAAQgMAAgHAIg");
	this.shape_13.setTransform(194.9,-317.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag0AxIATgfQAIAGAMAEQAJADAFAAQAJABAAgGQAAgDgJgEIgSgGQgMgFgGgFQgMgIAAgSQAAgTAPgMQAOgMAYAAQAbAAATAQIgQAeQgHgGgKgDQgIgEgGAAQgKAAAAAGQAAADAIADIAQAEQAOAFAIAGQAMAKAAARQAAAWgRAMQgPAMgXAAQgaAAgYgSg");
	this.shape_14.setTransform(182.025,-317.75);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAKBBIgUgrIgFAAIAAArIgrAAIAAiBIA5AAQAXAAANAJQAQALAAAWQAAAZgVAMIAdAygAgPgKIAKAAQAGAAADgCQAFgDAAgGQAAgFgFgEQgDgCgGAAIgKAAg");
	this.shape_15.setTransform(171.175,-317.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AguBBIAAiBIBcAAIAAAiIgyAAIAAANIAuAAIAAAhIguAAIAAAPIAzAAIAAAig");
	this.shape_16.setTransform(159.05,-317.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag1BBIAAiBIA4AAQAXAAANAKQAPAMAAAXQAAAWgPALQgNAKgXAAIgNAAIAAApgAgKgGIAHAAQAGAAADgDQAFgDAAgHQAAgIgFgDQgDgCgGAAIgHAAg");
	this.shape_17.setTransform(147.975,-317.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AASBBIgnhHIABAWIAAAxIgpAAIAAiBIAuAAIAlBHIgBgWIAAgxIApAAIAACBg");
	this.shape_18.setTransform(130.875,-317.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgyAxQgTgSAAgfQAAgeATgTQAUgRAeAAQAfAAATARQAVATAAAeQAAAfgVASQgTASgfAAQgeAAgUgSgAgUgWQgHAIAAAOQAAAMAHAJQAIAIAMAAQANAAAHgIQAIgIAAgNQAAgOgIgIQgHgIgNAAQgMAAgIAIg");
	this.shape_19.setTransform(116.3,-317.775);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AiuBCIgKgDIACgfQAGADAFAAQADAAACgCQACgBAAgFIAAhcIAqAAIAABcQAAAVgJAJQgIAKgTAAIgQgBgACsgvQgDgDAAgFQAAgEADgEQADgDAFAAIAFABIAAAGQgCgCgDAAQgFAAAAAGQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQABABAAAAQABAAAAABQABAAAAAAQABAAAAAAQADAAACgDIAAAIIAAAAIgFAAQgFAAgDgDgAChgsIgCgMIgGAMIgCAAIgEgMIgCAMIgGAAIAEgVIAFAAIAFALIAEgLIAGAAIADAVg");
	this.shape_20.setTransform(346.125,-317.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(106.7,-328.6,260.5,23.30000000000001), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAOQgGgEAAgKQAAgIAGgFQAGgGAJAAQAKAAAGAGQAGAFAAAIQAAAKgGAEQgGAFgKABQgJgBgGgFg");
	this.shape.setTransform(213.15,-171.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag9A6IAXgmQAJAJANAEQALAEAGAAQALAAAAgHQAAgEgLgEIgVgGQgPgGgFgGQgOgKgBgVQAAgWASgOQAQgOAcAAQAgAAAWASIgTAjQgIgGgLgFQgKgDgHAAQgLAAAAAGQgBAEAKADIASAGQARAGAJAGQAOAMgBAVQABAYgUAPQgRANgbAAQggAAgbgUg");
	this.shape_1.setTransform(203.65,-177.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag0BMIAAiXIBpAAIAAAnIg3AAIAAAYIA0AAIAAAmIg0AAIAAAyg");
	this.shape_2.setTransform(191.775,-177.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgYBMIAAiXIAxAAIAACXg");
	this.shape_3.setTransform(181.825,-177.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag8A6IAVgmQAKAJAOAEQAKAEAGAAQALAAAAgHQAAgEgLgEIgVgGQgPgGgFgGQgPgKAAgVQAAgWASgOQAQgOAbAAQAhAAAWASIgTAjQgIgGgMgFQgJgDgHAAQgLAAAAAGQAAAEAJADIASAGQARAGAJAGQANAMAAAVQAAAYgTAPQgRANgbAAQggAAgagUg");
	this.shape_4.setTransform(171.9,-177.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag6A6QgYgVABglQgBgjAYgWQAXgVAjABQAkgBAXAVQAYAWgBAjQABAlgYAVQgXAVgkgBQgjABgXgVgAgXgaQgJALAAAPQAAAPAJAKQAJAJAOAAQAPAAAJgJQAIgKAAgPQAAgPgIgLQgJgJgPAAQgOAAgJAJg");
	this.shape_5.setTransform(157.1,-177.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgxBMIAAiXIAxAAIAABuIAyAAIAAApg");
	this.shape_6.setTransform(144,-177.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag+BMIAAiXIBBAAQAbAAAPAMQASAOAAAbQAAAZgSANQgPANgbAAIgPAAIAAAvgAgMgIIAIAAQAHAAAEgDQAGgDAAgIQAAgJgGgEQgEgDgHAAIgIAAg");
	this.shape_7.setTransform(131.475,-177.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAYBMIgYgxIgXAxIg8AAIAzhOIgwhJIA7AAIAVApIAVgpIA8AAIgwBJIAzBOg");
	this.shape_8.setTransform(116.225,-177.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAnIg5AAIAAARIA1AAIAAAmIg1AAIAAARIA7AAIAAAog");
	this.shape_9.setTransform(102.15,-177.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag8A6IAWgmQAJAJAOAEQAKAEAGAAQALAAAAgHQAAgEgLgEIgVgGQgPgGgFgGQgOgKgBgVQAAgWASgOQAQgOAbAAQAhAAAWASIgTAjQgIgGgLgFQgKgDgHAAQgLAAAAAGQAAAEAJADIASAGQARAGAJAGQAOAMgBAVQAAAYgTAPQgRANgbAAQggAAgagUg");
	this.shape_10.setTransform(84.95,-177.35);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAnIg6AAIAAARIA2AAIAAAmIg2AAIAAARIA8AAIAAAog");
	this.shape_11.setTransform(72.65,-177.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgxA7QgZgVAAgmQAAglAZgVQAWgTAhAAQAbAAATALQAHAFALAKIghAcQgNgOgSAAQgNAAgIAKQgJAKAAARQAAARAJALQAIAJANAAQASAAADgFIAAgLIgXAAIAAgkIBHAAIAABBQgOANgKAFQgTAKgbAAQggAAgWgTg");
	this.shape_12.setTransform(57.775,-177.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAaBMIgGgWIgqAAIgGAWIgzAAIA0iXIA2AAIA1CXgAAKAQIgKgnIgMAnIAWAAg");
	this.shape_13.setTransform(42.475,-177.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAMBMIgYgzIgGAAIAAAzIgyAAIAAiXIBCAAQAcAAAPALQATAOAAAXQAAAegZAPIAiA6gAgSgLIAMAAQAHAAADgCQAGgFAAgGQAAgGgGgFQgDgDgHAAIgMAAg");
	this.shape_14.setTransform(28.125,-177.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgYBMIAAiXIAxAAIAACXg");
	this.shape_15.setTransform(16.575,-177.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgXBMIg5iXIA0AAIAcBXIAdhXIA0AAIg5CXg");
	this.shape_16.setTransform(5.125,-177.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(-4.8,-189.4,223.3,26), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag9A6IAXgmQAJAJANAEQALAEAGAAQALAAAAgHQAAgEgLgDIgVgHQgPgGgFgFQgOgLgBgVQAAgWASgOQAQgOAcAAQAgAAAWASIgTAjQgIgHgLgEQgKgDgHAAQgLAAAAAGQgBAEAKADIASAGQARAGAJAGQAOAMgBAVQABAYgUAPQgRANgbAAQggAAgbgUg");
	this.shape.setTransform(178.9,-198.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag2BMIAAiXIBrAAIAAAnIg5AAIAAARIA1AAIAAAmIg1AAIAAASIA7AAIAAAng");
	this.shape_1.setTransform(166.6,-198.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhHBMIAAiXIA6AAQAlAAAWARQAZATAAAnQAAAogZATQgWARglAAgAgVAiIALAAQAPAAAIgIQAIgIABgSQgBgSgIgJQgIgHgPAAIgLAAg");
	this.shape_2.setTransform(152.45,-198.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAMBMIgYgzIgGAAIAAAzIgyAAIAAiXIBCAAQAcAAAPALQATAOAAAXQAAAegZAQIAiA5gAgSgLIAMAAQAHAAADgCQAGgEAAgHQAAgGgGgEQgDgEgHAAIgMAAg");
	this.shape_3.setTransform(133.425,-198.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag0A7QgQgQAAghIAAhWIAyAAIAABYQAAAMAFAFQAFAFAIAAQAJAAAFgFQAFgFAAgMIAAhYIAyAAIAABWQAAAhgQAQQgSASgjAAQgiAAgSgSg");
	this.shape_4.setTransform(117.575,-198.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag6A6QgXgWAAgjQAAgkAXgWQAXgUAjAAQAkAAAXAUQAYAWAAAkQAAAjgYAWQgXAVgkgBQgjABgXgVgAgXgZQgJAJAAAQQAAAPAJAKQAJAJAOAAQAPAAAIgJQAJgKAAgPQAAgQgJgJQgIgKgPAAQgOAAgJAKg");
	this.shape_5.setTransform(101,-198.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag+BMIAAiXIBBAAQAbAAAPAMQASAOAAAbQAAAZgSANQgPANgbAAIgPAAIAAAvgAgMgHIAIAAQAHgBAEgDQAGgDAAgIQAAgJgGgDQgEgEgHAAIgIAAg");
	this.shape_6.setTransform(85.925,-198.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag0A7QgQgQAAghIAAhWIAyAAIAABYQAAAMAFAFQAFAFAIAAQAJAAAFgFQAFgFAAgMIAAhYIAyAAIAABWQAAAhgQAQQgSASgjAAQgiAAgSgSg");
	this.shape_7.setTransform(66.425,-198.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgaBdIARghQgWgFgPgQQgVgUAAghQAAglAYgVQAXgVAiAAQAiAAARAPIgOAqQgPgNgTgBQgPAAgIAJQgKAJAAARQgBAQALAJQAJAJAOAAQAXgBANgOIAPAoQgQAPgWADIgOAfg");
	this.shape_8.setTransform(51.75,-196.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAVBMIgthTIABAaIAAA5IgwAAIAAiXIA2AAIArBUIgCgbIAAg5IAxAAIAACXg");
	this.shape_9.setTransform(36.2,-198.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag6A6QgXgWAAgjQAAgkAXgWQAWgUAkAAQAkAAAXAUQAYAWgBAkQABAjgYAWQgXAVgkgBQgkABgWgVgAgXgZQgJAJAAAQQAAAPAJAKQAJAJAOAAQAPAAAIgJQAJgKAAgPQAAgQgJgJQgIgKgPAAQgOAAgJAKg");
	this.shape_10.setTransform(19.2,-198.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgrA6QgXgVAAglQAAgkAXgVQAWgUAjAAQAiAAAQAOIgNAqQgPgNgTAAQgPAAgJAIQgJAKgBAQQAAAQALAJQAIAJAPAAQAWAAAOgOIAPAnQgUATgiAAQgjAAgWgUg");
	this.shape_11.setTransform(4.2,-198.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(-5,-210.4,196.7,26), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgPAwIAAhGIgWAAIAAgZIBLAAIAAAZIgWAAIAABGg");
	this.shape.setTransform(521.275,-221.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AANAwIgcg1IABARIAAAkIgfAAIAAhfIAiAAIAbA0IgBgQIAAgkIAfAAIAABfg");
	this.shape_1.setTransform(512.225,-221.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AARAwIgEgOIgaAAIgEAOIghAAIAihfIAhAAIAiBfgAAGAKIgGgYIgHAYIANAAg");
	this.shape_2.setTransform(502.025,-221.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AANAwIgcg1IABARIAAAkIgfAAIAAhfIAiAAIAbA0IgBgQIAAgkIAfAAIAABfg");
	this.shape_3.setTransform(491.875,-221.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AghAwIAAhfIBCAAIAAAZIgkAAIAAAKIAiAAIAAAYIgiAAIAAALIAlAAIAAAZg");
	this.shape_4.setTransform(482.75,-221.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AgPAwIAAhGIgWAAIAAgZIBLAAIAAAZIgWAAIAABGg");
	this.shape_5.setTransform(474.825,-221.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AANAwIgcg1IABARIAAAkIgfAAIAAhfIAiAAIAbA0IgBgQIAAgkIAfAAIAABfg");
	this.shape_6.setTransform(465.775,-221.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgPAwIAAhfIAfAAIAABfg");
	this.shape_7.setTransform(458.25,-221.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AARAwIgEgOIgaAAIgEAOIghAAIAihfIAhAAIAiBfgAAGAKIgGgYIgHAYIANAAg");
	this.shape_8.setTransform(451.125,-221.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#231F20").s().p("AAbAwIgBg2IgMA2IgaAAIgNg2IgBA2IgfAAIAGhfIAoAAIALAzIAMgzIAoAAIAGBfg");
	this.shape_9.setTransform(440,-221.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#231F20").s().p("AAHAwIgOggIgEAAIAAAgIgfAAIAAhfIApAAQARAAAKAHQAMAIAAAQQAAASgQAJIAVAlgAgLgHIAIAAQAEAAACgBQADgDAAgEQAAgEgDgCQgDgCgDAAIgIAAg");
	this.shape_10.setTransform(426.975,-221.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#231F20").s().p("AgiAwIAAhfIBEAAIAAAZIgkAAIAAAKIAhAAIAAAYIghAAIAAALIAlAAIAAAZg");
	this.shape_11.setTransform(418.1,-221.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#231F20").s().p("AgPAwIAAhGIgWAAIAAgZIBLAAIAAAZIgWAAIAABGg");
	this.shape_12.setTransform(410.175,-221.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#231F20").s().p("AghAwIAAhfIBCAAIAAAZIgkAAIAAAKIAiAAIAAAYIgiAAIAAALIAmAAIAAAZg");
	this.shape_13.setTransform(402.5,-221.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#231F20").s().p("AANAwIAAgkIgZAAIAAAkIgfAAIAAhfIAfAAIAAAjIAZAAIAAgjIAfAAIAABfg");
	this.shape_14.setTransform(393.225,-221.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#231F20").s().p("AgbAlQgPgOAAgXQAAgWAPgOQAPgMAVAAQAVAAALAJIgJAaQgKgIgMAAQgJAAgFAFQgGAGAAAKQgBAKAIAGQAFAFAIAAQAOAAAKgJIAJAZQgMAMgWAAQgVAAgPgMg");
	this.shape_15.setTransform(383.9,-221.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#231F20").s().p("AARAwIgEgOIgaAAIgEAOIghAAIAihfIAhAAIAiBfgAAGAKIgGgYIgHAYIANAAg");
	this.shape_16.setTransform(374.725,-221.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("As+CMQgQgBgMgLQgMgMAAgRIAAjGQAAgQAMgMQAMgMAQABIZ8AAQARgBAMAMQAMAMAAAQIAADGQAAARgMAMQgMALgRABg");
	this.shape_17.setTransform(447.125,-221.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(360.1,-235.4,174.10000000000002,27.900000000000006), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-97.8,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.9,-288.5,393,26.69999999999999);


// stage content:
(lib.shift_728x90_fr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(184.8,315,1.12,1.12,0,0,0,62,18.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(290).to({_off:false},0).to({alpha:1},28,cjs.Ease.quartInOut).wait(25));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(176.9,413.9,1.12,1.12,0,0,0,84.2,10.6);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(273).to({_off:false},0).to({alpha:1},27,cjs.Ease.quartInOut).wait(43));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(166.05,299.5,0.448,0.448,0,0,0,177.6,184.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(256).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(58));

	// skate1
	this.instance_3 = new lib.skate1();
	this.instance_3.setTransform(613.05,401.85,1.12,1.12,0,0,0,56.1,61.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(23).to({_off:false},0).to({x:350.55},25,cjs.Ease.quartOut).wait(195).to({x:611.55},18,cjs.Ease.quintInOut).wait(82));

	// Ctet2
	this.instance_4 = new lib.Ctext2();
	this.instance_4.setTransform(-167.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(154).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_5 = new lib.Ctext1();
	this.instance_5.setTransform(-132.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(151).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// text2
	this.instance_6 = new lib.Tween2("synched",0);
	this.instance_6.setTransform(-158.95,366.45,1.12,1.12);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(9).to({_off:false},0).to({x:123.25},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_7 = new lib.text1();
	this.instance_7.setTransform(-206.95,282.9,1.12,1.12,0,0,0,74.8,24);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(5).to({_off:false},0).to({x:106.15,y:280.9},21,cjs.Ease.quartOut).wait(96).to({y:282.9,alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// bg
	this.instance_8 = new lib.Asset1();
	this.instance_8.setTransform(728,0,0.6198,0.6558,90);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(71.9,43.1,918.8000000000001,302.79999999999995);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/shift_728x90_fr_atlas_1.jpg", id:"shift_728x90_fr_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;