(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"fam_336x280_us_atlas_P_1", frames: [[116,0,112,123],[0,0,114,124],[0,126,114,123]]},
		{name:"fam_336x280_us_atlas_NP_1", frames: [[0,0,558,1110]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset1 = function() {
	this.initialize(ss["fam_336x280_us_atlas_NP_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset2pngcopy = function() {
	this.initialize(ss["fam_336x280_us_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset3 = function() {
	this.initialize(ss["fam_336x280_us_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Asset4 = function() {
	this.initialize(ss["fam_336x280_us_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYAWQgJgIAAgOQAAgNAJgIQAJgIAPAAQAQAAAJAIQAJAIAAANQAAAOgJAIQgJAIgQAAQgPAAgJgIg");
	this.shape.setTransform(18.975,-157.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhOBJIAdgvQAMAKAPAFQAPAGAIAAQAPAAAAgIQgCgHgNgEIgbgIQgSgIgJgHQgRgOAAgaQAAgcAXgTQATgQAkAAQAqAAAbAXIgYAtQgKgJgOgFQgNgFgJAAQgPAAAAAIQAAAGANADIAKADIANAEQAVAHALAJQATAPAAAaQgBAfgZAUQgVAQgjAAQgoAAgjgag");
	this.shape_1.setTransform(6,-164.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhFBhIAAjBICIAAIAAAyIhJAAIAAAVIBFAAIAAAxIhFAAIAAAWIBMAAIAAAzg");
	this.shape_2.setTransform(-9.65,-164.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeBhIAAiPIguAAIAAgyICZAAIAAAyIgtAAIAACPg");
	this.shape_3.setTransform(-25.75,-164.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAiBhIgIgbIg2AAIgHAbIhCAAIBDjBIBFAAIBDDBgAAMAVIgMgzIgPAzIAbAAg");
	this.shape_4.setTransform(-43.35,-164.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAPBhIgfhBIgLAOIAAAzIg/AAIAAjBIA/AAIAAA7IAng7IBLAAIg/BOIBDBzg");
	this.shape_5.setTransform(-61.55,-164.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhOBJIAcgvQANAKAPAFQAPAGAIAAQAPAAAAgIQgCgHgNgEIgbgIQgSgIgJgHQgRgOAAgaQAAgcAXgTQATgQAlAAQApAAAbAXIgYAtQgKgJgOgFQgNgFgJAAQgPAAAAAIQAAAGANADIAKADIANAEQAVAHALAJQASAPABAaQAAAfgaAUQgVAQgjAAQgnAAgkgag");
	this.shape_6.setTransform(-80.15,-164.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-178.9,116.1,32);


(lib.text3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhCBgIAAi/ICFAAIAAAxIhGAAIAAAeIBCAAIAAAxIhCAAIAAA/g");
	this.shape.setTransform(46.375,-189.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhLBJQgdgbAAguQAAgtAdgbQAegbAtAAQAvAAAcAbQAeAbAAAtQAAAugeAbQgdAbguAAQgtAAgegbgAgdggQgMALAAAUQAAAUAMANQAMAMARAAQATAAALgMQALgNAAgUQAAgUgLgLQgLgNgTAAQgSAAgLANg");
	this.shape_1.setTransform(27.2,-189.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgfBgIAAhLIhDh0IBGAAIAcBBIAdhBIBGAAIhEB0IAABLg");
	this.shape_2.setTransform(1.425,-189.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag/BgIAAi/IA/AAIAACLIBAAAIAAA0g");
	this.shape_3.setTransform(-12.075,-189.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgfBgIAAi/IA+AAIAAC/g");
	this.shape_4.setTransform(-24.45,-189.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AA3BgIgDhtIgZBtIg1AAIgahtIgCBtIg+AAIALi/IBSAAIAXBnIAZhnIBRAAIALC/g");
	this.shape_5.setTransform(-41.525,-189.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAiBgIgIgbIg2AAIgHAbIhCAAIBDi/IBFAAIBDC/gAAMAVIgMgzIgPAzIAbAAg");
	this.shape_6.setTransform(-63.95,-189.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhCBgIAAi/ICFAAIAAAxIhGAAIAAAeIBCAAIAAAxIhCAAIAAA/g");
	this.shape_7.setTransform(-79.875,-189.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-203.9,145.9,32);


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhFBgIAAi/ICIAAIAAAxIhJAAIAAAVIBFAAIAAAxIhFAAIAAAWIBMAAIAAAyg");
	this.shape.setTransform(104.8,-142.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag3BJQgegaAAgvQAAguAegaQAdgbArAAQAaAAAQAHQANAEAIAFIACADIgRA1IgGgFQgCgCgNgFQgMgFgKAAQgUAAgLALQgMAMAAAVQAAATAMAMQAMAMATAAQAdAAARgSIASAyQgYAZgtAAQgrAAgdgbg");
	this.shape_1.setTransform(87.8,-142.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAPBgIgehAIgJAAIAABAIg/AAIAAi/IBVAAQAiAAAUANQAYARAAAfQAAAmggATIAsBJgAgYgOIAQAAQAJAAAFgEQAGgFABgIQgBgJgGgFQgFgDgJAAIgQAAg");
	this.shape_2.setTransform(70.35,-142.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhCBLQgVgUAAgrIAAhtIA/AAIAABwQAAAPAHAGQAHAHAKAAQALAAAHgHQAGgGAAgPIAAhwIBAAAIAABtQAAArgVAUQgWAXgtAAQgrAAgXgXg");
	this.shape_3.setTransform(50.125,-142.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhLBKQgdgcAAguQAAgtAdgbQAegbAtAAQAvAAAcAbQAeAbAAAtQAAAugeAcQgdAaguAAQgtAAgegagAgdggQgMAMAAATQAAAUAMANQAMAMARAAQATAAALgMQALgNAAgUQAAgTgLgMQgLgNgTAAQgSAAgLANg");
	this.shape_4.setTransform(29,-142.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhOBJIAcgvQANAKAPAFQAPAGAIAAQAPAAAAgIQgCgHgNgEIgbgIQgSgIgJgHQgRgOAAgaQAAgcAXgTQATgQAlAAQApAAAbAXIgYAtQgKgJgOgFQgNgFgJAAQgPAAABAIQAAAGAMADIAKADIANAEQAVAHALAJQASAPABAaQAAAfgaAUQgVAQgjAAQgnAAgkgag");
	this.shape_5.setTransform(9.85,-142.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(0,-157.5,114.8,32), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhFBgIAAi/ICIAAIAAAxIhJAAIAAAVIBFAAIAAAxIhFAAIAAAWIBMAAIAAAyg");
	this.shape.setTransform(124.8,-190.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAbBgIAAhHIg0AAIAABHIg/AAIAAi/IA/AAIAABGIA0AAIAAhGIA/AAIAAC/g");
	this.shape_1.setTransform(106.05,-190.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeBgIAAiPIguAAIAAgwICZAAIAAAwIgtAAIAACPg");
	this.shape_2.setTransform(88,-190.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgfBgIAAiPIgtAAIAAgwICZAAIAAAwIguAAIAACPg");
	this.shape_3.setTransform(67.15,-190.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhFBgIAAi/ICIAAIAAAxIhJAAIAAAVIBFAAIAAAxIhFAAIAAAWIBMAAIAAAyg");
	this.shape_4.setTransform(51.65,-190.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhFBgIAAi/ICIAAIAAAxIhJAAIAAAVIBFAAIAAAxIhFAAIAAAWIBMAAIAAAyg");
	this.shape_5.setTransform(35.45,-190.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AA3BgIgDhtIgZBtIg1AAIgahtIgCBtIg+AAIALi/IBSAAIAXBoIAZhoIBRAAIALC/g");
	this.shape_6.setTransform(14.525,-190.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(0,-205,134.8,32), null);


(lib.skate3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset4();
	this.instance.setTransform(186,-276,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate3, new cjs.Rectangle(186,-276,62.69999999999999,67.69999999999999), null);


(lib.skate2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset3();
	this.instance.setTransform(62,-294,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate2, new cjs.Rectangle(62,-294,62.7,68.19999999999999), null);


(lib.skate1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset2pngcopy();
	this.instance.setTransform(187,-290,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate1, new cjs.Rectangle(187,-290,61.599999999999994,67.69999999999999), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgFAVIAAgfIgJAAIAAgLIAdAAIAAALIgJAAIAAAfg");
	this.shape.setTransform(274.1,-154.4564,0.6702,0.6702);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPAVIgDgVIgKAVIgDAAIgKgVIgDAVIgMAAIAHgqIAMAAIAHAWIAIgWIAMAAIAHAqg");
	this.shape_1.setTransform(277.0488,-154.4564,0.6702,0.6702);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgnCYIAAiSIhuidIBeAAIA3BTIA4hTIBeAAIhvCdIAACSg");
	this.shape_2.setTransform(260.3612,-145.7273,0.6702,0.6702);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhVCYIAAkvICrAAIAABDIhcAAIAAAzIBXAAIAABCIhXAAIAAA0IBcAAIAABDg");
	this.shape_3.setTransform(243.2214,-145.7273,0.6702,0.6702);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAoCYIhmiEIAACEIhPAAIAAkvIBPAAIAAB9IBfh9IBiAAIh5CQICECfg");
	this.shape_4.setTransform(225.5956,-145.7273,0.6702,0.6702);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhDBzQgwgvAAhEQAAhEAwguQAvgtBAAAQAiAAAmAQIAABeQgcghgogBQgjAAgXAZQgXAXAAAjQAAAkAYAYQAWAYAjAAQAmAAAeghIAABeIgIADQgkAMgdAAQg/AAgvgtg");
	this.shape_5.setTransform(204.9875,-145.7441,0.6702,0.6702);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ah4ByQgvgtAAhFQAAhDAvgtQAwgvBIAAQBJAAAwAvQAvAtAABDQAABFgvAtQgwAuhJAAQhIAAgwgugAg7g6QgaAXAAAjQAAAkAaAYQAYAYAjAAQAjAAAZgYQAZgYAAgkQAAgjgZgXQgZgZgjAAQgjAAgYAZg");
	this.shape_6.setTransform(183.5417,-145.7441,0.6702,0.6702);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AA5CYIAAh9IhxAAIAAB9IhPAAIAAkvIBPAAIAAB1IBxAAIAAh1IBPAAIAAEvg");
	this.shape_7.setTransform(159.8508,-145.7273,0.6702,0.6702);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAcCYIhKh1IAAB1IhPAAIAAkvIB7AAQAvAAAbAcQAZAaAAAoQAABFhDAPIBgB9gAgugPIAOAAQAYAAALgKQANgKAAgRQAAgSgNgKQgLgKgYAAIgOAAg");
	this.shape_8.setTransform(130.9492,-145.7273,0.6702,0.6702);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ah4ByQgvgtAAhFQAAhDAvgtQAwgvBIAAQBJAAAwAvQAvAtAABDQAABFgvAtQgwAuhJAAQhJAAgvgugAg7g6QgZAXgBAjQABAkAZAYQAYAYAjAAQAjAAAZgYQAagYgBgkQABgjgagXQgZgZgjAAQgjAAgYAZg");
	this.shape_9.setTransform(107.895,-145.7441,0.6702,0.6702);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhWCYIAAkvICtAAIAABDIheAAIAAAzIBVAAIAABCIhVAAIAAB3g");
	this.shape_10.setTransform(88.5938,-145.7273,0.6702,0.6702);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AirEtIAApZIFWAAIAACEIi5AAIAABlICvAAIAACDIivAAIAABpIC5AAIAACEg");
	this.shape_11.setTransform(284.2867,-199.4926,0.6702,0.6702);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgcEpQg7gWgvgsQhihYAAiPQAAg9AXg6QAXg5ArgtQAtgvA+gaQA8gaBBAAQBHAABJAeIAAC+QgXgfgmgSQgkgSgqABQhHgBgtAxQgtAxAABGQAABJAtAvQAtAuBKABQAmAAAlgSQAkgSAZgdIAAC+QgxAPgWAFQgjAIgiAAQg/AAg6gYg");
	this.shape_12.setTransform(246.6728,-199.4256,0.6702,0.6702);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AA4EtIiTjnIgCAAIAADnIicAAIAApZIDqAAQBdAAA3AtQA8AvAABdQAABBgiAuQgkAvg+ALIC9D3gAhdgeIAPAAQAwAAAagNQAigSAAgtQAAgrgigTQgagNgwABIgPAAg");
	this.shape_13.setTransform(209.8128,-199.4926,0.6702,0.6702);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhqEmQg6gRgjgjQgogngOg8QgJgnAAhLIAAlRICdAAIAAE8QAABNAPAiQAYA1BCgBQBDABAYg1QAPgjAAhMIAAk8ICdAAIAAFRQAABKgJAoQgOA8gpAnQgjAjg5ARQgxAPg6AAQg5AAgxgPg");
	this.shape_14.setTransform(164.9442,-198.9565,0.6702,0.6702);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AjtDjQhfhdAAiRQABiEBlhaQBhhWCFgBQCFABBiBWQBlBaAACEQAACRhdBdQheBdiRAAQiQAAhdhdgAh3h4QgyAvAABAQAABMAyAzQAxAzBGAAQBHAAAxgzQAyg0AAhLQAAhAgygvQgzgwhFAAQhFAAgyAwg");
	this.shape_15.setTransform(116.7414,-199.4591,0.6702,0.6702);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AiEEwQgzgRgagYIAAiUQAcAhA2AYQAzAXArAAQAoAAAWgOQAVgPAAgZQAAgZgXgRQgXgPg4gVQicg5AAiIQAAhSA5g2QA5g2BfAAQA1AAAsAOQAtAQAaASIAACTQgYgcgsgUQgrgWgmABQgjAAgSAOQgTAPAAAZQAAAYAUAQQATAQA1AUQBOAcAuAuQAuAwAABDQAABXg9A2Qg8A3hrAAQhBAAgxgRg");
	this.shape_16.setTransform(72.0738,-199.4256,0.6702,0.6702);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAyK0QiSAAiCg3QiCg3hghoQhbhhgxh9Qgyh9AAiDQAAkdDLjLQDLjLEdAAQFYADD6DGIAAEQQiEhziNg2QiNg3ijAAQi/AAh/CLQh0CAAACoQAAClB3CCQB/CLC5AAQA5AAAnAmQAmAmAAA6QAAA3grAoQgpAkgyAAg");
	this.shape_17.setTransform(171.847,-335.6232,0.6702,0.6702);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AmrJUQiUhIh0h5IAAkXQCECOCHBKQC5BnDgAAQC/AAB+iLQB1iAAAioQAAilh3iCQiAiLi4AAQg7AAglgmQgmgmAAg6QAAg4AqgnQAogkA0AAIAMAAQCSgBCCA4QCCA4BhBoQBaBhAyB8QAxB9AACCQAAEejLDLQhgBgh8A1QiAA3iNAAQjogCjDhfg");
	this.shape_18.setTransform(178.5824,-299.2826,0.6702,0.6702);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(58,-382,237.8,247), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfAVIgDgWIgKAWIgFAAIgJgWIgDAWIgLAAIAHgpIALAAIAIAUIAJgUIALAAIAHApgAghAVIAAgfIgJAAIAAgKIAeAAIAAAKIgJAAIAAAfg");
	this.shape.setTransform(140.0505,-201.1704,0.4158,0.4158);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgKAKQgEgEAAgGQAAgFAEgDQAEgEAGAAQAHAAAEAEQAEADAAAFQAAAGgEAEQgEADgHAAQgGAAgEgDg");
	this.shape_1.setTransform(139.425,-195);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAVIgfAAIAAAJIAdAAIAAAUIgdAAIAAAJIAgAAIAAAWg");
	this.shape_2.setTransform(134.075,-197.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAXApIgBguIgKAuIgXAAIgKguIgBAuIgbAAIAFhRIAjAAIAJArIAKgrIAjAAIAFBRg");
	this.shape_3.setTransform(125.175,-197.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOApIgDgMIgWAAIgDAMIgcAAIAchRIAdAAIAcBRgAAFAJIgFgVIgGAVIALAAg");
	this.shape_4.setTransform(115.625,-197.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaAgQgOgMAAgUQAAgUAOgLQAMgLARAAQAOAAALAHQAEADAGAFIgSAPQgHgHgKAAQgGgBgFAGQgFAFAAAJQAAAJAFAGQAFAFAGAAQAIAAADgCIAAgBIAAgGIgMAAIAAgTIAnAAIAAAjIgFAEIgFAEIgHAEQgKADgLABQgRAAgMgLg");
	this.shape_5.setTransform(106.925,-197.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAGApIgMgbIgDAAIAAAbIgbAAIAAhRIAjAAQAPAAAIAGQAKAHAAANQAAAPgNAJIASAfgAgKgGIAHAAQADAAACgBQADgCAAgDQAAgFgDgBQgCgCgDAAIgHAAg");
	this.shape_6.setTransform(96.775,-197.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgbAgQgKgJABgSIAAguIAbAAIAAAvQgBAHADACQADADAEAAQAFAAADgDQACgCAAgHIAAgvIAbAAIAAAuQABASgKAJQgJAKgTAAQgSAAgJgKg");
	this.shape_7.setTransform(88.25,-197.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgfAfQgNgMAAgTQAAgTANgLQAMgMATAAQATAAANAMQAMALAAATQAAATgMAMQgNAMgTAAQgTAAgMgMgAgMgOQgEAGgBAIQABAIAEAGQAFAEAHAAQAIAAAEgEQAGgGAAgIQAAgIgGgGQgEgEgIAAQgHAAgFAEg");
	this.shape_8.setTransform(79.25,-197.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgMApIAAggIgdgxIAeAAIALAcIANgcIAdAAIgdAxIAAAgg");
	this.shape_9.setTransform(71.1,-197.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgMApIAAg8IgUAAIAAgVIBBAAIAAAVIgUAAIAAA8g");
	this.shape_10.setTransform(61.525,-197.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgNApIAAhRIAaAAIAABRg");
	this.shape_11.setTransform(56.35,-197.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbApIAAhRIA3AAIAAAVIgdAAIAAANIAcAAIAAAUIgcAAIAAAbg");
	this.shape_12.setTransform(51.35,-197.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAVIgfAAIAAAJIAdAAIAAAUIgdAAIAAAJIAgAAIAAAWg");
	this.shape_13.setTransform(42.225,-197.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AALApIgLguIgKAuIgcAAIgXhRIAdAAIAKAtIAKgtIAaAAIAKAtIAKgtIAbAAIgWBRg");
	this.shape_14.setTransform(32.65,-197.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(25.2,-204.8,117.89999999999999,14.700000000000017), null);


(lib.Ctext4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYAWQgJgIAAgOQAAgNAJgIQAJgIAPAAQAQAAAJAIQAJAIAAANQAAAOgJAIQgJAIgQAAQgPAAgJgIg");
	this.shape.setTransform(175.675,-107.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhFBgIAAi/ICIAAIAAAxIhJAAIAAAVIBFAAIAAAxIhFAAIAAAWIBMAAIAAAyg");
	this.shape_1.setTransform(163,-114.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag4BJQgdgaAAgvQAAguAdgaQAegbAsAAQAZAAAQAHQAMAEAJAFIACADIgQA1IgHgFQgCgCgNgFQgMgFgKAAQgUAAgKALQgNAMgBAVQABATANAMQALAMATAAQAcAAASgSIASAyQgYAZgsAAQgsAAgegbg");
	this.shape_2.setTransform(146,-114.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgfBgIAAi/IA+AAIAAC/g");
	this.shape_3.setTransform(132.3,-114.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOBgIgdhAIgIAAIAABAIhAAAIAAi/IBUAAQAjAAAVANQAXARAAAfQAAAmggATIArBJgAgXgOIAQAAQAJAAADgEQAIgFgBgIQABgJgIgFQgEgDgIAAIgQAAg");
	this.shape_4.setTransform(119.45,-114.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhPBgIAAi/IBTAAQAjAAATAPQAWARAAAiQAAAhgWARQgTAPgjAAIgUAAIAAA8gAgQgKIALAAQAJAAAFgDQAHgFAAgLQAAgLgHgFQgFgDgJAAIgLAAg");
	this.shape_5.setTransform(101.175,-114.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgeBgIAAiPIguAAIAAgwICZAAIAAAwIgtAAIAACPg");
	this.shape_6.setTransform(78.65,-114.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAbBgIAAhHIg0AAIAABHIg/AAIAAi/IA/AAIAABFIA0AAIAAhFIA/AAIAAC/g");
	this.shape_7.setTransform(60.6,-114.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhABMQgfgcAAgwQAAgwAggaQAcgZAqAAQAiAAAZAPQAKAGANANIgqAjQgRgRgXAAQgQAAgLANQgLANAAAVQAAAWALANQALANAQAAQAVAAAEgGIACgBIAAgPIgdAAIAAguIBbAAIAABUIgLAJIgMAJQgKAHgHACQgWAIgcAAQgpAAgdgXg");
	this.shape_8.setTransform(39.7,-114.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgeBgIAAi/IA+AAIAAC/g");
	this.shape_9.setTransform(25,-114.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAOBgIgdhAIgIAAIAABAIg/AAIAAi/IBTAAQAkAAATANQAYARAAAfQAAAmggATIArBJgAgXgOIAQAAQAIAAAEgEQAIgFAAgIQAAgJgIgFQgEgDgIAAIgQAAg");
	this.shape_10.setTransform(12.15,-114.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext4, new cjs.Rectangle(0,-129.2,182.8,31.999999999999986), null);


(lib.Ctext3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhFBgIAAjAICIAAIAAAyIhJAAIAAAVIBFAAIAAAxIhFAAIAAAWIBMAAIAAAyg");
	this.shape.setTransform(107.45,-139.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAaBgIAAhHIg0AAIAABHIg/AAIAAjAIA/AAIAABHIA0AAIAAhHIBAAAIAADAg");
	this.shape_1.setTransform(88.7,-139.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgfBgIAAiPIgtAAIAAgxICZAAIAAAxIguAAIAACPg");
	this.shape_2.setTransform(70.65,-139.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAPBgIgehAIgJAAIAABAIg/AAIAAjAIBVAAQAiABAVAOQAXAQAAAfQAAAmggATIAsBJgAgYgPIAQAAQAJAAAFgDQAGgFABgJQgBgIgGgEQgFgEgJAAIgQAAg");
	this.shape_3.setTransform(49.2,-139.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhLBKQgdgbAAgvQAAgtAdgbQAegbAtAAQAvAAAcAbQAeAbAAAtQAAAvgeAbQgdAaguAAQgtAAgegagAgdghQgLAMAAAVQAAATALAMQAMANARAAQATAAALgNQALgMAAgTQAAgVgLgMQgLgMgTAAQgSAAgLAMg");
	this.shape_4.setTransform(28,-139.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhCBgIAAjAICFAAIAAAyIhGAAIAAAeIBCAAIAAAxIhCAAIAAA/g");
	this.shape_5.setTransform(10.125,-139.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext3, new cjs.Rectangle(0,-154.5,117.5,32), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYAWQgJgIAAgOQAAgNAJgIQAJgIAPAAQAQAAAJAIQAJAIAAANQAAAOgJAIQgJAIgQAAQgPAAgJgIg");
	this.shape.setTransform(133.775,-158.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeBhIAAiPIguAAIAAgyICZAAIAAAyIgtAAIAACPg");
	this.shape_1.setTransform(124,-165);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeBhIAAjBIA+AAIAADBg");
	this.shape_2.setTransform(111.75,-165);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhCBhIAAjBICFAAIAAAyIhGAAIAAAeIBCAAIAAAxIhCAAIAABAg");
	this.shape_3.setTransform(99.925,-165);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeBhIAAiPIguAAIAAgyICZAAIAAAyIgtAAIAACPg");
	this.shape_4.setTransform(78.65,-165);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAbBhIAAhIIg0AAIAABIIg/AAIAAjBIA/AAIAABGIA0AAIAAhGIA/AAIAADBg");
	this.shape_5.setTransform(60.6,-165);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhABMQgfgcAAgwQAAgwAggaQAcgZAqAAQAiAAAZAPQAKAGANANIgqAjQgRgQgXAAQgQAAgLAMQgLANAAAVQAAAWALANQALAMAQAAQAVABAEgGIACgBIAAgPIgdAAIAAgtIBbAAIAABTIgLAJIgMAJQgKAHgHACQgWAJgcgBQgpAAgdgXg");
	this.shape_6.setTransform(39.7,-165);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgeBhIAAjBIA+AAIAADBg");
	this.shape_7.setTransform(25,-165);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAOBhIgdhBIgIAAIAABBIg/AAIAAjBIBTAAQAkAAATAOQAYARAAAfQAAAmggATIArBKgAgXgPIAQAAQAIAAAEgDQAIgFAAgIQAAgJgIgFQgEgDgIAAIgQAAg");
	this.shape_8.setTransform(12.15,-165);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(0,-179.7,140.9,32), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhFBgIAAi/ICIAAIAAAxIhJAAIAAAVIBFAAIAAAxIhFAAIAAAWIBMAAIAAAyg");
	this.shape.setTransform(46.5,-190.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAbBgIAAhHIg0AAIAABHIg/AAIAAi/IA/AAIAABGIA0AAIAAhGIA/AAIAAC/g");
	this.shape_1.setTransform(27.75,-190.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeBgIAAiPIguAAIAAgwICZAAIAAAwIgtAAIAACPg");
	this.shape_2.setTransform(9.7,-190.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(0,-205,56.5,32), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgfAsIAAhXIA+AAIAAAXIghAAIAAAJIAfAAIAAAWIgfAAIAAAKIAhAAIAAAXg");
	this.shape.setTransform(86.4,-58.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AAGAsIgMgdIgEAAIAAAdIgdAAIAAhXIAmAAQAQAAAIAHQALAHAAAOQAAARgOAJIATAhgAgKgGIAHAAQAEAAACgBQACgDAAgEQAAgDgCgDQgCgBgEAAIgHAAg");
	this.shape_1.setTransform(78.85,-58.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AghAhQgNgMAAgVQAAgUANgMQANgMAUAAQAVAAAOAMQANAMgBAUQABAVgNAMQgOAMgVAAQgUAAgNgMgAgNgOQgEAFAAAJQAAAJAEAFQAGAGAHAAQAJAAAEgGQAGgFgBgJQABgJgGgFQgEgGgJAAQgHAAgGAGg");
	this.shape_2.setTransform(69.25,-58.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AAZAsIgBgxIgMAxIgXAAIgMgxIgBAxIgcAAIAFhXIAlAAIAKAvIALgvIAlAAIAFBXg");
	this.shape_3.setTransform(58.575,-58.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AAMAsIgagwIABAPIAAAhIgcAAIAAhXIAfAAIAZAwIgBgPIAAghIAcAAIAABXg");
	this.shape_4.setTransform(45.675,-58.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AAGAsIgMgdIgEAAIAAAdIgdAAIAAhXIAnAAQAPAAAIAHQAMAHAAAOQAAARgPAJIATAhgAgKgGIAHAAQADAAACgBQADgDAAgEQAAgDgDgDQgCgBgDAAIgHAAg");
	this.shape_5.setTransform(37.1,-58.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AAPAsIgDgNIgYAAIgEANIgdAAIAehXIAfAAIAeBXgAAGAKIgGgXIgGAXIAMAAg");
	this.shape_6.setTransform(28.025,-58.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgfAsIAAhXIA9AAIAAAXIggAAIAAAJIAfAAIAAAWIgfAAIAAAKIAhAAIAAAXg");
	this.shape_7.setTransform(20,-58.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AgcAsIAAhXIAcAAIAAA/IAdAAIAAAYg");
	this.shape_8.setTransform(13.15,-58.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AmuB/QhAAAAAg5IAAiLQAAg5BAAAINdAAQBAAAAAA5IAACLQAAA5hAAAg");
	this.shape_9.setTransform(49.4,-58.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(-0.1,-71.6,99,25.39999999999999), null);


(lib.Btext22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAPBgIgehAIgJAAIAABAIg/AAIAAi/IBVAAQAiAAAVANQAXARAAAfQAAAmggATIAsBJgAgYgOIAQAAQAJAAAFgEQAGgFAAgIQAAgJgGgFQgFgDgJAAIgQAAg");
	this.shape.setTransform(99.05,-213.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhLBJQgdgbAAguQAAgtAdgbQAegbAtAAQAuAAAeAbQAdAbAAAtQAAAugdAbQgeAbguAAQgtAAgegbgAgdggQgLALAAAUQAAAUALANQAMAMARAAQASAAAMgMQALgNAAgUQAAgUgLgLQgMgNgSAAQgSAAgLANg");
	this.shape_1.setTransform(77.85,-213.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhPBgIAAi/IBTAAQAjAAATAPQAWARAAAiQAAAhgWARQgTAPgjAAIgUAAIAAA8gAgQgKIALAAQAJAAAFgDQAHgFAAgLQAAgLgHgFQgFgDgJAAIgLAAg");
	this.shape_2.setTransform(58.675,-213.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAiBgIgIgbIg2AAIgIAbIhBAAIBDi/IBFAAIBDC/gAANAVIgOgzIgOAzIAcAAg");
	this.shape_3.setTransform(39.4,-213.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeBgIhJi/IBEAAIAjBuIAkhuIBDAAIhJC/g");
	this.shape_4.setTransform(20.65,-213.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAPBgIgehAIgJAAIAABAIg/AAIAAi/IBVAAQAiAAAVANQAXARAAAfQAAAmggATIAsBJgAgYgOIAQAAQAJAAAFgEQAGgFAAgIQAAgJgGgFQgFgDgJAAIgQAAg");
	this.shape_5.setTransform(-3.2,-213.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhFBgIAAi/ICIAAIAAAxIhJAAIAAAVIBFAAIAAAxIhFAAIAAAWIBMAAIAAAyg");
	this.shape_6.setTransform(-21.15,-213.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhCBLQgVgVAAgqIAAhtIA/AAIAABwQAAAPAHAGQAHAHAKAAQALAAAHgHQAGgGAAgPIAAhwIBAAAIAABtQAAAqgVAVQgWAXgtAAQgrAAgXgXg");
	this.shape_7.setTransform(-39.625,-213.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAhBgIgHgbIg2AAIgIAbIhBAAIBDi/IBFAAIBDC/gAANAVIgOgzIgOAzIAcAAg");
	this.shape_8.setTransform(-59.6,-213.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhSBgIAAi/IBQAAQAeAAARAGQANAGAHAKQAJALAAAPQAAAPgJAMQgHAMgMAEQASAEAJAMQAKAMAAARQAAAcgVAPQgTAMggAAgAgTAyIATAAQAUgBAAgPQAAgIgFgDQgGgEgJAAIgTAAgAgTgWIAMAAQAIAAAFgDQAGgEgBgHQABgIgGgDQgEgDgJAAIgMAAg");
	this.shape_9.setTransform(-78.25,-213.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-228.7,199.6,32);


(lib.Btext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhFBgIAAi/ICIAAIAAAxIhJAAIAAAVIBFAAIAAAxIhFAAIAAAWIBMAAIAAAyg");
	this.shape.setTransform(142.7,-220.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeBgIhIi/IBCAAIAkBuIAkhuIBEAAIhKC/g");
	this.shape_1.setTransform(124.25,-220.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeBgIAAi/IA+AAIAAC/g");
	this.shape_2.setTransform(109.6,-220.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhOBJIAcgvQANAKAPAFQAPAGAIAAQAOAAAAgIQgBgHgMgEIgbgIQgTgIgIgHQgSgOAAgaQAAgcAWgTQAVgQAkAAQApAAAbAXIgYAtQgKgJgNgFQgOgFgJAAQgOAAAAAIQAAAGAMADIAJADIAOAEQAVAHALAJQASAPAAAaQAAAfgZAUQgVAQgjAAQgnAAgkgag");
	this.shape_3.setTransform(96.95,-219.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhCBMQgVgVAAgqIAAhuIA/AAIAABwQAAAPAHAGQAHAHAKAAQALAAAHgHQAGgGAAgPIAAhwIBAAAIAABuQAAAqgVAVQgWAWgtAAQgrAAgXgWg");
	this.shape_4.setTransform(79.025,-219.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag/BgIAAi/IA/AAIAACLIBAAAIAAA0g");
	this.shape_5.setTransform(62.775,-220.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag4BJQgdgaAAgvQAAguAdgaQAegbArAAQAaAAAQAHQAMAEAJAFIACADIgQA1IgHgFQgDgCgNgFQgLgFgKAAQgUAAgLALQgNAMAAAVQAAATANAMQALAMAUAAQAdAAARgSIASAyQgYAZgtAAQgrAAgegbg");
	this.shape_6.setTransform(46.35,-220.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAeBgIgeg9IgeA9IhMAAIBBhkIg9hbIBMAAIAaAzIAbgzIBLAAIg8BbIBBBkg");
	this.shape_7.setTransform(28.3,-220.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhFBgIAAi/ICIAAIAAAxIhJAAIAAAVIBFAAIAAAxIhFAAIAAAWIBMAAIAAAyg");
	this.shape_8.setTransform(10.4,-220.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btext1, new cjs.Rectangle(0,-234.8,152.7,32), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-97.8,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-279.3,114.8,32);


// stage content:
(lib.fam_336x280_us = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(179.8,315,1.12,1.12,0,0,0,62,18.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(309).to({_off:false},0).to({alpha:1},22,cjs.Ease.cubicInOut).wait(12));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(-101.85,413.9,1.12,1.12,0,0,0,84.2,10.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(292).to({_off:false},0).to({x:166.9},20,cjs.Ease.quartOut).wait(31));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(166.05,299.5,0.448,0.448,0,0,0,177.6,184.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(268).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(46));

	// skate3
	this.instance_3 = new lib.skate3();
	this.instance_3.setTransform(196,562.8,1.12,1.12,0,0,0,57,61.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({x:109.75},20,cjs.Ease.quartOut).wait(187).to({x:196.55},18,cjs.Ease.quintInOut).wait(70));

	// skate2
	this.instance_4 = new lib.skate2();
	this.instance_4.setTransform(334.3,498.4,1.12,1.12,0,0,0,57,62);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({_off:false},0).to({x:247.5},20,cjs.Ease.quartOut).wait(190).to({x:334.3},18,cjs.Ease.quintInOut).wait(71));

	// skate1
	this.instance_5 = new lib.skate1();
	this.instance_5.setTransform(190.5,412.7,1.12,1.12,0,0,0,56.1,61.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(40).to({_off:false},0).to({x:108.75},20,cjs.Ease.quartOut).wait(193).to({x:202.55},18,cjs.Ease.quintInOut).wait(72));

	// cta
	this.instance_6 = new lib.CTA();
	this.instance_6.setTransform(94.65,320.25,1.12,1.12,0,0,0,62.1,18.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(145).to({y:263.15},23,cjs.Ease.quartInOut).wait(81).to({y:269.85,alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(76));

	// Ctext4
	this.instance_7 = new lib.Ctext4();
	this.instance_7.setTransform(-173.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(160).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(78));

	// Ctext3
	this.instance_8 = new lib.Ctext3();
	this.instance_8.setTransform(-103.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(157).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(81));

	// Ctet2
	this.instance_9 = new lib.Ctext2();
	this.instance_9.setTransform(-117.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(154).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_10 = new lib.Ctext1();
	this.instance_10.setTransform(-103.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(151).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// Btext6
	this.instance_11 = new lib.text6();
	this.instance_11.setTransform(-179.1,366.45,1.12,1.12);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(22).to({_off:false},0).to({x:123.25},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(189));

	// Btext2_copy
	this.instance_12 = new lib.text3();
	this.instance_12.setTransform(-179.1,366.45,1.12,1.12);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(19).to({_off:false},0).to({x:123.25},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(192));

	// Btext2
	this.instance_13 = new lib.Btext22();
	this.instance_13.setTransform(-156.25,366.45,1.12,1.12);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(17).to({_off:false},0).to({x:123.25},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(194));

	// Btext1
	this.instance_14 = new lib.Btext1();
	this.instance_14.setTransform(-147.8,372.95,1.12,1.12,0,0,0,74.8,24);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(13).to({_off:false},0).to({x:106.15,y:371.6},22,cjs.Ease.quartOut).wait(93).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(197));

	// text2
	this.instance_15 = new lib.Tween2("synched",0);
	this.instance_15.setTransform(-158.95,366.45,1.12,1.12);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(9).to({_off:false},0).to({x:123.25},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_16 = new lib.text1();
	this.instance_16.setTransform(-206.95,282.9,1.12,1.12,0,0,0,74.8,24);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(5).to({_off:false},0).to({x:106.15},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// bg
	this.instance_17 = new lib.Asset1();
	this.instance_17.setTransform(0,0,0.6021,0.6054);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("EgaPA0gMAAAho/MA0fAAAMAAABo/g");
	this.shape.setTransform(168,336);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_17}]}).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-122.7,140,540.9,532);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 336,
	height: 280,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/fam_336x280_us_atlas_P_1.png", id:"fam_336x280_us_atlas_P_1"},
		{src:"images/fam_336x280_us_atlas_NP_1.jpg", id:"fam_336x280_us_atlas_NP_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;