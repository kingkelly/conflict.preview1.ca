(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"jetfam_728x90_us_atlas_P_1", frames: [[0,126,131,130],[133,126,121,121],[256,126,121,121],[0,0,1000,124]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset2pngcopy = function() {
	this.initialize(ss["jetfam_728x90_us_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset3 = function() {
	this.initialize(ss["jetfam_728x90_us_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Asset4 = function() {
	this.initialize(ss["jetfam_728x90_us_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Asset8jetfamTearLB = function() {
	this.initialize(ss["jetfam_728x90_us_atlas_P_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUATQgHgHAAgMQAAgLAHgGQAIgHAMAAQANAAAHAHQAIAGAAALQAAAMgIAHQgHAGgNAAQgMAAgIgGg");
	this.shape.setTransform(244.825,-146.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgZBPIAAg+Ig3hfIA6AAIAWA1IAXg1IA6AAIg3BfIAAA+g");
	this.shape_1.setTransform(236.15,-152.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag0BPIAAidIA0AAIAABzIA1AAIAAAqg");
	this.shape_2.setTransform(225.075,-152.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgZBPIAAidIAzAAIAACdg");
	this.shape_3.setTransform(214.95,-152.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAtBPIgChaIgUBaIgsAAIgWhaIgBBaIgzAAIAJidIBDAAIATBVIAUhVIBDAAIAJCdg");
	this.shape_4.setTransform(200.95,-152.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAcBPIgHgWIgsAAIgGAWIg2AAIA3idIA5AAIA3CdgAAKARIgKgpIgMApIAWAAg");
	this.shape_5.setTransform(182.525,-152.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag2BPIAAidIBtAAIAAAoIg6AAIAAAZIA3AAIAAAoIg3AAIAAA0g");
	this.shape_6.setTransform(169.425,-152.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhKBPIAAidIA8AAQAoAAAWARQAbAUAAApQAAAqgbAUQgWARgoAAgAgWAkIAMAAQAPAAAIgJQAJgJAAgSQAAgTgJgJQgIgIgPAAIgMAAg");
	this.shape_7.setTransform(150.375,-152.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApg");
	this.shape_8.setTransform(135.35,-152.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApg");
	this.shape_9.setTransform(122.05,-152.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhABPIAAidIBDAAQAdAAAPAMQATAOgBAcQABAbgTAOQgPANgdAAIgPAAIAAAxgAgNgIIAJAAQAIAAAEgDQAFgEAAgJQAAgJgFgDQgEgDgIAAIgJAAg");
	this.shape_10.setTransform(108.5,-152.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhAA8IAXgnQALAJAMAEQANAFAGAAQAMAAAAgHQgCgGgKgDIgWgHQgPgGgHgFQgPgMAAgVQAAgYATgPQARgOAdAAQAiAAAXAUIgVAkQgHgHgMgEQgLgEgHAAQgMAAAAAHQAAAEAKADIAIACIALAEQARAGAJAHQAPAMABAWQAAAZgWAQQgRAOgdAAQgfAAgegWg");
	this.shape_11.setTransform(94.15,-152.475);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_12.setTransform(81.725,-152.525);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA/AAIAAApg");
	this.shape_13.setTransform(69,-152.525);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAtBPIgChaIgUBaIgsAAIgWhaIgBBaIgzAAIAJidIBDAAIATBVIAUhVIBDAAIAJCdg");
	this.shape_14.setTransform(38.5,-152.525);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgtA8QgZgWAAgmQAAgmAZgVQAYgWAjAAQAVAAAOAGQAKADAGAEIACACIgNArIgFgDQgDgCgKgEQgKgEgIAAQgQAAgJAJQgKAKAAARQAAAQAKAKQAJAJAQAAQAXAAAPgPIAPAqQgUAUglAAQgjAAgYgWg");
	this.shape_15.setTransform(21.125,-152.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgtA8QgZgWAAgmQAAgmAZgVQAYgWAjAAQAVAAAOAGQAKADAGAEIACACIgNArIgFgDQgDgCgKgEQgKgEgIAAQgQAAgJAJQgKAKAAARQAAAQAKAKQAJAJAQAAQAXAAAPgPIAPAqQgUAUglAAQgjAAgYgWg");
	this.shape_16.setTransform(7.025,-152.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgaBSIgMgDIACgnQAIAEAGAAQAEAAACgDQACgBAAgGIAAh0IA1AAIAAB0QAAAagMAMQgMALgVAAIgUgBg");
	this.shape_17.setTransform(57.325,-152.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(-2.5,-165,253.6,27), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA+AAIAAApg");
	this.shape.setTransform(323.2,-197.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgZBPIg7idIA3AAIAdBbIAehbIA3AAIg8Cdg");
	this.shape_1.setTransform(308.05,-197.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgZBPIAAidIAzAAIAACdg");
	this.shape_2.setTransform(296.05,-197.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhAA8IAYgnQAKAJAMAEQAMAFAHAAQAMAAAAgHQgCgGgKgDIgWgHQgPgGgHgFQgOgMAAgVQAAgYASgPQAQgOAeAAQAiAAAWAUIgUAkQgHgHgMgEQgLgEgHAAQgMAAAAAHQAAAEAKADIAIACIALAEQASAGAJAHQAPAMAAAWQAAAZgWAQQgRAOgdAAQgfAAgegWg");
	this.shape_3.setTransform(285.65,-197.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag2A+QgRgSAAgiIAAhaIA0AAIAABdQAAALAFAGQAGAFAIAAQAJAAAGgFQAFgGAAgLIAAhdIA0AAIAABaQAAAigRASQgSASglAAQgjAAgTgSg");
	this.shape_4.setTransform(270.925,-197.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag0BPIAAidIA0AAIAABzIA1AAIAAAqg");
	this.shape_5.setTransform(257.625,-197.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgtA8QgZgVAAgnQAAglAZgWQAYgWAjAAQAVAAAOAGQAKADAGAFIACABIgNAsIgFgEQgDgCgKgEQgKgEgIAAQgQAAgJAJQgKAKAAARQAAAQAKAJQAJAKAQAAQAXAAAPgPIAPApQgUAVglAAQgjAAgYgWg");
	this.shape_6.setTransform(244.125,-197.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAZBPIgZgyIgZAyIg9AAIA0hSIgyhLIA/AAIAVAqIAWgqIA+AAIgyBLIA2BSg");
	this.shape_7.setTransform(229.3,-197.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_8.setTransform(214.6,-197.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA+AAIAAApg");
	this.shape_9.setTransform(196.85,-197.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgtA8QgZgVAAgnQAAglAZgWQAYgWAjAAQAVAAAOAGQAKADAGAFIACABIgNAsIgFgEQgDgCgKgEQgKgEgIAAQgQAAgJAJQgKAKAAARQAAAQAKAJQAJAKAQAAQAXAAAPgPIAPApQgUAVglAAQgjAAgYgWg");
	this.shape_10.setTransform(182.875,-197.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgHgFgDQgEgDgHAAIgNAAg");
	this.shape_11.setTransform(168.525,-197.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag2A+QgRgSAAgiIAAhaIA0AAIAABdQAAALAFAGQAGAFAIAAQAJAAAGgFQAFgGAAgLIAAhdIA0AAIAABaQAAAigRASQgSASglAAQgjAAgTgSg");
	this.shape_12.setTransform(151.925,-197.75);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAQAJAKQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_13.setTransform(134.575,-197.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag/A8IAWgnQALAJAMAEQAMAFAHAAQAMAAgBgHQgBgGgKgDIgWgHQgPgGgHgFQgOgMAAgVQAAgYASgPQAQgOAeAAQAiAAAWAUIgTAkQgJgHgKgEQgMgEgHAAQgMAAAAAHQAAAEAKADIAIACIALAEQARAGAKAHQAPAMgBAWQAAAZgUAQQgSAOgcAAQghAAgcgWg");
	this.shape_14.setTransform(118.85,-197.825);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_15.setTransform(101.55,-197.875);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAVBPIAAg6IgqAAIAAA6IgzAAIAAidIAzAAIAAA5IAqAAIAAg5IA1AAIAACdg");
	this.shape_16.setTransform(86.15,-197.875);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_17.setTransform(71.325,-197.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_18.setTransform(54.225,-197.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApg");
	this.shape_19.setTransform(41.5,-197.875);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_20.setTransform(28.2,-197.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAtBPIgChaIgUBaIgsAAIgWhaIgBBaIgzAAIAJidIBDAAIATBVIAUhVIBDAAIAJCdg");
	this.shape_21.setTransform(11.05,-197.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(-1.2,-210.3,333,27), null);


(lib.skate3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset4();
	this.instance.setTransform(188,-274,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate3, new cjs.Rectangle(188,-274,66.6,66.6), null);


(lib.skate2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset3();
	this.instance.setTransform(65,-293,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate2, new cjs.Rectangle(65,-293,66.6,66.6), null);


(lib.skate1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset2pngcopy();
	this.instance.setTransform(187,-292,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate1, new cjs.Rectangle(187,-292,72.10000000000002,71.5), null);


(lib.rip = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset8jetfamTearLB();
	this.instance.setTransform(-10,0,0.7424,0.7424);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rip, new cjs.Rectangle(-10,0,742.4,92.1), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgFAWIAAggIgJAAIAAgKIAdAAIAAAKIgJAAIAAAgg");
	this.shape.setTransform(155.3319,-362.3244,0.5482,0.5482);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPAWIgDgXIgJAXIgFAAIgJgXIgDAXIgMAAIAHgqIAMAAIAHAUIAJgUIALAAIAHAqg");
	this.shape_1.setTransform(157.7303,-362.3244,0.5482,0.5482);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgkCRIAAiLIhqiWIBaAAIA1BQIA1hQIBaAAIhrCWIAACLg");
	this.shape_2.setTransform(144.4501,-355.5678,0.5482,0.5482);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhRCRIAAkhICkAAIAABAIhZAAIAAAxIBTAAIAAA+IhTAAIAAAyIBZAAIAABAg");
	this.shape_3.setTransform(131.0739,-355.5678,0.5482,0.5482);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAmCRIhhh+IAAB+IhLAAIAAkhIBLAAIAAB4IBah4IBeAAIhzCKIB+CXg");
	this.shape_4.setTransform(117.3141,-355.5678,0.5482,0.5482);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhABuQguguAAhAQAAhBAugsQAtgrA9AAQAhAAAkAPIAABaQgagggnAAQghAAgWAXQgWAWAAAiQAAAiAWAXQAWAXAhAAQAkAAAdgfIAABZIgIADQgiAMgcAAQg8AAgtgrg");
	this.shape_5.setTransform(101.2106,-355.5541,0.5482,0.5482);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhyBtQgtgsAAhBQAAhAAtgsQAtgsBFAAQBGAAAtAsQAtAsAABAQAABBgtAsQgtAshGAAQhFAAgtgsgAg4g4QgZAXAAAhQAAAiAZAYQAXAWAhAAQAhAAAYgWQAZgYAAgiQAAghgZgXQgYgXghAAQghAAgXAXg");
	this.shape_6.setTransform(84.463,-355.5541,0.5482,0.5482);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AA2CRIAAh3IhsAAIAAB3IhKAAIAAkhIBKAAIAABwIBsAAIAAhwIBMAAIAAEhg");
	this.shape_7.setTransform(65.9749,-355.5678,0.5482,0.5482);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAaCRIhGhvIAABvIhMAAIAAkhIB2AAQAtAAAaAbQAXAYABAnQgBBCg+AOIBbB3gAgsgOIAOAAQAWAAALgKQAMgJAAgRQAAgRgMgJQgLgKgWAAIgOAAg");
	this.shape_8.setTransform(43.3889,-355.5678,0.5482,0.5482);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhyBtQgtgsAAhBQAAhAAtgsQAtgsBFAAQBGAAAtAsQAtAsAABAQAABBgtAsQgtAshGAAQhFAAgtgsgAg4g4QgYAXAAAhQAAAiAYAYQAXAWAhAAQAiAAAXgWQAZgYAAgiQAAghgZgXQgXgXgiAAQghAAgXAXg");
	this.shape_9.setTransform(25.3942,-355.5541,0.5482,0.5482);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhSCRIAAkhIClAAIAABAIhaAAIAAAxIBSAAIAAA+IhSAAIAAByg");
	this.shape_10.setTransform(10.3186,-355.5678,0.5482,0.5482);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AigEbIAAo1IFBAAIAAB9IiuAAIAABeIClAAIAAB8IilAAIAABhICuAAIAAB9g");
	this.shape_11.setTransform(160.9647,-396.9297,0.5482,0.5482);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbEYQg3gWgtgoQhchTABiGQgBg6AWg2QAWg3ApgqQAqgrA6gZQA4gZA9AAQBBAABIAdIAACzQgXgfgkgQQghgRgoAAQhDABgqAtQgqAuAABDQAABEArArQAqAsBFAAQAkAAAigQQAjgQAYgdIAACzQgxAPgTAEQghAIgfAAQg8AAg3gWg");
	this.shape_12.setTransform(132.0333,-396.8886,0.5482,0.5482);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AA0EbIiKjaIgBAAIAADaIiTAAIAAo1IDcAAQBXAAA0AqQA4AtAABXQAAA9ggArQghAtg7AKICyDogAhXgcIAOAAQAtAAAYgMQAggRAAgqQAAgpgggRQgYgNgtAAIgOAAg");
	this.shape_13.setTransform(103.6775,-396.9297,0.5482,0.5482);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhkEVQg1gRgiggQglglgOg4QgIgmAAhFIAAk+ICTAAIAAEqQAABIAOAgQAXAxA+AAQA/AAAWgxQAPggAAhIIAAkqICTAAIAAE+QAABFgJAmQgNA4glAlQgiAgg1ARQgvAOg2AAQg2AAgugOg");
	this.shape_14.setTransform(69.1545,-396.5185,0.5482,0.5482);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AjgDWQhYhXAAiIQAAh+BghUQBbhRB9AAQB+AABbBRQBgBUAAB+QAACIhZBXQhYBYiIAAQiIAAhYhYgAhwhxQgvAuAAA6QAABIAvAwQAuAwBCAAQBDAAAugwQAvgwAAhIQAAg6gvguQgwgthBAAQhAAAgwAtg");
	this.shape_15.setTransform(32.0823,-396.916,0.5482,0.5482);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ah8EeQgwgPgYgYIAAiLQAbAgAyAXQAxAVAnAAQAnABAUgOQATgOAAgYQAAgYgVgPQgWgOg1gVQiTg1AAiAQAAhNA2gzQA2gzBZAAQAyAAApAOQApANAaATIAACJQgWgZgpgUQgpgUgkAAQghAAgRAOQgRAOgBAXQAAAYAUAOQARAPAyATQBJAaArAsQArAuABA+QgBBRg4AzQg4A0hmAAQg6AAgxgQg");
	this.shape_16.setTransform(-2.2763,-396.8886,0.5482,0.5482);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAvKLQiJAAh6g0Qh6g0hbhhQhVhbgvh2Qguh1AAh8QAAkMC/i/QC/i/EMAAQFCADDrC6IAAEAQh7hsiFgzQiEg0iaAAQizAAh3CDQhuB5AACdQAACcBwB6QB4CDCtAAQA2AAAkAkQAkAkAAA2QAAA0goAlQgnAigvAAg");
	this.shape_17.setTransform(-80.8749,-394.2983,0.5482,0.5482);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AmRIxQiMhEhthyIAAkGQB9CFB+BGQCvBhDSAAQCzAAB3iDQBuh4AAifQAAibhwh6Qh4iDiuABQg2AAgkgkQgkgjAAg3QAAg2ApgkQAlgiAwAAIAMAAQCJAAB7A0QB6A0BbBjQBVBaAvB2QAuB2AAB5QAAEOi/C+Qi+C/kOAAQjagCi3hYg");
	this.shape_18.setTransform(-75.6943,-366.3537,0.5482,0.5482);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(-114,-430,283.8,99.39999999999998), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfAVIgDgWIgKAWIgFAAIgJgWIgDAWIgLAAIAHgpIALAAIAIAUIAJgUIALAAIAHApgAghAVIAAgfIgJAAIAAgKIAeAAIAAAKIgJAAIAAAfg");
	this.shape.setTransform(375.5264,-323.5014,0.8232,0.8232);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgUATQgIgHAAgMQAAgLAIgHQAIgHAMABQANAAAIAGQAIAIAAAKQAAAMgIAHQgIAHgNgBQgMABgIgHg");
	this.shape_1.setTransform(374.25,-311.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag6BRIAAihIByAAIAAAqIg9AAIAAARIA6AAIAAApIg6AAIAAATIBAAAIAAAqg");
	this.shape_2.setTransform(363.55,-317.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAuBRIgChcIgVBcIgtAAIgVhcIgCBcIg0AAIAJihIBFAAIATBXIAVhXIBEAAIAJChg");
	this.shape_3.setTransform(345.925,-317.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAdBRIgHgXIgtAAIgGAXIg4AAIA4ihIA7AAIA4ChgAALASIgLgrIgMArIAXAAg");
	this.shape_4.setTransform(327.05,-317.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag1BAQgbgXAAgpQAAgoAbgWQAYgVAkAAQAcAAAVANQAIAFALALIgjAdQgOgOgTAAQgOAAgJAKQgKALAAASQAAATAKAKQAJALAOAAQAQAAAFgEIABgCIAAgMIgZAAIAAgmIBNAAIAABGIgJAIIgLAIQgHAEgHADQgSAHgYAAQgiAAgYgUg");
	this.shape_5.setTransform(309.825,-317.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AANBRIgZg2IgHAAIAAA2Ig2AAIAAihIBHAAQAeAAAQALQAUAOAAAaQAAAggbAQIAlA+gAgTgMIANAAQAHAAAEgDQAGgEAAgHQAAgHgGgEQgEgDgHAAIgNAAg");
	this.shape_6.setTransform(289.725,-317.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag3A/QgSgRAAgkIAAhcIA1AAIAABfQAAAMAGAGQAGAFAIAAQAJAAAGgFQAGgGAAgMIAAhfIA1AAIAABcQAAAkgRARQgTAUgmgBQgkABgTgUg");
	this.shape_7.setTransform(272.775,-317.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag/A+QgZgXABgnQgBgmAZgXQAZgWAmAAQAnAAAYAWQAZAXAAAmQAAAngZAXQgYAWgnAAQgmAAgZgWgAgYgbQgKAKAAARQAAAQAKAKQAJALAPgBQAPABAKgLQAKgKgBgQQABgRgKgKQgKgLgPAAQgPAAgJALg");
	this.shape_8.setTransform(255.05,-317.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgaBRIAAg/Ig4hiIA6AAIAYA3IAYg3IA7AAIg4BiIAAA/g");
	this.shape_9.setTransform(238.9,-317.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgaBRIAAh4IgmAAIAAgpICBAAIAAApIgmAAIAAB4g");
	this.shape_10.setTransform(220,-317.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgaBRIAAihIA1AAIAAChg");
	this.shape_11.setTransform(209.725,-317.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag4BRIAAihIBxAAIAAAqIg7AAIAAAZIA3AAIAAApIg3AAIAAA1g");
	this.shape_12.setTransform(199.775,-317.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag6BRIAAihIByAAIAAAqIg9AAIAAARIA6AAIAAApIg6AAIAAATIBAAAIAAAqg");
	this.shape_13.setTransform(181.75,-317.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAWBRIgWhbIgVBbIg2AAIguihIA3AAIAVBZIAUhZIA0AAIATBZIAUhZIA4AAIguChg");
	this.shape_14.setTransform(162.75,-317.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(148.1,-330.7,233.29999999999998,29.099999999999966), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUASQgHgGAAgMQAAgKAHgHQAIgHAMAAQANAAAHAHQAIAHAAAKQAAAMgIAGQgHAHgNAAQgMAAgIgHg");
	this.shape.setTransform(254.725,-181.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_1.setTransform(246.675,-187.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_2.setTransform(233.95,-187.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag0A+QgagWAAgoQAAgnAbgWQAXgUAiAAQAcAAAUAMQAIAFALALIgiAdQgOgOgTAAQgNAAgJAKQgJALAAARQAAASAJALQAJAKANAAQARAAAEgEIABgCIAAgLIgYAAIAAgmIBLAAIAABFIgJAHIgKAIQgIAFgGACQgSAHgXAAQgiAAgXgUg");
	this.shape_3.setTransform(218.375,-187.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhKBPIAAidIA8AAQAoAAAWARQAbAUAAApQAAAqgbAUQgWARgoAAgAgWAkIAMAAQAPAAAIgJQAJgJAAgSQAAgTgJgJQgIgIgPAAIgMAAg");
	this.shape_4.setTransform(202.125,-187.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag2A+QgRgSAAgiIAAhaIA0AAIAABdQAAALAFAGQAGAFAIAAQAJAAAGgFQAFgGAAgLIAAhdIA0AAIAABaQAAAigRASQgSASglAAQgjAAgTgSg");
	this.shape_5.setTransform(185.225,-187.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhEBPIAAidIBCAAQAZAAAOAFQAKAFAHAIQAGAKAAAMQAAAMgGAKQgGAJgKAEQAOADAIAKQAJAKAAANQAAAYgSAMQgQAKgaAAgAgQApIAQAAQAQAAAAgNQAAgGgEgEQgEgCgIAAIgQAAgAgQgSIAKAAQAHAAAEgCQAEgEAAgFQAAgGgEgEQgDgCgIAAIgKAAg");
	this.shape_6.setTransform(169.825,-187.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgZBPIAAg+Ig3hfIA6AAIAWA1IAXg1IA6AAIg3BfIAAA+g");
	this.shape_7.setTransform(149.75,-187.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgHgFgDQgEgDgHAAIgNAAg");
	this.shape_8.setTransform(135.725,-187.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_9.setTransform(121,-187.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgYBPIg8idIA3AAIAdBbIAehbIA3AAIg8Cdg");
	this.shape_10.setTransform(105.85,-187.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApg");
	this.shape_11.setTransform(91.15,-187.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgHgFgDQgEgDgHAAIgNAAg");
	this.shape_12.setTransform(72.975,-187.525);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAQAJAKQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_13.setTransform(55.575,-187.525);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag2BPIAAidIBtAAIAAAoIg6AAIAAAZIA3AAIAAAoIg3AAIAAA0g");
	this.shape_14.setTransform(40.875,-187.525);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_15.setTransform(23.425,-187.525);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgZBPIAAidIAzAAIAACdg");
	this.shape_16.setTransform(13.4,-187.525);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag2BPIAAidIBtAAIAAAoIg6AAIAAAZIA3AAIAAAoIg3AAIAAA0g");
	this.shape_17.setTransform(3.675,-187.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(-5,-200,266,27), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AghAwIAAhfIBCAAIAAAZIgkAAIAAAKIAiAAIAAAYIgiAAIAAALIAlAAIAAAZg");
	this.shape.setTransform(501.3,-221.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AAHAwIgOggIgEAAIAAAgIgfAAIAAhfIApAAQARAAAKAHQAMAIAAAQQAAASgQAJIAVAlgAgLgHIAIAAQAEAAACgBQADgDAAgEQAAgEgDgCQgDgCgDAAIgIAAg");
	this.shape_1.setTransform(493.075,-221.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AgkAkQgPgNAAgXQAAgWAPgNQAOgNAWAAQAXAAAOANQAPANAAAWQAAAXgPANQgOANgXAAQgWAAgOgNgAgOgQQgGAGAAAKQAAAJAGAHQAGAGAIAAQAJAAAGgGQAFgHAAgJQAAgKgFgGQgGgGgJAAQgIAAgGAGg");
	this.shape_2.setTransform(482.575,-221.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AAbAwIgBg2IgMA2IgaAAIgNg2IgBA2IgfAAIAFhfIApAAIALAzIAMgzIAoAAIAGBfg");
	this.shape_3.setTransform(470.95,-221.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AANAwIgcg1IABARIAAAkIgfAAIAAhfIAiAAIAbA0IgBgQIAAgkIAfAAIAABfg");
	this.shape_4.setTransform(456.825,-221.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AAHAwIgOggIgEAAIAAAgIgfAAIAAhfIApAAQARAAAKAHQAMAIAAAQQAAASgQAJIAVAlgAgLgHIAIAAQAEAAACgBQADgDAAgEQAAgEgDgCQgDgCgDAAIgIAAg");
	this.shape_5.setTransform(447.425,-221.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AARAwIgEgOIgaAAIgEAOIghAAIAihfIAhAAIAiBfgAAGAKIgGgYIgHAYIANAAg");
	this.shape_6.setTransform(437.525,-221.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AghAwIAAhfIBCAAIAAAZIgkAAIAAAKIAiAAIAAAYIgiAAIAAALIAlAAIAAAZg");
	this.shape_7.setTransform(428.75,-221.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AgfAwIAAhfIAfAAIAABFIAgAAIAAAag");
	this.shape_8.setTransform(421.275,-221.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AnsCLQhJAAAAg+IAAiZQAAg+BJAAIPZAAQBJAAAAA+IAACZQAAA+hJAAg");
	this.shape_9.setTransform(461.05,-221.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(404.5,-235.4,113.20000000000005,27.700000000000017), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-99.4,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92.5,-288.4,253.6,27);


// stage content:
(lib.jetfam_728x90_us = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(184.8,315,1.12,1.12,0,0,0,62,18.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(290).to({_off:false},0).to({alpha:1},28,cjs.Ease.quartInOut).wait(25));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(166.9,413.9,1.12,1.12,0,0,0,84.2,10.6);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(273).to({_off:false},0).to({alpha:1},27,cjs.Ease.quartInOut).wait(43));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(166.05,299.5,0.448,0.448,0,0,0,177.6,184.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(256).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(58));

	// skate3
	this.instance_3 = new lib.skate3();
	this.instance_3.setTransform(592.95,386.15,1.12,1.12,0,0,0,57,61.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({x:499.95},20,cjs.Ease.quartOut).wait(176).to({x:592.95},18,cjs.Ease.quintInOut).wait(81));

	// skate2
	this.instance_4 = new lib.skate2();
	this.instance_4.setTransform(724.05,406.25,1.12,1.12,0,0,0,57,62);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({_off:false},0).to({x:564.4},20,cjs.Ease.quartOut).wait(179).to({x:727.15},18,cjs.Ease.quintInOut).wait(82));

	// skate1
	this.instance_5 = new lib.skate1();
	this.instance_5.setTransform(583.05,401.85,1.12,1.12,0,0,0,56.1,61.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(40).to({_off:false},0).to({x:350.55},20,cjs.Ease.quartOut).wait(182).to({x:583.05},18,cjs.Ease.quintInOut).wait(83));

	// Ctext1
	this.instance_6 = new lib.Ctext1();
	this.instance_6.setTransform(-382.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(151).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// text2
	this.instance_7 = new lib.Tween2("synched",0);
	this.instance_7.setTransform(-158.95,366.45,1.12,1.12);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(9).to({_off:false},0).to({x:123.25},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_8 = new lib.text1();
	this.instance_8.setTransform(-206.95,282.9,1.12,1.12,0,0,0,74.8,24);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(5).to({_off:false},0).to({x:106.15},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// rip
	this.instance_9 = new lib.rip();
	this.instance_9.setTransform(373.7,45.3,1,1,0,0,0,365.7,46.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(243).to({x:683.7},24,cjs.Ease.quartInOut).to({_off:true},1).wait(75));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("A4/H0IAAvnMAx/AAAIAAPng");
	this.shape.setTransform(363.999,44.9997,2.275,0.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-108.1,44,1158.5,47.099999999999994);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/jetfam_728x90_us_atlas_P_1.png", id:"jetfam_728x90_us_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;