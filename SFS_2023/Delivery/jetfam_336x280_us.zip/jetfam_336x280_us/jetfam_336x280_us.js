(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"jetfam_336x280_us_atlas_P_1", frames: [[0,468,131,130],[133,468,121,121],[256,468,121,121],[0,0,557,466]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset2pngcopy = function() {
	this.initialize(ss["jetfam_336x280_us_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset3 = function() {
	this.initialize(ss["jetfam_336x280_us_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Asset4 = function() {
	this.initialize(ss["jetfam_336x280_us_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Asset6tearBB = function() {
	this.initialize(ss["jetfam_336x280_us_atlas_P_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVAUQgJgHAAgNQAAgMAJgHQAIgHANAAQAOAAAIAHQAJAHAAAMQAAANgJAHQgIAHgOAAQgNAAgIgHg");
	this.shape.setTransform(-0.35,-194.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgbBWIAAhDIg8hoIA+AAIAZA6IAag6IA+AAIg8BoIAABDg");
	this.shape_1.setTransform(-9.725,-200.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag5BWIAAirIA5AAIAAB9IA5AAIAAAug");
	this.shape_2.setTransform(-21.75,-200.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbBWIAAirIA3AAIAACrg");
	this.shape_3.setTransform(-32.825,-200.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAxBWIgChiIgXBiIgvAAIgXhiIgCBiIg3AAIAKirIBIAAIAVBdIAWhdIBJAAIAJCrg");
	this.shape_4.setTransform(-48.075,-200.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAeBWIgHgYIgwAAIgGAYIg7AAIA8irIA9AAIA8CrgAALATIgLguIgNAuIAYAAg");
	this.shape_5.setTransform(-68.125,-200.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag7BWIAAirIB3AAIAAAsIg/AAIAAAbIA8AAIAAArIg8AAIAAA5g");
	this.shape_6.setTransform(-82.35,-200.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.6,-213.9,97.89999999999999,29);


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape.setTransform(93.85,-146.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgxBBQgbgXAAgqQAAgoAbgYQAagYAnAAQAWAAAPAGQALAEAHAFIACABIgPAwIgFgEQgDgCgLgFQgKgEgKAAQgRAAgKAKQgLAKAAATQAAARALALQAKAKARAAQAaAAAQgPIAQAsQgWAWgnAAQgnAAgagYg");
	this.shape_1.setTransform(78.675,-146.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOBWIgbg5IgHAAIAAA5Ig5AAIAAirIBLAAQAfAAASAMQAVAPAAAcQAAAigdARIAnBBgAgVgNIAOAAQAJAAADgDQAHgEgBgIQABgHgHgEQgEgEgIAAIgOAAg");
	this.shape_2.setTransform(63.05,-146.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag7BDQgTgTAAglIAAhiIA5AAIAABkQAAAOAGAFQAGAGAJAAQAKAAAGgGQAGgFAAgOIAAhkIA5AAIAABiQAAAlgTATQgUAVgoAAQgmAAgVgVg");
	this.shape_3.setTransform(44.975,-145.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_4.setTransform(26.125,-146.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhFBBIAZgqQALAJANAFQAOAFAHAAQAMAAAAgHQgBgHgKgCIgYgIQgRgHgIgGQgQgNAAgXQAAgZAVgRQASgOAfAAQAmgBAYAVIgVAoQgKgIgMgEQgLgFgJABQgMgBAAAIQAAAEAKADIAJADIAMADQATAHAKAJQAQAMAAAYQAAAbgWASQgUAPgfAAQgiAAgggYg");
	this.shape_5.setTransform(9,-146.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(0,-159.5,103.1,29), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag9BWIAAirIB5AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape.setTransform(110.1,-191.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAXBWIAAg/IguAAIAAA/Ig4AAIAAirIA4AAIAAA+IAuAAIAAg+IA5AAIAACrg");
	this.shape_1.setTransform(93.35,-191.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_2.setTransform(77.225,-191.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_3.setTransform(58.625,-191.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag9BWIAAirIB5AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape_4.setTransform(44.75,-191.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag9BWIAAirIB5AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBEAAIAAAtg");
	this.shape_5.setTransform(30.25,-191.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAxBWIgChiIgXBiIgvAAIgXhiIgCBiIg3AAIAKirIBIAAIAVBdIAWhdIBJAAIAJCrg");
	this.shape_6.setTransform(11.575,-191.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(-1.6,-205,120.89999999999999,29), null);


(lib.skate3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset4();
	this.instance.setTransform(180,-272,0.605,0.605);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate3, new cjs.Rectangle(180,-272,73.19999999999999,73.19999999999999), null);


(lib.skate2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset3();
	this.instance.setTransform(54,-296,0.605,0.605);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate2, new cjs.Rectangle(54,-296,73.2,73.19999999999999), null);


(lib.skate1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset2pngcopy();
	this.instance.setTransform(173,-302,0.605,0.605);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate1, new cjs.Rectangle(173,-302,79.30000000000001,78.69999999999999), null);


(lib.rip = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset6tearBB();
	this.instance.setTransform(18,0,0.5452,0.5452);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rip, new cjs.Rectangle(18,0,303.7,254.1), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgFAVIAAgfIgJAAIAAgLIAdAAIAAALIgJAAIAAAfg");
	this.shape.setTransform(274.1098,-154.4461,0.6702,0.6702);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPAVIgDgVIgKAVIgDAAIgKgVIgDAVIgMAAIAHgqIAMAAIAHAWIAIgWIAMAAIAHAqg");
	this.shape_1.setTransform(277.0587,-154.4461,0.6702,0.6702);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgnCYIAAiSIhuidIBeAAIA3BTIA4hTIBeAAIhvCdIAACSg");
	this.shape_2.setTransform(260.3705,-145.7166,0.6702,0.6702);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhVCYIAAkvICrAAIAABDIhcAAIAAAzIBXAAIAABCIhXAAIAAA0IBcAAIAABDg");
	this.shape_3.setTransform(243.2298,-145.7166,0.6702,0.6702);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAoCYIhmiEIAACEIhPAAIAAkvIBPAAIAAB9IBfh9IBiAAIh5CQICECfg");
	this.shape_4.setTransform(225.6032,-145.7166,0.6702,0.6702);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhDBzQgwgvAAhEQAAhEAwguQAvgtBAAAQAiAAAmAQIAABeQgcghgogBQgjAAgXAZQgXAXAAAjQAAAkAYAYQAWAYAjAAQAmAAAeghIAABeIgIADQgkAMgdAAQg/AAgvgtg");
	this.shape_5.setTransform(204.9942,-145.7333,0.6702,0.6702);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ah4ByQgvgtAAhFQAAhDAvgtQAwgvBIAAQBJAAAwAvQAvAtAABDQAABFgvAtQgwAuhJAAQhIAAgwgugAg7g6QgaAXAAAjQAAAkAaAYQAYAYAjAAQAjAAAZgYQAZgYAAgkQAAgjgZgXQgZgZgjAAQgjAAgYAZg");
	this.shape_6.setTransform(183.5474,-145.7333,0.6702,0.6702);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AA5CYIAAh9IhxAAIAAB9IhPAAIAAkvIBPAAIAAB1IBxAAIAAh1IBPAAIAAEvg");
	this.shape_7.setTransform(159.8554,-145.7166,0.6702,0.6702);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAcCYIhKh1IAAB1IhPAAIAAkvIB7AAQAvAAAbAcQAZAaAAAoQAABFhDAPIBgB9gAgugPIAOAAQAYAAALgKQANgKAAgRQAAgSgNgKQgLgKgYAAIgOAAg");
	this.shape_8.setTransform(130.9526,-145.7166,0.6702,0.6702);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ah4ByQgvgtAAhFQAAhDAvgtQAwgvBIAAQBJAAAwAvQAvAtAABDQAABFgvAtQgwAuhJAAQhJAAgvgugAg7g6QgZAXgBAjQABAkAZAYQAYAYAjAAQAjAAAZgYQAagYgBgkQABgjgagXQgZgZgjAAQgjAAgYAZg");
	this.shape_9.setTransform(107.8973,-145.7333,0.6702,0.6702);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhWCYIAAkvICtAAIAABDIheAAIAAAzIBVAAIAABCIhVAAIAAB3g");
	this.shape_10.setTransform(88.5952,-145.7166,0.6702,0.6702);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AirEtIAApZIFWAAIAACEIi5AAIAABlICvAAIAACDIivAAIAABpIC5AAIAACEg");
	this.shape_11.setTransform(284.297,-199.4843,0.6702,0.6702);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgcEpQg7gWgvgsQhihYAAiPQAAg9AXg6QAXg5ArgtQAtgvA+gaQA8gaBBAAQBHAABJAeIAAC+QgXgfgmgSQgkgSgqABQhHgBgtAxQgtAxAABGQAABJAtAvQAtAuBKABQAmAAAlgSQAkgSAZgdIAAC+QgxAPgWAFQgjAIgiAAQg/AAg6gYg");
	this.shape_12.setTransform(246.6814,-199.4173,0.6702,0.6702);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AA4EtIiTjnIgCAAIAADnIicAAIAApZIDqAAQBdAAA3AtQA8AvAABdQAABBgiAuQgkAvg+ALIC9D3gAhdgeIAPAAQAwAAAagNQAigSAAgtQAAgrgigTQgagNgwABIgPAAg");
	this.shape_13.setTransform(209.8197,-199.4843,0.6702,0.6702);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhqEmQg6gRgjgjQgogngOg8QgJgnAAhLIAAlRICdAAIAAE8QAABNAPAiQAYA1BCgBQBDABAYg1QAPgjAAhMIAAk8ICdAAIAAFRQAABKgJAoQgOA8gpAnQgjAjg5ARQgxAPg6AAQg5AAgxgPg");
	this.shape_14.setTransform(164.9491,-198.9481,0.6702,0.6702);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AjtDjQhfhdAAiRQABiEBlhaQBhhWCFgBQCFABBiBWQBlBaAACEQAACRhdBdQheBdiRAAQiQAAhdhdgAh3h4QgyAvAABAQAABMAyAzQAxAzBGAAQBHAAAxgzQAyg0AAhLQAAhAgygvQgzgwhFAAQhFAAgyAwg");
	this.shape_15.setTransform(116.7441,-199.4508,0.6702,0.6702);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AiEEwQgzgRgagYIAAiUQAcAhA2AYQAzAXArAAQAoAAAWgOQAVgPAAgZQAAgZgXgRQgXgPg4gVQicg5AAiIQAAhSA5g2QA5g2BfAAQA1AAAsAOQAtAQAaASIAACTQgYgcgsgUQgrgWgmABQgjAAgSAOQgTAPAAAZQAAAYAUAQQATAQA1AUQBOAcAuAuQAuAwAABDQAABXg9A2Qg8A3hrAAQhBAAgxgRg");
	this.shape_16.setTransform(72.0744,-199.4173,0.6702,0.6702);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAyK0QiSAAiCg3QiCg3hghoQhbhhgxh9Qgyh9AAiDQAAkdDLjLQDLjLEdAAQFYADD6DGIAAEQQiEhziNg2QiNg3ijAAQi/AAh/CLQh0CAAACoQAAClB3CCQB/CLC5AAQA5AAAnAmQAmAmAAA6QAAA3grAoQgpAkgyAAg");
	this.shape_17.setTransform(171.8522,-335.6211,0.6702,0.6702);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AmrJUQiUhIh0h5IAAkXQCECOCHBKQC5BnDgAAQC/AAB+iLQB1iAAAioQAAilh3iCQiAiLi4AAQg7AAglgmQgmgmAAg6QAAg4AqgnQAogkA0AAIAMAAQCSgBCCA4QCCA4BhBoQBaBhAyB8QAxB9AACCQAAEejLDLQhgBgh8A1QiAA3iNAAQjogCjDhfg");
	this.shape_18.setTransform(178.5879,-299.2788,0.6702,0.6702);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(58,-382,237.8,247), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfAVIgDgWIgKAWIgFAAIgJgWIgDAWIgLAAIAHgpIALAAIAIAUIAJgUIALAAIAHApgAghAVIAAgfIgJAAIAAgKIAeAAIAAAKIgJAAIAAAfg");
	this.shape.setTransform(140.0505,-201.1704,0.4158,0.4158);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgKAKQgEgEAAgGQAAgFAEgDQAEgEAGAAQAHAAAEAEQAEADAAAFQAAAGgEAEQgEADgHAAQgGAAgEgDg");
	this.shape_1.setTransform(139.425,-195);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAVIgfAAIAAAJIAdAAIAAAUIgdAAIAAAJIAgAAIAAAWg");
	this.shape_2.setTransform(134.075,-197.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAXApIgBguIgKAuIgXAAIgKguIgBAuIgbAAIAFhRIAjAAIAJArIAKgrIAjAAIAFBRg");
	this.shape_3.setTransform(125.175,-197.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOApIgDgMIgWAAIgDAMIgcAAIAchRIAdAAIAcBRgAAFAJIgFgVIgGAVIALAAg");
	this.shape_4.setTransform(115.625,-197.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaAgQgOgMAAgUQAAgUAOgLQAMgLARAAQAOAAALAHQAEADAGAFIgSAPQgHgHgKAAQgGgBgFAGQgFAFAAAJQAAAJAFAGQAFAFAGAAQAIAAADgCIAAgBIAAgGIgMAAIAAgTIAnAAIAAAjIgFAEIgFAEIgHAEQgKADgLABQgRAAgMgLg");
	this.shape_5.setTransform(106.925,-197.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAGApIgMgbIgDAAIAAAbIgbAAIAAhRIAjAAQAPAAAIAGQAKAHAAANQAAAPgNAJIASAfgAgKgGIAHAAQADAAACgBQADgCAAgDQAAgFgDgBQgCgCgDAAIgHAAg");
	this.shape_6.setTransform(96.775,-197.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgbAgQgKgJABgSIAAguIAbAAIAAAvQgBAHADACQADADAEAAQAFAAADgDQACgCAAgHIAAgvIAbAAIAAAuQABASgKAJQgJAKgTAAQgSAAgJgKg");
	this.shape_7.setTransform(88.25,-197.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgfAfQgNgMAAgTQAAgTANgLQAMgMATAAQATAAANAMQAMALAAATQAAATgMAMQgNAMgTAAQgTAAgMgMgAgMgOQgEAGgBAIQABAIAEAGQAFAEAHAAQAIAAAEgEQAGgGAAgIQAAgIgGgGQgEgEgIAAQgHAAgFAEg");
	this.shape_8.setTransform(79.25,-197.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgMApIAAggIgdgxIAeAAIALAcIANgcIAdAAIgdAxIAAAgg");
	this.shape_9.setTransform(71.1,-197.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgMApIAAg8IgUAAIAAgVIBBAAIAAAVIgUAAIAAA8g");
	this.shape_10.setTransform(61.525,-197.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgNApIAAhRIAaAAIAABRg");
	this.shape_11.setTransform(56.35,-197.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbApIAAhRIA3AAIAAAVIgdAAIAAANIAcAAIAAAUIgcAAIAAAbg");
	this.shape_12.setTransform(51.35,-197.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAVIgfAAIAAAJIAdAAIAAAUIgdAAIAAAJIAgAAIAAAWg");
	this.shape_13.setTransform(42.225,-197.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AALApIgLguIgKAuIgcAAIgXhRIAdAAIAKAtIAKgtIAaAAIAKAtIAKgtIAbAAIgWBRg");
	this.shape_14.setTransform(32.65,-197.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(25.2,-204.8,117.89999999999999,14.700000000000017), null);


(lib.Ctext3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVAUQgJgHABgNQgBgMAJgHQAIgHANAAQAOAAAJAHQAHAHAAAMQAAANgHAHQgJAHgOAAQgNAAgIgHg");
	this.shape.setTransform(103.1,-140.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_1.setTransform(94.375,-147.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape_2.setTransform(80.5,-147.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag5BDQgcgYAAgrQAAgrAdgXQAZgWAmAAQAeAAAWANQAJAGALALIglAfQgPgPgUAAQgPAAgKAMQgKALAAATQAAATAKAMQAKAMAPAAQARAAAFgGIABgBIAAgMIgaAAIAAgpIBSAAIAABKIgKAIIgLAIQgIAGgHACQgTAIgaAAQgkAAgagWg");
	this.shape_3.setTransform(63.575,-147.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhQBWIAAirIBBAAQArAAAYASQAdAXAAAsQAAAtgdAWQgYATgrAAgAgYAnIANAAQAQAAAJgJQAKgKAAgUQAAgVgKgJQgJgJgQAAIgNAAg");
	this.shape_4.setTransform(45.875,-147.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag7BDQgTgTAAglIAAhiIA5AAIAABkQAAAOAGAFQAGAGAJAAQAKAAAGgGQAGgFAAgOIAAhkIA5AAIAABiQAAAlgTATQgUAVgoAAQgmAAgVgVg");
	this.shape_5.setTransform(27.475,-146.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhKBWIAAirIBHAAQAdAAAPAGQAKAFAIAJQAHAKAAANQAAAOgHALQgHAKgKAEQAPADAJALQAJALAAAOQAAAagTANQgSALgbAAgAgSAtIASAAQASAAAAgOQAAgHgFgEQgEgDgJAAIgSAAgAgSgTIAMAAQAHAAAFgDQAEgEABgGQgBgGgEgEQgEgCgIAAIgMAAg");
	this.shape_6.setTransform(10.7,-147.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext3, new cjs.Rectangle(0,-160.5,109.7,29), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbBWIAAhDIg8hoIA+AAIAZA6IAag6IA+AAIg8BoIAABDg");
	this.shape.setTransform(73.325,-169.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AANBWIgag5IgIAAIAAA5Ig4AAIAAirIBLAAQAfAAASAMQAVAPAAAcQAAAigcARIAmBBgAgVgNIAPAAQAHAAAEgDQAGgEABgIQgBgHgGgEQgEgEgHAAIgPAAg");
	this.shape_1.setTransform(58.05,-169.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBEAAIAAAtg");
	this.shape_2.setTransform(42,-169.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgaBWIhBirIA7AAIAgBjIAghjIA8AAIhACrg");
	this.shape_3.setTransform(25.5,-169.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape_4.setTransform(9.5,-169.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(0,-182.7,83.8,29), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAOBWIgbg5IgHAAIAAA5Ig5AAIAAirIBLAAQAfAAASAMQAVAPAAAcQAAAigdARIAnBBgAgVgNIAOAAQAJAAADgDQAHgEgBgIQABgHgHgEQgEgEgIAAIgOAAg");
	this.shape.setTransform(84.65,-191.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_1.setTransform(65.725,-191.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag7BWIAAirIB3AAIAAAsIg/AAIAAAbIA8AAIAAArIg8AAIAAA5g");
	this.shape_2.setTransform(49.75,-191.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_3.setTransform(30.775,-191.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgbBWIAAirIA3AAIAACrg");
	this.shape_4.setTransform(19.825,-191.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag7BWIAAirIB3AAIAAAsIg/AAIAAAbIA8AAIAAArIg8AAIAAA5g");
	this.shape_5.setTransform(9.25,-191.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(0,-205,94.3,29), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgfAsIAAhXIA+AAIAAAXIghAAIAAAJIAfAAIAAAWIgfAAIAAAKIAhAAIAAAXg");
	this.shape.setTransform(85.6,-58.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AAGAsIgMgdIgEAAIAAAdIgdAAIAAhXIAnAAQAPAAAIAHQAMAHAAAOQAAARgPAJIATAhgAgKgGIAHAAQADAAACgBQADgDAAgEQAAgDgDgDQgCgBgDAAIgHAAg");
	this.shape_1.setTransform(78.05,-58.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AghAhQgNgMAAgVQAAgUANgMQANgMAUAAQAVAAAOAMQAMAMAAAUQAAAVgMAMQgOAMgVAAQgUAAgNgMgAgMgOQgGAFAAAJQAAAJAGAFQAEAGAIAAQAIAAAGgGQAEgFAAgJQAAgJgEgFQgGgGgIAAQgIAAgEAGg");
	this.shape_2.setTransform(68.45,-58.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AAZAsIgBgxIgMAxIgXAAIgMgxIgBAxIgcAAIAFhXIAlAAIAKAvIALgvIAlAAIAFBXg");
	this.shape_3.setTransform(57.775,-58.675);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AAMAsIgagwIABAPIAAAhIgcAAIAAhXIAfAAIAZAwIgBgPIAAghIAcAAIAABXg");
	this.shape_4.setTransform(44.875,-58.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AAHAsIgOgdIgDAAIAAAdIgdAAIAAhXIAnAAQAPAAAIAHQAMAHAAAOQAAARgPAJIATAhgAgKgGIAHAAQADAAACgBQADgDAAgEQAAgDgDgDQgCgBgDAAIgHAAg");
	this.shape_5.setTransform(36.3,-58.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AAPAsIgDgNIgYAAIgEANIgdAAIAehXIAfAAIAeBXgAAGAKIgGgXIgGAXIAMAAg");
	this.shape_6.setTransform(27.225,-58.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgfAsIAAhXIA9AAIAAAXIggAAIAAAJIAeAAIAAAWIgeAAIAAAKIAhAAIAAAXg");
	this.shape_7.setTransform(19.2,-58.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AgcAsIAAhXIAcAAIAAA/IAdAAIAAAYg");
	this.shape_8.setTransform(12.35,-58.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AmuB/QhAAAAAg5IAAiLQAAg5BAAAINdAAQBAAAAAA5IAACLQAAA5hAAAg");
	this.shape_9.setTransform(48.6,-58.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(-0.9,-71.6,99,25.39999999999999), null);


(lib.Btext22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhQBWIAAirIBBAAQArAAAYASQAdAXAAAsQAAAtgdAWQgYATgrAAgAgYAnIANAAQAQAAAJgJQAKgKAAgUQAAgVgKgJQgJgJgQAAIgNAAg");
	this.shape.setTransform(74.625,-223.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag9BWIAAirIB5AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape_1.setTransform(58.25,-223.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag9BWIAAirIB5AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBEAAIAAAtg");
	this.shape_2.setTransform(43.75,-223.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhGBWIAAirIBKAAQAfAAARAOQATAPAAAeQAAAdgTAQQgRAOgfAAIgSAAIAAA1gAgOgJIAJAAQAJAAAEgDQAGgEAAgKQAAgJgGgEQgEgEgJAAIgJAAg");
	this.shape_3.setTransform(29.025,-223.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhFBBIAZgqQAMAJAMAFQAOAFAHAAQANAAAAgHQgCgHgKgCIgYgIQgRgHgIgGQgQgMAAgYQAAgZAVgRQASgPAfAAQAmAAAYAVIgVAoQgKgIgMgEQgMgEgIgBQgMAAAAAIQAAAEALAEIAJACIALADQATAHAKAIQAQANAAAXQAAAcgWASQgUAPgeAAQgkAAgfgYg");
	this.shape_4.setTransform(13.4,-223.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_5.setTransform(-0.125,-223.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape_6.setTransform(-14,-223.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAxBWIgChiIgXBiIgvAAIgXhiIgCBiIg3AAIAKirIBIAAIAVBdIAWhdIBJAAIAJCrg");
	this.shape_7.setTransform(-47.225,-223.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgxBCQgbgYAAgqQAAgpAbgXQAagYAnAAQAWAAAPAGQALAEAHAEIACACIgPAwIgFgFQgDgCgLgEQgKgEgKAAQgRAAgKAKQgLAKAAATQAAARALALQAKAKARAAQAaAAAQgPIAQAsQgWAWgnAAQgnAAgagXg");
	this.shape_8.setTransform(-66.075,-223.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgxBCQgbgYAAgqQAAgpAbgXQAagYAnAAQAWAAAPAGQALAEAHAEIACACIgPAwIgFgFQgDgCgLgEQgKgEgKAAQgRAAgKAKQgLAKAAATQAAARALALQAKAKARAAQAaAAAQgPIAQAsQgWAWgnAAQgnAAgagXg");
	this.shape_9.setTransform(-81.425,-223.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgcBYQgJgCgDgBIACgqQAIADAGAAQAFAAABgCQADgCAAgHIAAh7IA4AAIAAB7QAAAdgNANQgMAMgXAAIgVgBg");
	this.shape_10.setTransform(-26.275,-223.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.6,-236.7,177.1,29);


(lib.Btext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag9BWIAAirIB5AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBEAAIAAAtg");
	this.shape.setTransform(126.1,-226.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgbBWIhBirIA9AAIAfBjIAhhjIA8AAIhCCrg");
	this.shape_1.setTransform(109.6,-226.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbBWIAAirIA3AAIAACrg");
	this.shape_2.setTransform(96.525,-226.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhFBCIAZgrQAMAJANAFQANAFAHAAQANAAAAgIQgBgFgMgEIgXgIQgRgGgHgGQgQgMgBgYQABgZATgRQATgOAfAAQAmAAAYAUIgWAoQgIgIgNgEQgMgFgHABQgOAAAAAGQAAAGAMACIAJADIALAEQATAGAKAJQAQAMAAAYQAAAbgXASQgTAOgeAAQgkAAgfgWg");
	this.shape_3.setTransform(85.2,-226.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag7BDQgTgTAAglIAAhiIA5AAIAABkQAAAOAGAFQAGAGAJAAQAKAAAGgGQAGgFAAgOIAAhkIA5AAIAABiQAAAlgTATQgUAVgoAAQgmAAgVgVg");
	this.shape_4.setTransform(69.175,-226.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag5BWIAAirIA5AAIAAB9IA5AAIAAAug");
	this.shape_5.setTransform(54.75,-226.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgxBBQgbgXAAgqQAAgpAbgXQAagYAnAAQAWAAAPAGQALADAHAGIACACIgPAvIgFgEQgDgCgLgFQgKgEgKAAQgRAAgKAKQgLALAAASQAAASALAKQAKAKARAAQAaAAAQgQIAQAtQgWAWgnAAQgnAAgagYg");
	this.shape_6.setTransform(40.075,-226.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAbBWIgbg3IgbA3IhDAAIA6hZIg3hSIBDAAIAYAuIAZguIBDAAIg3BSIA6BZg");
	this.shape_7.setTransform(23.9,-226.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape_8.setTransform(7.9,-226.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btext1, new cjs.Rectangle(-1.6,-239.8,136.9,29), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(-1.6,-97.8,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.6,-281.3,103.1,29);


// stage content:
(lib.jetfam_336x280_us = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(180.8,315,1.12,1.12,0,0,0,62,18.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(309).to({_off:false},0).to({alpha:1},22,cjs.Ease.cubicInOut).wait(12));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(-101.85,413.9,1.12,1.12,0,0,0,84.2,10.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(292).to({_off:false},0).to({x:166.9},20,cjs.Ease.quartOut).wait(31));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(166.05,299.5,0.448,0.448,0,0,0,177.6,184.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(268).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(46));

	// skate3
	this.instance_3 = new lib.skate3();
	this.instance_3.setTransform(196,562.8,1.12,1.12,0,0,0,57,61.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({x:109.75},20,cjs.Ease.quartOut).wait(187).to({x:196.55},18,cjs.Ease.quintInOut).wait(70));

	// skate2
	this.instance_4 = new lib.skate2();
	this.instance_4.setTransform(334.3,498.4,1.12,1.12,0,0,0,57,62);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({_off:false},0).to({x:247.5},20,cjs.Ease.quartOut).wait(190).to({x:334.3},18,cjs.Ease.quintInOut).wait(71));

	// skate1
	this.instance_5 = new lib.skate1();
	this.instance_5.setTransform(190.5,412.7,1.12,1.12,0,0,0,56.1,61.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(40).to({_off:false},0).to({x:108.75},20,cjs.Ease.quartOut).wait(193).to({x:202.55},18,cjs.Ease.quintInOut).wait(72));

	// cta
	this.instance_6 = new lib.CTA();
	this.instance_6.setTransform(94.65,320.25,1.12,1.12,0,0,0,62.1,18.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(145).to({y:276.75},23,cjs.Ease.quartInOut).wait(81).to({y:277.85,alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(76));

	// Ctext3
	this.instance_7 = new lib.Ctext3();
	this.instance_7.setTransform(-103.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(157).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(81));

	// Ctet2
	this.instance_8 = new lib.Ctext2();
	this.instance_8.setTransform(-117.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(154).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_9 = new lib.Ctext1();
	this.instance_9.setTransform(-103.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(151).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// Btext2_copy
	this.instance_10 = new lib.text3();
	this.instance_10.setTransform(-179.1,366.45,1.12,1.12);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(19).to({_off:false},0).to({x:123.25},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(192));

	// Btext2
	this.instance_11 = new lib.Btext22();
	this.instance_11.setTransform(-156.25,366.45,1.12,1.12);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(17).to({_off:false},0).to({x:123.25},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(194));

	// Btext1
	this.instance_12 = new lib.Btext1();
	this.instance_12.setTransform(-147.8,372.95,1.12,1.12,0,0,0,74.8,24);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(13).to({_off:false},0).to({x:106.15,y:371.6},22,cjs.Ease.quartOut).wait(93).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(197));

	// text2
	this.instance_13 = new lib.Tween2("synched",0);
	this.instance_13.setTransform(-158.95,366.45,1.12,1.12);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(9).to({_off:false},0).to({x:123.25},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_14 = new lib.text1();
	this.instance_14.setTransform(-206.95,282.9,1.12,1.12,0,0,0,74.8,24);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(5).to({_off:false},0).to({x:106.15},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// rip
	this.instance_15 = new lib.rip();
	this.instance_15.setTransform(177.95,140.25,1.12,1.12,0,0,0,151.9,126.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(258).to({x:339.25},16,cjs.Ease.quartInOut).wait(69));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("EgaPA0gMAAAho/MA0fAAAMAAABo/g");
	this.shape.setTransform(168,336);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-124.5,138.9,653.9,533.1);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 336,
	height: 280,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/jetfam_336x280_us_atlas_P_1.png", id:"jetfam_336x280_us_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;