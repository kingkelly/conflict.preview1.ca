(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"shift_728x90_us_atlas_1", frames: [[0,0,558,1110],[0,1112,510,184]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset1 = function() {
	this.initialize(ss["shift_728x90_us_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset2pngcopy = function() {
	this.initialize(ss["shift_728x90_us_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUATQgHgHAAgMQAAgLAHgGQAIgHAMAAQANAAAHAHQAIAGAAALQAAAMgIAHQgHAGgNAAQgMAAgIgGg");
	this.shape.setTransform(303.325,-146.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAQAJAKQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_1.setTransform(291.175,-152.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgHgFgDQgEgDgHAAIgNAAg");
	this.shape_2.setTransform(275.275,-152.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhBBPIAAidIBEAAQAdAAAPAMQASAOABAcQgBAbgSAOQgPANgdAAIgQAAIAAAxgAgNgIIAJAAQAHAAAFgDQAFgEAAgJQAAgJgFgDQgFgDgHAAIgJAAg");
	this.shape_3.setTransform(260.3,-152.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_4.setTransform(241.825,-152.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag2BPIAAidIBtAAIAAAoIg6AAIAAAZIA3AAIAAAoIg3AAIAAA0g");
	this.shape_5.setTransform(229.525,-152.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgZBPIAAidIAzAAIAACdg");
	this.shape_6.setTransform(219.15,-152.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAWBPIAAg6IgrAAIAAA6Ig0AAIAAidIA0AAIAAA5IArAAIAAg5IA0AAIAACdg");
	this.shape_7.setTransform(206.9,-152.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag/A8IAWgnQALAJAMAEQAMAFAHAAQAMAAgBgHQgBgGgKgDIgWgHQgPgGgHgFQgOgMAAgVQAAgYASgPQAQgOAeAAQAiAAAWAUIgTAkQgJgHgKgEQgMgEgHAAQgMAAAAAHQAAAEAKADIAIACIALAEQARAGAKAHQAPAMgBAWQAAAZgUAQQgSAOgcAAQghAAgcgWg");
	this.shape_8.setTransform(191.75,-152.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAZBPIgZgyIgZAyIg9AAIA0hSIgyhLIA/AAIAVAqIAWgqIA+AAIgyBLIA1BSg");
	this.shape_9.setTransform(172.6,-152.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgHgFgDQgEgDgHAAIgNAAg");
	this.shape_10.setTransform(153.025,-152.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAQAJAKQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_11.setTransform(135.625,-152.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhBBPIAAidIBEAAQAdAAAQAMQARAOAAAcQAAAbgRAOQgQANgdAAIgQAAIAAAxgAgNgIIAJAAQAHAAAFgDQAFgEAAgJQAAgJgFgDQgFgDgHAAIgJAAg");
	this.shape_12.setTransform(119.9,-152.525);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAcBPIgHgWIgsAAIgGAWIg2AAIA3idIA5AAIA3CdgAAKARIgKgpIgMApIAWAAg");
	this.shape_13.setTransform(104.075,-152.525);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgZBPIg7idIA3AAIAdBbIAehbIA3AAIg8Cdg");
	this.shape_14.setTransform(88.7,-152.525);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgHgFgDQgEgDgHAAIgNAAg");
	this.shape_15.setTransform(69.125,-152.525);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_16.setTransform(54.4,-152.525);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag2A+QgRgSAAgiIAAhaIA0AAIAABdQAAALAFAFQAGAHAIgBQAJABAGgHQAFgFAAgLIAAhdIA0AAIAABaQAAAigRASQgSASglAAQgjAAgTgSg");
	this.shape_17.setTransform(39.225,-152.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAcBPIgHgWIgsAAIgGAWIg2AAIA3idIA5AAIA3CdgAAKARIgKgpIgMApIAWAAg");
	this.shape_18.setTransform(22.825,-152.525);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhEBPIAAidIBCAAQAZAAAOAFQAKAFAHAIQAGAKAAAMQAAAMgGAKQgGAJgKAEQAOADAIAKQAJAKAAANQAAAYgSAMQgQAKgaAAgAgQApIAQAAQAQAAAAgNQAAgGgEgEQgEgCgIAAIgQAAgAgQgSIAKAAQAHAAAEgCQAEgEAAgFQAAgGgEgEQgDgCgIAAIgKAAg");
	this.shape_19.setTransform(7.525,-152.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(-2.5,-165,312.1,27), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape.setTransform(211.55,-197.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYBPIg8idIA3AAIAdBbIAehbIA3AAIg8Cdg");
	this.shape_1.setTransform(196.4,-197.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgZBPIAAidIAzAAIAACdg");
	this.shape_2.setTransform(184.4,-197.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag/A8IAWgnQALAJAMAEQANAFAGAAQALAAAAgHQgBgGgKgDIgWgHQgPgGgHgFQgPgMAAgVQABgYASgPQARgOAdAAQAiAAAXAUIgUAkQgJgHgKgEQgMgEgHAAQgMAAAAAHQAAAEAKADIAIACIALAEQASAGAIAHQAPAMAAAWQAAAZgUAQQgSAOgdAAQgfAAgdgWg");
	this.shape_3.setTransform(174,-197.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag2A+QgRgSAAgiIAAhaIA0AAIAABdQAAALAFAGQAGAFAIAAQAJAAAGgFQAFgGAAgLIAAhdIA0AAIAABaQAAAigRASQgSASglAAQgjAAgTgSg");
	this.shape_4.setTransform(159.275,-197.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag0BPIAAidIA0AAIAABzIA1AAIAAAqg");
	this.shape_5.setTransform(145.975,-197.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgtA8QgZgVAAgnQAAglAZgWQAYgWAjAAQAVAAAOAGQAKADAGAFIACABIgNAsIgFgEQgDgCgKgEQgKgEgIAAQgQAAgJAJQgKAKAAARQAAAQAKAJQAJAKAQAAQAXAAAPgPIAPApQgUAVglAAQgjAAgYgWg");
	this.shape_6.setTransform(132.475,-197.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAZBPIgZgyIgYAyIg+AAIA1hSIgzhLIA+AAIAWAqIAWgqIA+AAIgyBLIA1BSg");
	this.shape_7.setTransform(117.65,-197.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApg");
	this.shape_8.setTransform(102.95,-197.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA/AAIAAApg");
	this.shape_9.setTransform(85.2,-197.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgtA8QgZgVAAgnQAAglAZgWQAYgWAjAAQAVAAAOAGQAKADAGAFIACABIgNAsIgFgEQgDgCgKgEQgKgEgIAAQgQAAgJAJQgKAKAAARQAAAQAKAJQAJAKAQAAQAXAAAPgPIAPApQgUAVglAAQgjAAgYgWg");
	this.shape_10.setTransform(71.225,-197.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgHgFgDQgEgDgHAAIgNAAg");
	this.shape_11.setTransform(56.875,-197.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag2A+QgRgSAAgiIAAhaIA0AAIAABdQAAALAFAGQAGAFAIAAQAJAAAGgFQAFgGAAgLIAAhdIA0AAIAABaQAAAigRASQgSASglAAQgjAAgTgSg");
	this.shape_12.setTransform(40.275,-197.75);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAQAJAKQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_13.setTransform(22.925,-197.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhAA8IAYgnQAKAJAMAEQANAFAGAAQAMAAAAgHQgCgGgKgDIgWgHQgPgGgHgFQgPgMABgVQgBgYATgPQARgOAdAAQAiAAAXAUIgVAkQgHgHgMgEQgLgEgHAAQgMAAAAAHQAAAEAKADIAIACIALAEQARAGAJAHQAQAMAAAWQAAAZgWAQQgRAOgdAAQggAAgdgWg");
	this.shape_14.setTransform(7.2,-197.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(-1.2,-210.3,221.39999999999998,27), null);


(lib.skate1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset2pngcopy();
	this.instance.setTransform(163,-299,0.4516,0.4516);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate1, new cjs.Rectangle(163,-299,230.3,83.1), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgFAWIAAggIgJAAIAAgKIAdAAIAAAKIgJAAIAAAgg");
	this.shape.setTransform(155.3319,-362.3244,0.5482,0.5482);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPAWIgDgXIgJAXIgFAAIgJgXIgDAXIgMAAIAHgqIAMAAIAHAUIAJgUIALAAIAHAqg");
	this.shape_1.setTransform(157.7303,-362.3244,0.5482,0.5482);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgkCRIAAiLIhqiWIBaAAIA1BQIA1hQIBaAAIhrCWIAACLg");
	this.shape_2.setTransform(144.4501,-355.5678,0.5482,0.5482);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhRCRIAAkhICkAAIAABAIhZAAIAAAxIBTAAIAAA+IhTAAIAAAyIBZAAIAABAg");
	this.shape_3.setTransform(131.0739,-355.5678,0.5482,0.5482);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAmCRIhhh+IAAB+IhLAAIAAkhIBLAAIAAB4IBah4IBeAAIhzCKIB+CXg");
	this.shape_4.setTransform(117.3141,-355.5678,0.5482,0.5482);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhABuQguguAAhAQAAhBAugsQAtgrA9AAQAhAAAkAPIAABaQgagggnAAQghAAgWAXQgWAWAAAiQAAAiAWAXQAWAXAhAAQAkAAAdgfIAABZIgIADQgiAMgcAAQg8AAgtgrg");
	this.shape_5.setTransform(101.2106,-355.5541,0.5482,0.5482);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhyBtQgtgsAAhBQAAhAAtgsQAtgsBFAAQBGAAAtAsQAtAsAABAQAABBgtAsQgtAshGAAQhFAAgtgsgAg4g4QgZAXAAAhQAAAiAZAYQAXAWAhAAQAhAAAYgWQAZgYAAgiQAAghgZgXQgYgXghAAQghAAgXAXg");
	this.shape_6.setTransform(84.463,-355.5541,0.5482,0.5482);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AA2CRIAAh3IhsAAIAAB3IhKAAIAAkhIBKAAIAABwIBsAAIAAhwIBMAAIAAEhg");
	this.shape_7.setTransform(65.9749,-355.5678,0.5482,0.5482);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAaCRIhGhvIAABvIhMAAIAAkhIB2AAQAtAAAaAbQAXAYABAnQgBBCg+AOIBbB3gAgsgOIAOAAQAWAAALgKQAMgJAAgRQAAgRgMgJQgLgKgWAAIgOAAg");
	this.shape_8.setTransform(43.3889,-355.5678,0.5482,0.5482);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhyBtQgtgsAAhBQAAhAAtgsQAtgsBFAAQBGAAAtAsQAtAsAABAQAABBgtAsQgtAshGAAQhFAAgtgsgAg4g4QgYAXAAAhQAAAiAYAYQAXAWAhAAQAiAAAXgWQAZgYAAgiQAAghgZgXQgXgXgiAAQghAAgXAXg");
	this.shape_9.setTransform(25.3942,-355.5541,0.5482,0.5482);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhSCRIAAkhIClAAIAABAIhaAAIAAAxIBSAAIAAA+IhSAAIAAByg");
	this.shape_10.setTransform(10.3186,-355.5678,0.5482,0.5482);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AigEbIAAo1IFBAAIAAB9IiuAAIAABeIClAAIAAB8IilAAIAABhICuAAIAAB9g");
	this.shape_11.setTransform(160.9647,-396.9297,0.5482,0.5482);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbEYQg3gWgtgoQhchTABiGQgBg6AWg2QAWg3ApgqQAqgrA6gZQA4gZA9AAQBBAABIAdIAACzQgXgfgkgQQghgRgoAAQhDABgqAtQgqAuAABDQAABEArArQAqAsBFAAQAkAAAigQQAjgQAYgdIAACzQgxAPgTAEQghAIgfAAQg8AAg3gWg");
	this.shape_12.setTransform(132.0333,-396.8886,0.5482,0.5482);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AA0EbIiKjaIgBAAIAADaIiTAAIAAo1IDcAAQBXAAA0AqQA4AtAABXQAAA9ggArQghAtg7AKICyDogAhXgcIAOAAQAtAAAYgMQAggRAAgqQAAgpgggRQgYgNgtAAIgOAAg");
	this.shape_13.setTransform(103.6775,-396.9297,0.5482,0.5482);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhkEVQg1gRgiggQglglgOg4QgIgmAAhFIAAk+ICTAAIAAEqQAABIAOAgQAXAxA+AAQA/AAAWgxQAPggAAhIIAAkqICTAAIAAE+QAABFgJAmQgNA4glAlQgiAgg1ARQgvAOg2AAQg2AAgugOg");
	this.shape_14.setTransform(69.1545,-396.5185,0.5482,0.5482);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AjgDWQhYhXAAiIQAAh+BghUQBbhRB9AAQB+AABbBRQBgBUAAB+QAACIhZBXQhYBYiIAAQiIAAhYhYgAhwhxQgvAuAAA6QAABIAvAwQAuAwBCAAQBDAAAugwQAvgwAAhIQAAg6gvguQgwgthBAAQhAAAgwAtg");
	this.shape_15.setTransform(32.0823,-396.916,0.5482,0.5482);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ah8EeQgwgPgYgYIAAiLQAbAgAyAXQAxAVAnAAQAnABAUgOQATgOAAgYQAAgYgVgPQgWgOg1gVQiTg1AAiAQAAhNA2gzQA2gzBZAAQAyAAApAOQApANAaATIAACJQgWgZgpgUQgpgUgkAAQghAAgRAOQgRAOgBAXQAAAYAUAOQARAPAyATQBJAaArAsQArAuABA+QgBBRg4AzQg4A0hmAAQg6AAgxgQg");
	this.shape_16.setTransform(-2.2763,-396.8886,0.5482,0.5482);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAvKLQiJAAh6g0Qh6g0hbhhQhVhbgvh2Qguh1AAh8QAAkMC/i/QC/i/EMAAQFCADDrC6IAAEAQh7hsiFgzQiEg0iaAAQizAAh3CDQhuB5AACdQAACcBwB6QB4CDCtAAQA2AAAkAkQAkAkAAA2QAAA0goAlQgnAigvAAg");
	this.shape_17.setTransform(-80.8749,-394.2983,0.5482,0.5482);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AmRIxQiMhEhthyIAAkGQB9CFB+BGQCvBhDSAAQCzAAB3iDQBuh4AAifQAAibhwh6Qh4iDiuABQg2AAgkgkQgkgjAAg3QAAg2ApgkQAlgiAwAAIAMAAQCJAAB7A0QB6A0BbBjQBVBaAvB2QAuB2AAB5QAAEOi/C+Qi+C/kOAAQjagCi3hYg");
	this.shape_18.setTransform(-75.6943,-366.3537,0.5482,0.5482);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(-114,-430,283.8,99.39999999999998), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfAVIgDgWIgKAWIgFAAIgJgWIgDAWIgLAAIAHgpIALAAIAIAUIAJgUIALAAIAHApgAghAVIAAgfIgJAAIAAgKIAeAAIAAAKIgJAAIAAAfg");
	this.shape.setTransform(375.5264,-323.5014,0.8232,0.8232);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgUATQgIgHAAgMQAAgLAIgHQAIgHAMABQANAAAIAGQAIAIAAAKQAAAMgIAHQgIAHgNgBQgMABgIgHg");
	this.shape_1.setTransform(374.25,-311.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag6BRIAAihIByAAIAAAqIg9AAIAAARIA6AAIAAApIg6AAIAAATIBAAAIAAAqg");
	this.shape_2.setTransform(363.55,-317.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAuBRIgChcIgVBcIgtAAIgVhcIgCBcIg0AAIAJihIBFAAIATBXIAVhXIBEAAIAJChg");
	this.shape_3.setTransform(345.925,-317.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAdBRIgHgXIgtAAIgGAXIg4AAIA4ihIA7AAIA4ChgAALASIgLgrIgMArIAXAAg");
	this.shape_4.setTransform(327.05,-317.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag1BAQgbgXAAgpQAAgoAbgWQAYgVAkAAQAcAAAVANQAIAFALALIgjAdQgOgOgTAAQgOAAgJAKQgKALAAASQAAATAKAKQAJALAOAAQAQAAAFgEIABgCIAAgMIgZAAIAAgmIBNAAIAABGIgJAIIgLAIQgHAEgHADQgSAHgYAAQgiAAgYgUg");
	this.shape_5.setTransform(309.825,-317.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AANBRIgZg2IgHAAIAAA2Ig2AAIAAihIBHAAQAeAAAQALQAUAOAAAaQAAAggbAQIAlA+gAgTgMIANAAQAHAAAEgDQAGgEAAgHQAAgHgGgEQgEgDgHAAIgNAAg");
	this.shape_6.setTransform(289.725,-317.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag3A/QgSgRAAgkIAAhcIA1AAIAABfQAAAMAGAGQAGAFAIAAQAJAAAGgFQAGgGAAgMIAAhfIA1AAIAABcQAAAkgRARQgTAUgmgBQgkABgTgUg");
	this.shape_7.setTransform(272.775,-317.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag/A+QgZgXABgnQgBgmAZgXQAZgWAmAAQAnAAAYAWQAZAXAAAmQAAAngZAXQgYAWgnAAQgmAAgZgWgAgYgbQgKAKAAARQAAAQAKAKQAJALAPgBQAPABAKgLQAKgKgBgQQABgRgKgKQgKgLgPAAQgPAAgJALg");
	this.shape_8.setTransform(255.05,-317.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgaBRIAAg/Ig4hiIA6AAIAYA3IAYg3IA7AAIg4BiIAAA/g");
	this.shape_9.setTransform(238.9,-317.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgaBRIAAh4IgmAAIAAgpICBAAIAAApIgmAAIAAB4g");
	this.shape_10.setTransform(220,-317.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgaBRIAAihIA1AAIAAChg");
	this.shape_11.setTransform(209.725,-317.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag4BRIAAihIBxAAIAAAqIg7AAIAAAZIA3AAIAAApIg3AAIAAA1g");
	this.shape_12.setTransform(199.775,-317.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag6BRIAAihIByAAIAAAqIg9AAIAAARIA6AAIAAApIg6AAIAAATIBAAAIAAAqg");
	this.shape_13.setTransform(181.75,-317.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAWBRIgWhbIgVBbIg2AAIguihIA3AAIAVBZIAUhZIA0AAIATBZIAUhZIA4AAIguChg");
	this.shape_14.setTransform(162.75,-317.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(148.1,-330.7,233.29999999999998,29.099999999999966), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUATQgHgHAAgMQAAgLAHgGQAIgHAMAAQANAAAHAHQAIAGAAALQAAAMgIAHQgHAGgNAAQgMAAgIgGg");
	this.shape.setTransform(204.325,-172.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhAA8IAYgnQAKAJAMAEQAMAFAHAAQAMAAAAgHQgCgGgKgDIgWgHQgPgGgHgFQgOgMAAgVQAAgYASgPQAQgOAeAAQAiAAAWAUIgTAkQgJgHgKgEQgMgEgHAAQgMAAAAAHQAAAEAKADIAIACIALAEQASAGAJAHQAOAMAAAWQABAZgVAQQgSAOgcAAQghAAgdgWg");
	this.shape_1.setTransform(193.65,-177.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAWBPIgvhXIAAAcIAAA7IgyAAIAAidIA5AAIAtBXIgBgcIAAg7IAyAAIAACdg");
	this.shape_2.setTransform(178.5,-177.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgHgFgDQgEgDgHAAIgNAAg");
	this.shape_3.setTransform(162.925,-177.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag2A+QgRgSAAgiIAAhaIA0AAIAABdQAAALAFAFQAGAHAIgBQAJABAGgHQAFgFAAgLIAAhdIA0AAIAABaQAAAigRASQgSASglAAQgjAAgTgSg");
	this.shape_4.setTransform(146.325,-177.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgZBPIAAh1IglAAIAAgoIB9AAIAAAoIglAAIAAB1g");
	this.shape_5.setTransform(131.725,-177.725);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA4AAIAAAoIg4AAIAAASIA/AAIAAApg");
	this.shape_6.setTransform(114.55,-177.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgZBPIg7idIA3AAIAdBbIAehbIA3AAIg8Cdg");
	this.shape_7.setTransform(99.4,-177.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgZBPIAAidIAzAAIAACdg");
	this.shape_8.setTransform(87.4,-177.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag/A8IAWgnQALAJAMAEQAMAFAHAAQAMAAgBgHQgBgGgKgDIgWgHQgPgGgHgFQgOgMAAgVQAAgYASgPQAQgOAeAAQAiAAAWAUIgTAkQgIgHgLgEQgMgEgHAAQgMAAAAAHQAAAEAKADIAIACIALAEQARAGAKAHQAPAMgBAWQAAAZgUAQQgSAOgcAAQghAAgcgWg");
	this.shape_9.setTransform(77,-177.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAQAJAKQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_10.setTransform(61.475,-177.725);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag0BPIAAidIA0AAIAABzIA1AAIAAAqg");
	this.shape_11.setTransform(47.825,-177.725);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhBBPIAAidIBEAAQAdAAAQAMQARAOABAcQgBAbgRAOQgQANgdAAIgQAAIAAAxgAgNgIIAJAAQAHAAAEgDQAGgEAAgJQAAgJgGgDQgEgDgHAAIgJAAg");
	this.shape_12.setTransform(34.75,-177.725);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAZBPIgZgyIgYAyIg+AAIA1hSIgzhLIA/AAIAVAqIAWgqIA+AAIgyBLIA1BSg");
	this.shape_13.setTransform(18.8,-177.725);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_14.setTransform(4.1,-177.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(-4.8,-190.2,215.4,27), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgHgFgDQgEgDgHAAIgNAAg");
	this.shape.setTransform(184.475,-197.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag9A8QgYgWAAgmQAAglAYgWQAYgWAlAAQAmAAAYAWQAYAWAAAlQAAAmgYAWQgYAWgmAAQglAAgYgWgAgYgbQgJAKAAARQAAAQAJAKQAKAKAOAAQAPAAAKgKQAJgKAAgQQAAgRgJgKQgKgKgPAAQgOAAgKAKg");
	this.shape_1.setTransform(167.075,-197.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag2BPIAAidIBtAAIAAAoIg6AAIAAAZIA3AAIAAAoIg3AAIAAA0g");
	this.shape_2.setTransform(152.375,-197.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhKBPIAAidIA8AAQAoAAAWARQAbAUAAApQAAAqgbAUQgWARgoAAgAgWAkIAMAAQAPAAAIgJQAJgJAAgSQAAgTgJgJQgIgIgPAAIgMAAg");
	this.shape_3.setTransform(133.325,-197.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_4.setTransform(118.3,-197.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAMBPIgYg1IgHAAIAAA1Ig0AAIAAidIBFAAQAdAAAQALQAUAOAAAZQAAAfgbAQIAkA8gAgTgMIANAAQAHAAAEgDQAFgEAAgHQAAgHgFgDQgEgDgHAAIgNAAg");
	this.shape_5.setTransform(104.575,-197.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_6.setTransform(89.85,-197.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag4BPIAAidIBvAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_7.setTransform(76.55,-197.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAWBPIgvhXIABAcIAAA7IgzAAIAAidIA5AAIAtBXIgBgcIAAg7IAyAAIAACdg");
	this.shape_8.setTransform(60.95,-197.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgZBPIAAidIAzAAIAACdg");
	this.shape_9.setTransform(48.5,-197.975);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag0A+QgagWAAgoQAAgnAbgWQAXgUAiAAQAcAAAUAMQAIAFALALIgiAdQgOgOgTAAQgNAAgJAKQgJALAAARQAAASAJALQAJAKANAAQARAAAEgEIABgCIAAgLIgYAAIAAgmIBLAAIAABFIgJAHIgKAIQgIAFgGACQgSAHgXAAQgiAAgXgUg");
	this.shape_10.setTransform(36.075,-197.975);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAWBPIgwhXIABAcIAAA7IgyAAIAAidIA5AAIAsBXIAAgcIAAg7IAyAAIAACdg");
	this.shape_11.setTransform(19.05,-197.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag5BPIAAidIBwAAIAAAoIg8AAIAAASIA5AAIAAAoIg5AAIAAASIA+AAIAAApg");
	this.shape_12.setTransform(3.9,-197.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(-5,-210.4,198.5,27), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AghAwIAAhfIBCAAIAAAZIgkAAIAAAKIAiAAIAAAYIgiAAIAAALIAlAAIAAAZg");
	this.shape.setTransform(501.3,-221.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AAHAwIgOggIgEAAIAAAgIgfAAIAAhfIApAAQARAAAKAHQAMAIAAAQQAAASgQAJIAVAlgAgLgHIAIAAQAEAAACgBQADgDAAgEQAAgEgDgCQgDgCgDAAIgIAAg");
	this.shape_1.setTransform(493.075,-221.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AgkAkQgPgNAAgXQAAgWAPgNQAOgNAWAAQAXAAAOANQAPANAAAWQAAAXgPANQgOANgXAAQgWAAgOgNgAgOgQQgGAGAAAKQAAAJAGAHQAGAGAIAAQAJAAAGgGQAFgHAAgJQAAgKgFgGQgGgGgJAAQgIAAgGAGg");
	this.shape_2.setTransform(482.575,-221.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AAbAwIgBg2IgMA2IgaAAIgNg2IgBA2IgfAAIAFhfIApAAIALAzIAMgzIAoAAIAGBfg");
	this.shape_3.setTransform(470.95,-221.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AANAwIgcg1IABARIAAAkIgfAAIAAhfIAiAAIAbA0IgBgQIAAgkIAfAAIAABfg");
	this.shape_4.setTransform(456.825,-221.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AAHAwIgOggIgEAAIAAAgIgfAAIAAhfIApAAQARAAAKAHQAMAIAAAQQAAASgQAJIAVAlgAgLgHIAIAAQAEAAACgBQADgDAAgEQAAgEgDgCQgDgCgDAAIgIAAg");
	this.shape_5.setTransform(447.425,-221.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AARAwIgEgOIgaAAIgEAOIghAAIAihfIAhAAIAiBfgAAGAKIgGgYIgHAYIANAAg");
	this.shape_6.setTransform(437.525,-221.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AghAwIAAhfIBCAAIAAAZIgkAAIAAAKIAiAAIAAAYIgiAAIAAALIAlAAIAAAZg");
	this.shape_7.setTransform(428.75,-221.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AgfAwIAAhfIAfAAIAABFIAgAAIAAAag");
	this.shape_8.setTransform(421.275,-221.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AnsCLQhJAAAAg+IAAiZQAAg+BJAAIPZAAQBJAAAAA+IAACZQAAA+hJAAg");
	this.shape_9.setTransform(461.05,-221.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(404.5,-235.4,113.20000000000005,27.700000000000017), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-98.6,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92.5,-287.6,312.1,27);


// stage content:
(lib.shift_728x90_us = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(184.8,315,1.12,1.12,0,0,0,62,18.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(290).to({_off:false},0).to({alpha:1},28,cjs.Ease.quartInOut).wait(25));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(166.9,413.9,1.12,1.12,0,0,0,84.2,10.6);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(273).to({_off:false},0).to({alpha:1},27,cjs.Ease.quartInOut).wait(43));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(166.05,299.5,0.448,0.448,0,0,0,177.6,184.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(256).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(58));

	// skate1
	this.instance_3 = new lib.skate1();
	this.instance_3.setTransform(613.05,401.85,1.12,1.12,0,0,0,56.1,61.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(23).to({_off:false},0).to({x:350.55},25,cjs.Ease.quartOut).wait(195).to({x:620.55},18,cjs.Ease.quintInOut).wait(82));

	// Ctet2
	this.instance_4 = new lib.Ctext2();
	this.instance_4.setTransform(-167.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(154).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_5 = new lib.Ctext1();
	this.instance_5.setTransform(-132.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(151).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// text2
	this.instance_6 = new lib.Tween2("synched",0);
	this.instance_6.setTransform(-158.95,366.45,1.12,1.12);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(9).to({_off:false},0).to({x:123.25},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_7 = new lib.text1();
	this.instance_7.setTransform(-206.95,282.9,1.12,1.12,0,0,0,74.8,24);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(5).to({_off:false},0).to({x:106.15},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// bg
	this.instance_8 = new lib.Asset1();
	this.instance_8.setTransform(728,0,0.6198,0.6558,90);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(71.9,43.1,926.3000000000001,302.79999999999995);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/shift_728x90_us_atlas_1.jpg", id:"shift_728x90_us_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;