(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"jetfam_300x250_en_atlas_P_1", frames: [[0,468,131,130],[133,468,121,121],[256,468,121,121],[0,0,557,466]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset2pngcopy = function() {
	this.initialize(ss["jetfam_300x250_en_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset3 = function() {
	this.initialize(ss["jetfam_300x250_en_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Asset4 = function() {
	this.initialize(ss["jetfam_300x250_en_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Asset6tearBB = function() {
	this.initialize(ss["jetfam_300x250_en_atlas_P_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVAUQgIgHgBgNQABgMAIgHQAIgHANAAQAOAAAJAHQAHAHABAMQgBANgHAHQgJAHgOAAQgNAAgIgHg");
	this.shape.setTransform(1.25,-194.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgbBWIAAhDIg8hoIA+AAIAZA6IAag6IA+AAIg8BoIAABDg");
	this.shape_1.setTransform(-8.125,-200.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag5BWIAAirIA4AAIAAB9IA6AAIAAAug");
	this.shape_2.setTransform(-20.15,-200.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbBWIAAirIA3AAIAACrg");
	this.shape_3.setTransform(-31.225,-200.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAxBWIgChiIgXBiIgvAAIgXhiIgCBiIg3AAIAKirIBIAAIAVBdIAWhdIBJAAIAJCrg");
	this.shape_4.setTransform(-46.475,-200.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAeBWIgHgYIgwAAIgGAYIg7AAIA8irIA9AAIA8CrgAALATIgLguIgNAuIAYAAg");
	this.shape_5.setTransform(-66.525,-200.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag7BWIAAirIB3AAIAAAsIg/AAIAAAbIA8AAIAAArIg8AAIAAA5g");
	this.shape_6.setTransform(-80.75,-200.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-213.9,97.9,29);


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape.setTransform(93.85,-146.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgxBBQgbgXAAgqQAAgoAbgYQAagYAnAAQAWAAAPAGQALAEAHAFIACABIgPAwIgFgEQgDgCgLgFQgKgEgKAAQgRAAgKAKQgLAKAAATQAAARALALQAKAKARAAQAaAAAQgPIAQAsQgWAWgnAAQgnAAgagYg");
	this.shape_1.setTransform(78.675,-146.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOBWIgbg5IgHAAIAAA5Ig5AAIAAirIBLAAQAfAAASAMQAVAPAAAcQAAAigdARIAnBBgAgVgNIAOAAQAJAAADgDQAHgEgBgIQABgHgHgEQgEgEgIAAIgOAAg");
	this.shape_2.setTransform(63.05,-146.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag7BDQgTgTAAglIAAhiIA5AAIAABkQAAAOAGAFQAGAGAJAAQAKAAAGgGQAGgFAAgOIAAhkIA5AAIAABiQAAAlgTATQgUAVgoAAQgmAAgVgVg");
	this.shape_3.setTransform(44.975,-145.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_4.setTransform(26.125,-146.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhFBBIAZgqQALAJANAFQAOAFAHAAQAMAAAAgHQgBgHgKgCIgYgIQgRgHgIgGQgQgNAAgXQAAgZAVgRQASgOAfAAQAmgBAYAVIgVAoQgKgIgMgEQgLgFgJABQgMgBAAAIQAAAEAKADIAJADIAMADQATAHAKAJQAQAMAAAYQAAAbgWASQgUAPgfAAQgiAAgggYg");
	this.shape_5.setTransform(9,-146.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(0,-159.5,103.1,29), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag9BWIAAirIB5AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBEAAIAAAtg");
	this.shape.setTransform(111.7,-191.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAXBWIAAg/IgtAAIAAA/Ig5AAIAAirIA5AAIAAA+IAtAAIAAg+IA5AAIAACrg");
	this.shape_1.setTransform(94.95,-191.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_2.setTransform(78.825,-191.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_3.setTransform(60.225,-191.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag9BWIAAirIB5AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape_4.setTransform(46.35,-191.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape_5.setTransform(31.85,-191.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAxBWIgChiIgXBiIgvAAIgXhiIgCBiIg3AAIAKirIBIAAIAVBdIAWhdIBJAAIAJCrg");
	this.shape_6.setTransform(13.175,-191.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(0,-205,120.9,29), null);


(lib.skate3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset4();
	this.instance.setTransform(180,-272,0.605,0.605);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate3, new cjs.Rectangle(180,-272,73.19999999999999,73.19999999999999), null);


(lib.skate2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset3();
	this.instance.setTransform(54,-296,0.605,0.605);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate2, new cjs.Rectangle(54,-296,73.2,73.19999999999999), null);


(lib.skate1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset2pngcopy();
	this.instance.setTransform(173,-302,0.605,0.605);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate1, new cjs.Rectangle(173,-302,79.30000000000001,78.69999999999999), null);


(lib.rip = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset6tearBB();
	this.instance.setTransform(20,0,0.5452,0.5452);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rip, new cjs.Rectangle(20,0,303.7,254.1), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfAVIgDgWIgKAWIgFAAIgJgWIgDAWIgLAAIAHgpIALAAIAIAUIAJgUIALAAIAHApgAghAVIAAgfIgJAAIAAgKIAeAAIAAAKIgJAAIAAAfg");
	this.shape.setTransform(283.8009,-144.2388,0.7,0.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiqEtIAApZIFVAAIAACEIi5AAIAABlICwAAIAACDIiwAAIAABpIC5AAIAACEg");
	this.shape_1.setTransform(289.5758,-191.5061,0.7,0.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgcEpQg7gWgwgrQhhhaAAiNQAAg+AXg6QAXg5ArgtQAtgvA+gaQA8gaBAAAQBIAABJAeIAAC+QgYgfglgSQglgSgpABQhHgBgtAxQgtAxAABGQAABJAtAvQAtAuBKABQAmAAAlgSQAkgRAZgeIAAC+QgxAPgWAFQgjAIgiAAQg/AAg6gYg");
	this.shape_2.setTransform(250.306,-191.4361,0.7,0.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AA3EtIiSjnIgCAAIAADnIicAAIAApZIDqAAQBdAAA3AtQA8AvAABdQAABBgiAuQgkAvg+ALIC9D3gAhdgeIAPAAQAwAAAagNQAigSAAgsQAAgsgigTQgagNgwAAIgPAAg");
	this.shape_3.setTransform(211.8062,-191.5061,0.7,0.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhqEmQg5gRgjgjQgpgngNg8QgKgoAAhKIAAlRICdAAIAAE8QAABMAPAjQAYA1BCgBQBDABAYg1QAPgiAAhNIAAk8ICdAAIAAFRQAABLgJAnQgOA8goAnQgjAjg5ARQgyAPg6AAQg5AAgxgPg");
	this.shape_4.setTransform(164.9064,-190.9461,0.7,0.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AjuDjQhehcAAiRQAAiFBmhaQBhhWCFgBQCGABBhBWQBmBaAACFQAACRheBcQheBdiRAAQiQAAhehdgAh3h4QgyAvAABAQAABLAyA1QAxAyBGAAQBHAAAxgyQAyg1AAhLQAAhAgygvQgzgwhFAAQhEAAgzAwg");
	this.shape_5.setTransform(114.5766,-191.4711,0.7,0.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AiEEwQgzgRgagYIAAiUQAeAjA0AWQA1AYAqAAQAnAAAWgPQAWgPAAgZQAAgagYgPQgWgPg5gWQicg5AAiIQAAhSA5g2QA6g2BeAAQA2AAArAOQAsAPAbATIAACTQgYgdgrgTQgrgVgnAAQgjAAgSAOQgTAQAAAYQAAAXAUARQAVARAzATQBPAdAtAtQAuAwAABDQAABXg8A2Qg9A3hrAAQg/AAgzgRg");
	this.shape_6.setTransform(67.9218,-191.4361,0.7,0.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ah3ByQgugvgBhIQAAhCA0gtQAwgrBCAAQBDAAAxArQAyAtAABCQAABIguAvQgvAuhJAAQhHAAgwgugAg7g8QgZAYAAAgQAAAlAZAaQAYAaAjAAQAkAAAYgaQAZgaAAglQAAgggZgYQgZgYgjAAQgiAAgZAYg");
	this.shape_7.setTransform(207.5537,-135.2789,0.7,0.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgmCYIAAjsIhBAAIAAhDIDPAAIAABDIhAAAIAADsg");
	this.shape_8.setTransform(251.811,-135.3139,0.7,0.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAcCYIhKh1IAAB1IhPAAIAAkvIB7AAQAYAAATAIQASAHANANQAMAMAHASQAGARAAATQAAAjgRAVQgRAVggAHIBfB9gAgugPIAPAAQAXAAALgKQANgJAAgSQAAgTgNgJQgKgKgYAAIgPAAg");
	this.shape_9.setTransform(232.8761,-135.3139,0.7,0.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhyCYIAAkvIB8AAQA0AAAbAbQAbAbAAAwQAAAwgbAaQgbAag0AAIgtAAIAABlgAgjgLIAaAAQAqAAAAgmQAAgmgqAAIgaAAg");
	this.shape_10.setTransform(182.9838,-135.3139,0.7,0.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAcCYIhKh1IAAB1IhPAAIAAkvIB7AAQAYAAATAIQATAHAMANQAMAMAHASQAGARAAATQAAAjgRAVQgQAVghAHIBfB9gAgugPIAPAAQAXAAAMgKQAMgKAAgSQAAgRgMgKQgMgKgXAAIgPAAg");
	this.shape_11.setTransform(129.4865,-135.2439,0.7,0.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhWCYIAAkvICtAAIAABDIheAAIAAAzIBVAAIAABCIhVAAIAAB3g");
	this.shape_12.setTransform(81.6067,-135.3139,0.7,0.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhBCXQgagHgNgNIAAhKQAPARAaAMQAaALAVAAQATABALgIQALgHAAgNQAAgMgLgIQgNgIgagKQhOgdAAhEQAAgoAcgbQAdgbAuAAQAcAAAVAHQAXAIAMAJIAABJQgLgOgWgKQgWgLgTABQgQgBgKAIQgJAHAAANQAAAMAKAIQAKAIAZAKQAnAOAXAWQAXAYAAAhQAAAsgeAaQgeAcg2AAQgfAAgZgJg");
	this.shape_13.setTransform(271.9359,-135.2964,0.7,0.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhBCXQgagHgNgNIAAhKQAOAQAbANQAbALAUAAQATABALgIQALgHAAgNQAAgMgMgIQgKgIgcgKQhOgdAAhEQAAgoAcgbQAcgbAvAAQAcAAAVAHQAXAIAMAJIAABJQgLgOgWgKQgWgLgTABQgQgBgKAIQgJAHAAANQAAAMAKAIQAKAIAZAKQAnAOAXAWQAXAYAAAhQAAAsgeAaQgfAcg1AAQgfAAgZgJg");
	this.shape_14.setTransform(162.1064,-135.2964,0.7,0.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ah2ByQgvgvAAhHQAAhDAygtQAxgrBCAAQBDAAAxArQAyAtAABDQAABHgvAvQguAuhJAAQhIAAgugugAg7g7QgZAYAAAfQAAAlAZAaQAYAZAjABQAjgBAZgZQAZgZAAgmQAAgfgZgYQgZgZgjAAQgiAAgZAZg");
	this.shape_15.setTransform(104.1816,-135.2264,0.7,0.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAxK0QiRAAiCg3QiBg3hihoQhahhgxh9Qgyh9AAiDQABkdDLjLQDLjLEcAAQFYADD6DGIAAEQQiDhyiOg3QiNg3ijAAQi/AAh/CLQh0CAgBCoQAAClB4CCQCACLC4AAQA5AAAmAmQAnAnAAA5QAAA3grAoQgoAkgzAAg");
	this.shape_16.setTransform(172.1339,-333.693,0.7,0.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AmrJUQiUhIh0h5IAAkXQCECOCHBKQC5BnDgAAQC+AAB/iLQB1iAAAioQAAilh3iCQiAiLi5AAQg6AAgmgmQgmgmAAg6QAAg4ArgnQAogkAzAAIANAAQCSgBCCA4QCCA4BhBoQBaBgAyB9QAxB+AACBQAAEejLDLQhgBgh8A1QiBA3iMAAQjogCjDhfg");
	this.shape_17.setTransform(179.1863,-295.7357,0.7,0.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(53.2,-382.1,248.40000000000003,258.1), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfAVIgDgWIgKAWIgFAAIgJgWIgDAWIgLAAIAHgpIALAAIAIAUIAJgUIALAAIAHApgAghAVIAAgfIgJAAIAAgKIAeAAIAAAKIgJAAIAAAfg");
	this.shape.setTransform(140.0505,-201.1704,0.4158,0.4158);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgKAKQgEgEAAgGQAAgFAEgDQAEgEAGAAQAHAAAEAEQAEADAAAFQAAAGgEAEQgEADgHAAQgGAAgEgDg");
	this.shape_1.setTransform(139.425,-195);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAVIgfAAIAAAJIAdAAIAAAUIgdAAIAAAJIAgAAIAAAWg");
	this.shape_2.setTransform(134.075,-197.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAXApIgBguIgKAuIgXAAIgKguIgBAuIgbAAIAFhRIAjAAIAJArIAKgrIAjAAIAFBRg");
	this.shape_3.setTransform(125.175,-197.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOApIgDgMIgWAAIgDAMIgcAAIAchRIAdAAIAcBRgAAFAJIgFgVIgGAVIALAAg");
	this.shape_4.setTransform(115.625,-197.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaAgQgOgMAAgUQAAgUAOgLQAMgLARAAQAOAAALAHQAEADAGAFIgSAPQgHgHgKAAQgGgBgFAGQgFAFAAAJQAAAJAFAGQAFAFAGAAQAIAAADgCIAAgBIAAgGIgMAAIAAgTIAnAAIAAAjIgFAEIgFAEIgHAEQgKADgLABQgRAAgMgLg");
	this.shape_5.setTransform(106.925,-197.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAGApIgMgbIgDAAIAAAbIgbAAIAAhRIAjAAQAPAAAIAGQAKAHAAANQAAAPgNAJIASAfgAgKgGIAHAAQADAAACgBQADgCAAgDQAAgFgDgBQgCgCgDAAIgHAAg");
	this.shape_6.setTransform(96.775,-197.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgbAgQgKgJABgSIAAguIAbAAIAAAvQgBAHADACQADADAEAAQAFAAADgDQACgCAAgHIAAgvIAbAAIAAAuQABASgKAJQgJAKgTAAQgSAAgJgKg");
	this.shape_7.setTransform(88.25,-197.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgfAfQgNgMAAgTQAAgTANgLQAMgMATAAQATAAANAMQAMALAAATQAAATgMAMQgNAMgTAAQgTAAgMgMgAgMgOQgEAGgBAIQABAIAEAGQAFAEAHAAQAIAAAEgEQAGgGAAgIQAAgIgGgGQgEgEgIAAQgHAAgFAEg");
	this.shape_8.setTransform(79.25,-197.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgMApIAAggIgdgxIAeAAIALAcIANgcIAdAAIgdAxIAAAgg");
	this.shape_9.setTransform(71.1,-197.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgMApIAAg8IgUAAIAAgVIBBAAIAAAVIgUAAIAAA8g");
	this.shape_10.setTransform(61.525,-197.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgNApIAAhRIAaAAIAABRg");
	this.shape_11.setTransform(56.35,-197.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbApIAAhRIA3AAIAAAVIgdAAIAAANIAcAAIAAAUIgcAAIAAAbg");
	this.shape_12.setTransform(51.35,-197.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAVIgfAAIAAAJIAdAAIAAAUIgdAAIAAAJIAgAAIAAAWg");
	this.shape_13.setTransform(42.225,-197.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AALApIgLguIgKAuIgcAAIgXhRIAdAAIAKAtIAKgtIAaAAIAKAtIAKgtIAbAAIgWBRg");
	this.shape_14.setTransform(32.65,-197.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(25.2,-204.8,117.89999999999999,14.700000000000017), null);


(lib.Ctext3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVAUQgJgHABgNQgBgMAJgHQAIgHANAAQAOAAAJAHQAHAHAAAMQAAANgHAHQgJAHgOAAQgNAAgIgHg");
	this.shape.setTransform(103.1,-140.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_1.setTransform(94.375,-147.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape_2.setTransform(80.5,-147.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag5BDQgcgYAAgrQAAgrAdgXQAZgWAmAAQAeAAAWANQAJAGALALIglAfQgPgPgUAAQgPAAgKAMQgKALAAATQAAATAKAMQAKAMAPAAQARAAAFgGIABgBIAAgMIgaAAIAAgpIBSAAIAABKIgKAIIgLAIQgIAGgHACQgTAIgaAAQgkAAgagWg");
	this.shape_3.setTransform(63.575,-147.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhQBWIAAirIBBAAQArAAAYASQAdAXAAAsQAAAtgdAWQgYATgrAAgAgYAnIANAAQAQAAAJgJQAKgKAAgUQAAgVgKgJQgJgJgQAAIgNAAg");
	this.shape_4.setTransform(45.875,-147.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag7BDQgTgTAAglIAAhiIA5AAIAABkQAAAOAGAFQAGAGAJAAQAKAAAGgGQAGgFAAgOIAAhkIA5AAIAABiQAAAlgTATQgUAVgoAAQgmAAgVgVg");
	this.shape_5.setTransform(27.475,-146.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhKBWIAAirIBHAAQAdAAAPAGQAKAFAIAJQAHAKAAANQAAAOgHALQgHAKgKAEQAPADAJALQAJALAAAOQAAAagTANQgSALgbAAgAgSAtIASAAQASAAAAgOQAAgHgFgEQgEgDgJAAIgSAAgAgSgTIAMAAQAHAAAFgDQAEgEABgGQgBgGgEgEQgEgCgIAAIgMAAg");
	this.shape_6.setTransform(10.7,-147.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext3, new cjs.Rectangle(0,-160.5,109.7,29), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbBWIAAhDIg8hoIA+AAIAZA6IAag6IA+AAIg8BoIAABDg");
	this.shape.setTransform(73.325,-169.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AANBWIgag5IgIAAIAAA5Ig4AAIAAirIBLAAQAfAAASAMQAVAPAAAcQAAAigcARIAmBBgAgVgNIAPAAQAHAAAEgDQAGgEABgIQgBgHgGgEQgEgEgHAAIgPAAg");
	this.shape_1.setTransform(58.05,-169.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBEAAIAAAtg");
	this.shape_2.setTransform(42,-169.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgaBWIhBirIA7AAIAgBjIAghjIA8AAIhACrg");
	this.shape_3.setTransform(25.5,-169.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape_4.setTransform(9.5,-169.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(0,-182.7,83.8,29), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAOBWIgbg5IgHAAIAAA5Ig5AAIAAirIBLAAQAfAAASAMQAVAPAAAcQAAAigdARIAnBBgAgVgNIAOAAQAJAAADgDQAHgEgBgIQABgHgHgEQgEgEgIAAIgOAAg");
	this.shape.setTransform(84.65,-191.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_1.setTransform(65.725,-191.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag7BWIAAirIB3AAIAAAsIg/AAIAAAbIA8AAIAAArIg8AAIAAA5g");
	this.shape_2.setTransform(49.75,-191.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_3.setTransform(30.775,-191.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgbBWIAAirIA3AAIAACrg");
	this.shape_4.setTransform(19.825,-191.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag7BWIAAirIB3AAIAAAsIg/AAIAAAbIA8AAIAAArIg8AAIAAA5g");
	this.shape_5.setTransform(9.25,-191.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(0,-205,94.3,29), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AALAsIgLgxIgLAxIgdAAIgYhXIAdAAIALAwIALgwIAbAAIALAwIAKgwIAeAAIgYBXg");
	this.shape.setTransform(73.05,-58.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AghAhQgOgMAAgVQAAgUAOgMQANgMAUAAQAVAAAOAMQANAMgBAUQABAVgNAMQgOAMgVAAQgUAAgNgMgAgNgOQgEAFAAAJQAAAJAEAFQAGAGAHAAQAJAAAEgGQAGgFAAgJQAAgJgGgFQgEgGgJAAQgHAAgGAGg");
	this.shape_1.setTransform(61.85,-58.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AAMAsIgagwIABAPIAAAhIgcAAIAAhXIAfAAIAZAwIgBgPIAAghIAcAAIAABXg");
	this.shape_2.setTransform(52.075,-58.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AgjAsIAAhXIAlAAQAPAAAJAHQAKAIAAAPQAAAPgKAIQgJAHgPAAIgJAAIAAAbgAgHgEIAFAAQAEAAACgCQADgCAAgFQAAgEgDgDQgCgBgEAAIgFAAg");
	this.shape_3.setTransform(41.1,-58.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AghAhQgOgMAAgVQAAgUAOgMQANgMAUAAQAVAAANAMQAOAMAAAUQAAAVgOAMQgNAMgVAAQgUAAgNgMgAgMgOQgFAFgBAJQABAJAFAFQAEAGAIAAQAJAAAFgGQAEgFAAgJQAAgJgEgFQgFgGgJAAQgIAAgEAGg");
	this.shape_4.setTransform(31.85,-58.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AAMAsIAAghIgXAAIAAAhIgdAAIAAhXIAdAAIAAAgIAXAAIAAggIAcAAIAABXg");
	this.shape_5.setTransform(22.15,-58.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AgiAhIAMgVQAGAEAHADQAHADADgBQAGAAAAgDQgBgEgFgBIgMgEQgJgEgDgDQgIgGAAgLQAAgNAKgIQAJgIAQAAQASAAANALIgLAUQgEgEgHgCQgFgCgFgBQgGABAAADQAAACAFACIAFABIAFACQALAEAFADQAHAHABALQAAAOgMAKQgKAHgPAAQgRAAgQgMg");
	this.shape_6.setTransform(13.8,-58.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Al7B/Qg5AAAAg5IAAiMQAAg4A5AAIL3AAQA5AAAAA4IAACMQAAA5g5AAg");
	this.shape_7.setTransform(45.025,-59.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(1.4,-71.7,87.3,25.400000000000006), null);


(lib.Btext22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhQBWIAAirIBBAAQArAAAYASQAdAXAAAsQAAAtgdAWQgYATgrAAgAgYAnIANAAQAQAAAJgJQAKgKAAgUQAAgVgKgJQgJgJgQAAIgNAAg");
	this.shape.setTransform(76.225,-223.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag9BWIAAirIB5AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape_1.setTransform(59.85,-223.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape_2.setTransform(45.35,-223.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhGBWIAAirIBKAAQAfAAARAOQATAPAAAeQAAAdgTAQQgRAOgfAAIgSAAIAAA1gAgOgJIAJAAQAJAAAEgDQAGgEAAgKQAAgJgGgEQgEgEgJAAIgJAAg");
	this.shape_3.setTransform(30.625,-223.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhFBBIAZgqQAMAJANAFQANAFAHAAQANAAAAgHQgBgHgMgCIgXgIQgRgHgHgGQgQgMgBgYQABgZATgRQATgPAgAAQAlAAAYAVIgWAoQgIgIgNgEQgMgEgHgBQgOAAAAAIQAAAEAMAEIAJACIALADQATAHAKAIQAQANAAAXQAAAcgXASQgTAPgeAAQgkAAgfgYg");
	this.shape_4.setTransform(15,-223.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_5.setTransform(1.475,-223.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag9BWIAAirIB5AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape_6.setTransform(-12.4,-223.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAxBWIgChiIgXBiIgvAAIgXhiIgCBiIg3AAIAKirIBIAAIAVBdIAWhdIBJAAIAJCrg");
	this.shape_7.setTransform(-45.625,-223.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgxBCQgbgYAAgqQAAgpAbgXQAagYAnAAQAWAAAPAGQALAEAHAEIACACIgPAwIgFgFQgDgCgLgEQgKgEgKAAQgRAAgKAKQgLAKAAATQAAARALALQAKAKARAAQAaAAAQgPIAQAsQgWAWgnAAQgnAAgagXg");
	this.shape_8.setTransform(-64.475,-223.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgxBCQgbgYAAgqQAAgpAbgXQAagYAnAAQAWAAAPAGQALAEAHAEIACACIgPAwIgFgFQgDgCgLgEQgKgEgKAAQgRAAgKAKQgLAKAAATQAAARALALQAKAKARAAQAaAAAQgPIAQAsQgWAWgnAAQgnAAgagXg");
	this.shape_9.setTransform(-79.825,-223.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgcBYQgJgCgDgBIACgqQAIADAGAAQAFAAABgCQADgCAAgHIAAh7IA4AAIAAB7QAAAdgNANQgMAMgXAAIgVgBg");
	this.shape_10.setTransform(-24.675,-223.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-236.7,177.1,29);


(lib.Btext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape.setTransform(126.7,-226.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgaBWIhBirIA7AAIAgBjIAhhjIA7AAIhBCrg");
	this.shape_1.setTransform(110.2,-226.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbBWIAAirIA3AAIAACrg");
	this.shape_2.setTransform(97.125,-226.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhFBCIAZgrQAMAJANAFQANAFAHAAQAMAAAAgIQAAgFgMgEIgYgIQgQgGgHgGQgRgMABgYQAAgZATgRQATgOAgAAQAkAAAZAUIgWAoQgJgIgLgEQgNgFgHABQgNAAgBAGQAAAGALACIAJADIAMAEQATAGAKAJQAQAMAAAYQAAAbgXASQgSAOggAAQgiAAgggWg");
	this.shape_3.setTransform(85.8,-226.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag7BDQgTgTAAglIAAhiIA5AAIAABkQAAAOAGAFQAGAGAJAAQAKAAAGgGQAGgFAAgOIAAhkIA5AAIAABiQAAAlgTATQgUAVgoAAQgmAAgVgVg");
	this.shape_4.setTransform(69.775,-226.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag5BWIAAirIA4AAIAAB9IA7AAIAAAug");
	this.shape_5.setTransform(55.35,-226.425);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgxBBQgbgXAAgqQAAgpAbgXQAagYAnAAQAWAAAPAGQALADAHAGIACACIgPAvIgFgEQgDgCgLgFQgKgEgKAAQgRAAgKAKQgLALAAASQAAASALAKQAKAKARAAQAaAAAQgQIAQAtQgWAWgnAAQgnAAgagYg");
	this.shape_6.setTransform(40.675,-226.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAcBWIgcg3IgaA3IhEAAIA6hZIg3hSIBDAAIAYAuIAYguIBEAAIg2BSIA5BZg");
	this.shape_7.setTransform(24.5,-226.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape_8.setTransform(8.5,-226.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btext1, new cjs.Rectangle(-1,-239.8,136.9,29), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-97.8,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-281.3,103.1,29);


// stage content:
(lib.jetfam_300x250_en = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(165,281.2,1,1,0,0,0,62,18);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(309).to({_off:false},0).to({alpha:1},22,cjs.Ease.cubicInOut).wait(12));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(-90.95,369.5,1,1,0,0,0,84.2,10.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(292).to({_off:false},0).to({x:149.05},20,cjs.Ease.quartOut).wait(31));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(148.25,267.4,0.4,0.4,0,0,0,177.5,184.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(268).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(46));

	// skate3
	this.instance_3 = new lib.skate3();
	this.instance_3.setTransform(175,502.5,1,1,0,0,0,57,61.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({x:98},20,cjs.Ease.quartOut).wait(187).to({x:175.5},18,cjs.Ease.quintInOut).wait(70));

	// skate2
	this.instance_4 = new lib.skate2();
	this.instance_4.setTransform(298.5,445,1,1,0,0,0,57,62);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({_off:false},0).to({x:221},20,cjs.Ease.quartOut).wait(190).to({x:298.5},18,cjs.Ease.quintInOut).wait(71));

	// skate1
	this.instance_5 = new lib.skate1();
	this.instance_5.setTransform(170,368.5,1,1,0,0,0,56,61.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(40).to({_off:false},0).to({x:97},20,cjs.Ease.quartOut).wait(193).to({x:180.75},18,cjs.Ease.quintInOut).wait(72));

	// cta
	this.instance_6 = new lib.CTA();
	this.instance_6.setTransform(84.45,285.9,1,1,0,0,0,62,18);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(145).to({y:244.9},23,cjs.Ease.quartInOut).wait(81).to({y:245.9,alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(76));

	// Ctext3
	this.instance_7 = new lib.Ctext3();
	this.instance_7.setTransform(-92.7,252.6,1,1,0,0,0,74.8,24);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(157).to({_off:false},0).to({x:94.8},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(81));

	// Ctet2
	this.instance_8 = new lib.Ctext2();
	this.instance_8.setTransform(-105.2,252.6,1,1,0,0,0,74.8,24);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(154).to({_off:false},0).to({x:94.8},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_9 = new lib.Ctext1();
	this.instance_9.setTransform(-92.7,252.6,1,1,0,0,0,74.8,24);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(151).to({_off:false},0).to({x:94.8},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// Btext2_copy
	this.instance_10 = new lib.text3();
	this.instance_10.setTransform(-159.95,327.2);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(19).to({_off:false},0).to({x:110.05},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(192));

	// Btext2
	this.instance_11 = new lib.Btext22();
	this.instance_11.setTransform(-139.55,327.2);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(17).to({_off:false},0).to({x:110.05},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(194));

	// Btext1
	this.instance_12 = new lib.Btext1();
	this.instance_12.setTransform(-132,333,1,1,0,0,0,74.8,24);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(13).to({_off:false},0).to({x:94.8,y:331.8},22,cjs.Ease.quartOut).wait(93).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(197));

	// text2
	this.instance_13 = new lib.Tween2("synched",0);
	this.instance_13.setTransform(-141.95,327.2);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(9).to({_off:false},0).to({x:110.05},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_14 = new lib.text1();
	this.instance_14.setTransform(-184.8,252.6,1,1,0,0,0,74.8,24);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(5).to({_off:false},0).to({x:94.8},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// rip
	this.instance_15 = new lib.rip();
	this.instance_15.setTransform(158.8,125.2,1,1,0,0,0,151.8,126.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(258).to({x:302.8},16,cjs.Ease.quartInOut).wait(69));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-109.6,124,584.3,476);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/jetfam_300x250_en_atlas_P_1.png", id:"jetfam_300x250_en_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;