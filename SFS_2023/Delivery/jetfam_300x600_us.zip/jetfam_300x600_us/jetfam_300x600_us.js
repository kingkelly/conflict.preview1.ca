(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"jetfam_300x600_us_atlas_P_1", frames: [[0,0,557,1114],[0,1116,131,130],[133,1116,121,121],[256,1116,121,121]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset1tearDBL = function() {
	this.initialize(ss["jetfam_300x600_us_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Asset2pngcopy = function() {
	this.initialize(ss["jetfam_300x600_us_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Asset3 = function() {
	this.initialize(ss["jetfam_300x600_us_atlas_P_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Asset4 = function() {
	this.initialize(ss["jetfam_300x600_us_atlas_P_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgeAcQgMgKAAgSQAAgRAMgKQAMgKASAAQAUAAALAKQAMALAAAQQAAASgMAKQgLAKgUAAQgSAAgMgKg");
	this.shape.setTransform(37,-148.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgnB5IAAhfIhTiSIBXAAIAjBSIAkhSIBXAAIhUCSIAABfg");
	this.shape_1.setTransform(23.85,-157.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhQB5IAAjxIBPAAIAACwIBRAAIAABBg");
	this.shape_2.setTransform(7,-157.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgmB5IAAjxIBNAAIAADxg");
	this.shape_3.setTransform(-8.5,-157.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABEB5IgDiKIgfCKIhDAAIgfiKIgECKIhNAAIAOjxIBlAAIAeCDIAfiDIBmAAIANDxg");
	this.shape_4.setTransform(-29.85,-157.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAqB5IgKgiIhDAAIgJAiIhTAAIBUjxIBXAAIBUDxgAAQAaIgRhAIgSBAIAjAAg");
	this.shape_5.setTransform(-57.925,-157.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhTB5IAAjxICnAAIAAA+IhYAAIAAAmIBTAAIAAA9IhTAAIAABQg");
	this.shape_6.setTransform(-77.85,-157.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-175.2,135.4,39);


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhWB5IAAjxICqAAIAAA+IhcAAIAAAbIBWAAIAAA9IhWAAIAAAcIBfAAIAAA/g");
	this.shape.setTransform(130.6,-130.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhFBcQglghAAg7QAAg5AlghQAkgiA3AAQAgAAAUAIQAPAGALAHIADACIgVBDIgIgGQgDgDgQgGQgPgGgNAAQgZAAgOAOQgPAOAAAbQAAAYAQAPQAOAOAYAAQAkAAAWgWIAWA/QgeAfg3AAQg3AAgkghg");
	this.shape_1.setTransform(109.35,-130.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AATB5IgmhRIgKAAIAABRIhPAAIAAjxIBpAAQAsAAAZASQAdAVAAAmQAAAwgoAYIA2BcgAgegSIAUAAQAMAAAFgEQAJgHAAgKQAAgLgJgGQgGgEgLAAIgUAAg");
	this.shape_2.setTransform(87.475,-130.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhTBeQgagaAAg0IAAiKIBPAAIAACNQAAASAIAIQAJAJANAAQAOAAAJgJQAIgHAAgTIAAiNIBPAAIAACKQAAA0gaAaQgcAdg4AAQg2AAgdgdg");
	this.shape_3.setTransform(62.175,-130.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhdBbQglghAAg6QAAg5AlghQAkgiA5AAQA6AAAlAiQAkAhAAA5QAAA6gkAhQglAig6AAQg5AAgkgigAglgpQgOAPAAAZQAAAZAOAQQAPAPAWgBQAXABAOgPQAOgQAAgZQAAgZgOgPQgOgQgXAAQgXAAgOAQg");
	this.shape_4.setTransform(35.775,-130.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhhBcIAjg8QAQANASAHQATAHALAAQARAAAAgLQgCgIgPgEIgigLQgXgKgLgIQgVgSAAghQAAgjAcgXQAYgVAuAAQA0AAAhAdIgeA4QgMgLgRgGQgQgGgMAAQgSAAgBAJQABAHAPAFIANAEIAQAEQAbAJAOAMQAWASAAAhQAAAnggAYQgbAVgrAAQgxAAgsggg");
	this.shape_5.setTransform(11.8,-130.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(0,-148.7,142.6,38.999999999999986), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhWB5IAAjxICqAAIAAA+IhcAAIAAAbIBWAAIAAA9IhWAAIAAAcIBfAAIAAA/g");
	this.shape.setTransform(155.6,-187.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAhB5IAAhZIhBAAIAABZIhPAAIAAjxIBPAAIAABYIBBAAIAAhYIBPAAIAADxg");
	this.shape_1.setTransform(132.15,-187.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgnB5IAAizIg4AAIAAg+IDAAAIAAA+Ig5AAIAACzg");
	this.shape_2.setTransform(109.6,-187.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgnB5IAAizIg5AAIAAg+IDBAAIAAA+Ig6AAIAACzg");
	this.shape_3.setTransform(83.55,-187.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhXB5IAAjxICrAAIAAA+IhcAAIAAAbIBWAAIAAA9IhWAAIAAAcIBfAAIAAA/g");
	this.shape_4.setTransform(64.1,-187.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhXB5IAAjxICrAAIAAA+IhcAAIAAAbIBXAAIAAA9IhXAAIAAAcIBgAAIAAA/g");
	this.shape_5.setTransform(43.8,-187.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ABEB5IgCiKIggCKIhDAAIggiKIgCCKIhOAAIAOjxIBlAAIAeCDIAfiDIBlAAIAODxg");
	this.shape_6.setTransform(17.65,-187.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(0,-205,167.6,39), null);


(lib.tear = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset1tearDBL();
	this.instance.setTransform(0,60,0.5441,0.5441);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tear, new cjs.Rectangle(0,60,303.1,606.2), null);


(lib.skate3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset4();
	this.instance.setTransform(-6,17,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate3, new cjs.Rectangle(-6,17,133.1,133.1), null);


(lib.skate2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset3();
	this.instance.setTransform(-22,1,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate2, new cjs.Rectangle(-22,1,133.1,133.1), null);


(lib.skate1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset2pngcopy();
	this.instance.setTransform(-24,18);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.skate1, new cjs.Rectangle(-24,18,131,130), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgFAVIAAgfIgJAAIAAgLIAdAAIAAALIgJAAIAAAfg");
	this.shape.setTransform(322.45,339.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPAVIgDgVIgKAVIgDAAIgKgVIgDAVIgMAAIAHgqIAMAAIAHAWIAIgWIAMAAIAHAqg");
	this.shape_1.setTransform(326.85,339.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgnCYIAAiSIhuidIBeAAIA3BTIA4hTIBeAAIhvCdIAACSg");
	this.shape_2.setTransform(301.95,352.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhVCYIAAkvICrAAIAABDIhcAAIAAAzIBXAAIAABCIhXAAIAAA0IBcAAIAABDg");
	this.shape_3.setTransform(276.375,352.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAoCYIhmiEIAACEIhPAAIAAkvIBPAAIAAB9IBfh9IBiAAIh5CQICECfg");
	this.shape_4.setTransform(250.075,352.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhDBzQgwgvAAhEQAAhEAwguQAvgtBAAAQAiAAAmAQIAABeQgcghgogBQgjAAgXAZQgXAXAAAjQAAAkAYAYQAWAYAjAAQAmAAAeghIAABeIgIADQgkAMgdAAQg/AAgvgtg");
	this.shape_5.setTransform(219.325,352.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ah4ByQgvgtAAhFQAAhDAvgtQAwgvBIAAQBJAAAwAvQAvAtAABDQAABFgvAtQgwAuhJAAQhIAAgwgugAg7g6QgaAXAAAjQAAAkAaAYQAYAYAjAAQAjAAAZgYQAZgYAAgkQAAgjgZgXQgZgZgjAAQgjAAgYAZg");
	this.shape_6.setTransform(187.325,352.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AA5CYIAAh9IhxAAIAAB9IhPAAIAAkvIBPAAIAAB1IBxAAIAAh1IBPAAIAAEvg");
	this.shape_7.setTransform(151.975,352.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAcCYIhKh1IAAB1IhPAAIAAkvIB7AAQAvAAAbAcQAZAaAAAoQAABFhDAPIBgB9gAgugPIAOAAQAYAAALgKQANgKAAgRQAAgSgNgKQgLgKgYAAIgOAAg");
	this.shape_8.setTransform(108.85,352.825);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ah4ByQgvgtAAhFQAAhDAvgtQAwgvBIAAQBJAAAwAvQAvAtAABDQAABFgvAtQgwAuhJAAQhJAAgvgugAg7g6QgZAXgBAjQABAkAZAYQAYAYAjAAQAjAAAZgYQAagYgBgkQABgjgagXQgZgZgjAAQgjAAgYAZg");
	this.shape_9.setTransform(74.45,352.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhWCYIAAkvICtAAIAABDIheAAIAAAzIBVAAIAABCIhVAAIAAB3g");
	this.shape_10.setTransform(45.65,352.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AirEtIAApZIFWAAIAACEIi5AAIAABlICvAAIAACDIivAAIAABpIC5AAIAACEg");
	this.shape_11.setTransform(337.65,272.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgcEpQg7gWgvgsQhihYAAiPQAAg9AXg6QAXg5ArgtQAtgvA+gaQA8gaBBAAQBHAABJAeIAAC+QgXgfgmgSQgkgSgqABQhHgBgtAxQgtAxAABGQAABJAtAvQAtAuBKABQAmAAAlgSQAkgSAZgdIAAC+QgxAPgWAFQgjAIgiAAQg/AAg6gYg");
	this.shape_12.setTransform(281.525,272.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AA4EtIiTjnIgCAAIAADnIicAAIAApZIDqAAQBdAAA3AtQA8AvAABdQAABBgiAuQgkAvg+ALIC9D3gAhdgeIAPAAQAwAAAagNQAigSAAgtQAAgrgigTQgagNgwABIgPAAg");
	this.shape_13.setTransform(226.525,272.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhqEmQg6gRgjgjQgogngOg8QgJgnAAhLIAAlRICdAAIAAE8QAABNAPAiQAYA1BCgBQBDABAYg1QAPgjAAhMIAAk8ICdAAIAAFRQAABKgJAoQgOA8gpAnQgjAjg5ARQgxAPg6AAQg5AAgxgPg");
	this.shape_14.setTransform(159.575,273.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AjtDjQhfhdAAiRQABiEBlhaQBhhWCFgBQCFABBiBWQBlBaAACEQAACRhdBdQheBdiRAAQiQAAhdhdgAh3h4QgyAvAABAQAABMAyAzQAxAzBGAAQBHAAAxgzQAyg0AAhLQAAhAgygvQgzgwhFAAQhFAAgyAwg");
	this.shape_15.setTransform(87.65,272.65);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AiEEwQgzgRgagYIAAiUQAcAhA2AYQAzAXArAAQAoAAAWgOQAVgPAAgZQAAgZgXgRQgXgPg4gVQicg5AAiIQAAhSA5g2QA5g2BfAAQA1AAAsAOQAtAQAaASIAACTQgYgcgsgUQgrgWgmABQgjAAgSAOQgTAPAAAZQAAAYAUAQQATAQA1AUQBOAcAuAuQAuAwAABDQAABXg9A2Qg8A3hrAAQhBAAgxgRg");
	this.shape_16.setTransform(21,272.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAyK0QiSAAiCg3QiCg3hghoQhbhhgxh9Qgyh9AAiDQAAkdDLjLQDLjLEdAAQFYADD6DGIAAEQQiEhziNg2QiNg3ijAAQi/AAh/CLQh0CAAACoQAAClB3CCQB/CLC5AAQA5AAAnAmQAmAmAAA6QAAA3grAoQgpAkgyAAg");
	this.shape_17.setTransform(169.875,69.475);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AmrJUQiUhIh0h5IAAkXQCECOCHBKQC5BnDgAAQC/AAB+iLQB1iAAAioQAAilh3iCQiAiLi4AAQg7AAglgmQgmgmAAg6QAAg4AqgnQAogkA0AAIAMAAQCSgBCCA4QCCA4BhBoQBaBhAyB8QAxB9AACCQAAEejLDLQhgBgh8A1QiAA3iNAAQjogCjDhfg");
	this.shape_18.setTransform(179.925,123.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(0,0.3,354.8,368.5), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfAVIgDgWIgKAWIgFAAIgJgWIgDAWIgLAAIAHgpIALAAIAIAUIAJgUIALAAIAHApgAghAVIAAgfIgJAAIAAgKIAeAAIAAAKIgJAAIAAAfg");
	this.shape.setTransform(163.953,5.2228,0.594,0.594);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOAOQgGgFAAgJQAAgIAGgFQAFgEAJgBQAJABAGAEQAGAFAAAIQAAAJgGAFQgGAEgJABQgJgBgFgEg");
	this.shape_1.setTransform(163.225,13.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgpA7IAAh1IBSAAIAAAfIgsAAIAAAMIApAAIAAAeIgpAAIAAANIAuAAIAAAfg");
	this.shape_2.setTransform(155.5,9.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAiA7IgChCIgQBCIggAAIgPhCIgBBCIgmAAIAHh1IAxAAIAOA/IAPg/IAxAAIAHB1g");
	this.shape_3.setTransform(142.8,9.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAUA7IgEgRIghAAIgEARIgoAAIAph1IApAAIApB1gAAIANIgIgfIgIAfIAQAAg");
	this.shape_4.setTransform(129.2,9.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgmAuQgTgRAAgdQAAgdATgQQARgPAaAAQAUAAAPAJQAGAEAIAIIgaAVQgKgKgNAAQgKAAgHAHQgHAIAAANQAAANAHAIQAHAIAKAAQALAAAEgDIABgBIAAgJIgSAAIAAgcIA3AAIAAAzIgGAGIgIAFIgKAGQgNAEgRABQgZAAgRgPg");
	this.shape_5.setTransform(116.775,9.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAJA7IgRgnIgGAAIAAAnIgmAAIAAh1IAzAAQAVAAAMAJQAPAKAAATQAAAXgUALIAaAtgAgOgIIAKAAQAFAAACgCQAEgDAAgFQAAgGgEgCQgCgDgFAAIgKAAg");
	this.shape_6.setTransform(102.25,9.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgoAuQgMgNAAgZIAAhDIAmAAIAABEQAAAJAEAEQAFAEAFAAQAHAAAEgEQAEgEAAgJIAAhEIAmAAIAABDQAAAZgMANQgOAOgbAAQgaAAgOgOg");
	this.shape_7.setTransform(90,9.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgtAtQgSgRAAgcQAAgbASgQQASgQAbgBQAcABASAQQASAQAAAbQAAAcgSARQgSAQgcAAQgbAAgSgQgAgRgTQgHAHAAAMQAAAMAHAHQAHAIAKAAQALAAAHgIQAHgHAAgMQAAgMgHgHQgHgIgLAAQgLAAgGAIg");
	this.shape_8.setTransform(77.225,9.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgSA7IAAguIgphHIArAAIAQAoIASgoIAqAAIgpBHIAAAug");
	this.shape_9.setTransform(65.55,9.725);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgSA7IAAhXIgcAAIAAgeIBdAAIAAAeIgcAAIAABXg");
	this.shape_10.setTransform(51.925,9.725);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgSA7IAAh1IAlAAIAAB1g");
	this.shape_11.setTransform(44.525,9.725);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgoA7IAAh1IBRAAIAAAfIgrAAIAAASIAoAAIAAAdIgoAAIAAAng");
	this.shape_12.setTransform(37.325,9.725);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgqA7IAAh1IBTAAIAAAfIgsAAIAAAMIApAAIAAAeIgpAAIAAANIAuAAIAAAfg");
	this.shape_13.setTransform(24.35,9.725);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAQA7IgQhCIgPBCIgnAAIghh1IAoAAIAOBBIAPhBIAlAAIAPBBIAOhBIAoAAIghB1g");
	this.shape_14.setTransform(10.625,9.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(0,0,168.4,21), null);


(lib.Ctext3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgeAcQgMgKAAgSQAAgRAMgKQALgKATAAQAUAAALAKQAMALAAAQQAAASgMAKQgLAKgUAAQgTAAgLgKg");
	this.shape.setTransform(143.55,-115.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgnB5IAAizIg5AAIAAg+IDBAAIAAA+Ig6AAIAACzg");
	this.shape_1.setTransform(131.35,-124.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhXB5IAAjxICrAAIAAA+IhcAAIAAAbIBXAAIAAA9IhXAAIAAAcIBgAAIAAA/g");
	this.shape_2.setTransform(111.9,-124.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhPBeQgogiAAg8QAAg8AogiQAkgdA1AAQApAAAgASQAMAHAQAQIg1AsQgVgVgbAAQgVAAgOAQQgOAQAAAbQAAAcAOAPQAOARAVgBQAYABAGgIIACgCIAAgRIgkAAIAAg5IByAAIAABoIgOAMIgPALQgLAIgLADQgaALgkgBQg0AAgigeg");
	this.shape_3.setTransform(88.2,-124.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhxB5IAAjxIBbAAQA9AAAiAaQApAfAAA/QAABAgpAeQgiAbg9AAgAgiA2IASAAQAYAAAMgMQAOgOAAgcQAAgegOgNQgMgMgYAAIgSAAg");
	this.shape_4.setTransform(63.425,-124.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhTBeQgagaAAg0IAAiKIBPAAIAACNQAAASAIAIQAJAJANAAQAOAAAJgJQAIgHAAgTIAAiNIBPAAIAACKQAAA0gaAaQgcAdg4AAQg2AAgdgdg");
	this.shape_5.setTransform(37.675,-124.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhnB5IAAjxIBjAAQAnAAAWAJQAPAGAJANQALAPAAASQAAATgKAPQgKAOgNAGQAUAFANAPQANAPAAAVQAAAkgbASQgYAQgnAAgAgZA+IAZAAQAZAAAAgTQAAgKgHgFQgHgEgLAAIgZAAgAgZgcIAQAAQALAAAFgEQAIgEAAgJQAAgJgIgFQgEgEgMAAIgQAAg");
	this.shape_6.setTransform(14.2,-124.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext3, new cjs.Rectangle(0,-142.5,151.9,39), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgnB5IAAhfIhUiSIBYAAIAjBSIAkhSIBYAAIhVCSIAABfg");
	this.shape.setTransform(101.85,-155.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AATB5IgmhRIgKAAIAABRIhPAAIAAjxIBpAAQAsAAAZASQAdAVAAAmQAAAwgoAYIA2BcgAgegSIAUAAQAMAAAFgEQAJgHAAgKQAAgLgJgGQgGgEgLAAIgUAAg");
	this.shape_1.setTransform(80.475,-155.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhXB5IAAjxICrAAIAAA+IhcAAIAAAbIBXAAIAAA9IhXAAIAAAcIBgAAIAAA/g");
	this.shape_2.setTransform(58,-155.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgmB5IhajxIBTAAIAtCLIAtiLIBVAAIhbDxg");
	this.shape_3.setTransform(34.9,-155.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhWB5IAAjxICqAAIAAA+IhcAAIAAAbIBWAAIAAA9IhWAAIAAAcIBfAAIAAA/g");
	this.shape_4.setTransform(12.5,-155.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(0,-173.7,115.7,39), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AATB5IgmhRIgKAAIAABRIhPAAIAAjxIBpAAQAsAAAZASQAdAVAAAmQAAAwgoAYIA2BcgAgegSIAUAAQAMAAAFgEQAJgHAAgKQAAgLgJgGQgGgEgLAAIgUAAg");
	this.shape.setTransform(117.725,-187.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhdBbQglghAAg6QAAg5AlghQAkgiA5AAQA6AAAlAiQAkAhAAA5QAAA6gkAhQglAig6AAQg5AAgkgigAglgpQgOAPAAAZQAAAZAOAQQAPAPAWgBQAXABAOgPQAOgQAAgZQAAgZgOgPQgOgQgXAAQgXAAgOAQg");
	this.shape_1.setTransform(91.225,-187.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhTB5IAAjxICnAAIAAA+IhYAAIAAAmIBTAAIAAA9IhTAAIAABQg");
	this.shape_2.setTransform(68.85,-187.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgnB5IAAizIg4AAIAAg+IC/AAIAAA+Ig4AAIAACzg");
	this.shape_3.setTransform(42.3,-187.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgmB5IAAjxIBNAAIAADxg");
	this.shape_4.setTransform(26.95,-187.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhTB5IAAjxICnAAIAAA+IhYAAIAAAmIBTAAIAAA9IhTAAIAABQg");
	this.shape_5.setTransform(12.15,-187.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(0,-205,130.4,39), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgsA+IAAh7IBXAAIAAAgIgvAAIAAANIAsAAIAAAfIgsAAIAAAPIAxAAIAAAgg");
	this.shape.setTransform(121.95,-15.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AAJA+IgSgpIgGAAIAAApIgoAAIAAh7IA2AAQAWAAANAJQAPAKAAAVQAAAYgVAMIAcAvgAgPgJIALAAQAFAAACgCQAFgDAAgGQAAgFgFgDQgCgDgFABIgLAAg");
	this.shape_1.setTransform(111.225,-15.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AgvAvQgUgRAAgeQAAgcAUgSQASgRAdAAQAeAAASARQAUASgBAcQABAegUARQgSARgeAAQgdAAgSgRgAgSgUQgIAHAAANQAAANAIAIQAHAHALAAQAMAAAHgHQAIgIAAgNQAAgNgIgHQgHgJgMAAQgLAAgHAJg");
	this.shape_2.setTransform(97.6,-15.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AAkA+IgChGIgQBGIgiAAIgQhGIgCBGIgoAAIAHh7IA1AAIAOBDIAQhDIA0AAIAHB7g");
	this.shape_3.setTransform(82.45,-15.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AARA+IglhFIABAWIAAAvIgoAAIAAh7IAsAAIAkBEIgBgVIAAgvIAnAAIAAB7g");
	this.shape_4.setTransform(64.1,-15.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AAJA+IgSgpIgGAAIAAApIgoAAIAAh7IA2AAQAWAAANAJQAPAKAAAVQAAAYgVAMIAcAvgAgPgJIALAAQAFAAACgCQAFgDAAgGQAAgFgFgDQgCgDgFABIgLAAg");
	this.shape_5.setTransform(51.925,-15.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AAWA+IgFgSIgjAAIgEASIgrAAIAsh7IAsAAIArB7gAAIAOIgIghIgJAhIARAAg");
	this.shape_6.setTransform(39.025,-15.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgsA+IAAh7IBXAAIAAAgIgvAAIAAANIAsAAIAAAfIgsAAIAAAPIAxAAIAAAgg");
	this.shape_7.setTransform(27.65,-15.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AgpA+IAAh7IApAAIAABZIAqAAIAAAig");
	this.shape_8.setTransform(17.95,-15.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AphC0QhaAAAAhQIAAjHQAAhQBaAAITDAAQBaAAAABQIAADHQAABQhaAAg");
	this.shape_9.setTransform(70,-15.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(0,-33.5,140,36), null);


(lib.Btext22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhxB5IAAjxIBbAAQA9AAAiAaQApAfAAA/QAABAgpAeQgiAbg9AAgAgiA2IASAAQAYAAAMgMQAOgOAAgcQAAgegOgNQgMgMgYAAIgSAAg");
	this.shape.setTransform(141.975,-188.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhWB5IAAjxICqAAIAAA+IhcAAIAAAbIBXAAIAAA9IhXAAIAAAcIBgAAIAAA/g");
	this.shape_1.setTransform(119.05,-188.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhXB5IAAjxICrAAIAAA+IhcAAIAAAbIBWAAIAAA9IhWAAIAAAcIBfAAIAAA/g");
	this.shape_2.setTransform(98.75,-188.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhjB5IAAjxIBoAAQAsAAAXAUQAcAVAAAqQAAAqgcAVQgXAUgsAAIgZAAIAABLgAgUgNIANAAQAMAAAGgEQAJgGAAgOQAAgNgJgGQgGgEgMAAIgNAAg");
	this.shape_3.setTransform(78.125,-188.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhhBcIAjg8QAQANASAHQATAHALAAQARAAAAgLQgCgIgPgEIgigLQgXgKgLgIQgWgSABghQAAgjAcgXQAYgVAuAAQA0AAAhAdIgdA4QgNgLgRgGQgQgGgMAAQgSAAgBAJQAAAHAQAFIANAEIAQAEQAbAJAOAMQAWASAAAhQAAAngfAYQgbAVgsAAQgxAAgsggg");
	this.shape_4.setTransform(56.25,-188.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgnB5IAAizIg4AAIAAg+IC/AAIAAA+Ig4AAIAACzg");
	this.shape_5.setTransform(37.35,-188.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhWB5IAAjxICqAAIAAA+IhcAAIAAAbIBWAAIAAA9IhWAAIAAAcIBfAAIAAA/g");
	this.shape_6.setTransform(17.9,-188.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("ABFB5IgEiKIgfCKIhDAAIgfiKIgDCKIhOAAIAOjxIBmAAIAdCDIAfiDIBmAAIANDxg");
	this.shape_7.setTransform(-28.65,-188.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhGBcQglghABg7QgBg5AlghQAlgiA3AAQAfAAAVAIQAPAGALAHIACACIgUBDIgIgGQgEgDgPgGQgPgGgNAAQgYAAgPAOQgPAOAAAbQAAAYAQAPQAOAOAYAAQAkAAAWgWIAXA/QgfAfg3AAQg3AAglghg");
	this.shape_8.setTransform(-55.05,-188.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhGBcQglghAAg7QAAg5AlghQAlgiA3AAQAfAAAVAIQAPAGAKAHIADACIgVBDIgHgGQgEgDgQgGQgOgGgNAAQgYAAgOAOQgQAOAAAbQAAAYAQAPQAOAOAYAAQAkAAAWgWIAXA/QgfAfg3AAQg3AAglghg");
	this.shape_9.setTransform(-76.55,-188.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgnB5QgNgCgEgCIADg5QALADAJAAQAGAAACgCQAEgDAAgJIAAirIBOAAIAACrQAAAngSASQgRARggAAQgOAAgPgCg");
	this.shape_10.setTransform(0.225,-187.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-206.2,246.3,39);


(lib.Btext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhWB5IAAjxICqAAIAAA+IhcAAIAAAbIBWAAIAAA9IhWAAIAAAcIBgAAIAAA/g");
	this.shape.setTransform(178,-200.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgmB5IhbjxIBVAAIAsCLIAuiLIBTAAIhaDxg");
	this.shape_1.setTransform(154.9,-200.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgmB5IAAjxIBOAAIAADxg");
	this.shape_2.setTransform(136.6,-200.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhhBcIAjg8QAQANASAHQATAHAKAAQASAAAAgLQgCgIgPgEIgigLQgXgKgKgIQgXgSAAghQAAgjAcgXQAagVAsAAQA0AAAjAdIgeA4QgNgLgRgGQgQgGgMAAQgTAAAAAJQAAAHAQAFIAMAEIARAEQAbAJAOAMQAWASAAAhQAAAngfAYQgcAVgrAAQgxAAgsggg");
	this.shape_3.setTransform(120.75,-200.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhTBeQgagaAAg0IAAiKIBPAAIAACNQAAASAIAIQAJAJANAAQAOAAAJgJQAIgHAAgTIAAiNIBPAAIAACKQAAA0gaAaQgcAdg4AAQg2AAgdgdg");
	this.shape_4.setTransform(98.325,-200.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhQB5IAAjxIBPAAIAACwIBRAAIAABBg");
	this.shape_5.setTransform(78.1,-200.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhGBcQglghAAg7QAAg5AlghQAlgiA3AAQAfAAAVAIQAPAGALAHIACACIgVBDIgHgGQgEgDgPgGQgPgGgNAAQgYAAgOAOQgQAOAAAbQAAAYAQAPQAOAOAYAAQAkAAAWgWIAXA/QgfAfg3AAQg3AAglghg");
	this.shape_6.setTransform(57.55,-200.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAnB5IgnhNIgmBNIheAAIBQh9IhMh0IBfAAIAhBBIAihBIBfAAIhNB0IBRB9g");
	this.shape_7.setTransform(34.9,-200.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhWB5IAAjxICqAAIAAA+IhcAAIAAAbIBWAAIAAA9IhWAAIAAAcIBfAAIAAA/g");
	this.shape_8.setTransform(12.5,-200.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btext1, new cjs.Rectangle(0,-218.5,190,39), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-97.8,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-270.5,142.6,39);


// stage content:
(lib.jetfam_300x600_us = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(140,477.2,1,1,0,0,0,62,18);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(309).to({_off:false},0).to({alpha:1},22,cjs.Ease.cubicInOut).wait(12));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(-90.95,369.5,1,1,0,0,0,84.2,10.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(292).to({_off:false},0).to({x:149.05},20,cjs.Ease.quartOut).wait(31));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(148.25,267.4,0.4,0.4,0,0,0,177.5,184.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(268).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(46));

	// skate3
	this.instance_3 = new lib.skate3();
	this.instance_3.setTransform(-57,502.5,1,1,0,0,0,57,61.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({x:98},20,cjs.Ease.quartOut).wait(187).to({x:-64.5},18,cjs.Ease.quintInOut).wait(70));

	// skate2
	this.instance_4 = new lib.skate2();
	this.instance_4.setTransform(358.5,445,1,1,0,0,0,57,62);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({_off:false},0).to({x:221},20,cjs.Ease.quartOut).wait(190).to({x:383.5},18,cjs.Ease.quintInOut).wait(71));

	// skate1
	this.instance_5 = new lib.skate1();
	this.instance_5.setTransform(-58,368.5,1,1,0,0,0,56,61.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(40).to({_off:false},0).to({x:97},20,cjs.Ease.quartOut).wait(193).to({x:-59.25},18,cjs.Ease.quintInOut).wait(72));

	// cta
	this.instance_6 = new lib.CTA();
	this.instance_6.setTransform(84.45,285.9,1,1,0,0,0,62,18);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(145).to({y:217.15},23,cjs.Ease.quartInOut).wait(81).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(76));

	// Ctext3
	this.instance_7 = new lib.Ctext3();
	this.instance_7.setTransform(-92.7,252.6,1,1,0,0,0,74.8,24);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(157).to({_off:false},0).to({x:94.8},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(81));

	// Ctet2
	this.instance_8 = new lib.Ctext2();
	this.instance_8.setTransform(-105.2,252.6,1,1,0,0,0,74.8,24);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(154).to({_off:false},0).to({x:94.8},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_9 = new lib.Ctext1();
	this.instance_9.setTransform(-92.7,252.6,1,1,0,0,0,74.8,24);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(151).to({_off:false},0).to({x:94.8},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// Btext2_copy
	this.instance_10 = new lib.text3();
	this.instance_10.setTransform(-159.95,327.2);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(19).to({_off:false},0).to({x:110.05},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(192));

	// Btext2
	this.instance_11 = new lib.Btext22();
	this.instance_11.setTransform(-139.55,327.2);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(17).to({_off:false},0).to({x:110.05},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(194));

	// Btext1
	this.instance_12 = new lib.Btext1();
	this.instance_12.setTransform(-132,333,1,1,0,0,0,74.8,24);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(13).to({_off:false},0).to({x:94.8,y:331.8},22,cjs.Ease.quartOut).wait(93).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(197));

	// text2
	this.instance_13 = new lib.Tween2("synched",0);
	this.instance_13.setTransform(-141.95,327.2);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(9).to({_off:false},0).to({x:110.05},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_14 = new lib.text1();
	this.instance_14.setTransform(-184.8,252.6,1,1,0,0,0,74.8,24);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(5).to({_off:false},0).to({x:94.8},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// rip
	this.instance_15 = new lib.tear();
	this.instance_15.setTransform(150.6,299,1,1,0,0,0,151.6,302);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(256).to({y:667.75,alpha:0},22,cjs.Ease.quartInOut).wait(65));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-109.6,300,547.2,731.9000000000001);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/jetfam_300x600_us_atlas_P_1.png", id:"jetfam_300x600_us_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;