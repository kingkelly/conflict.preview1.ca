(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVAUQgIgHgBgNQABgMAIgHQAIgHANAAQAOAAAJAHQAHAHABAMQgBANgHAHQgJAHgOAAQgNAAgIgHg");
	this.shape.setTransform(413.45,78.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAxBWIgChiIgXBiIgvAAIgXhiIgCBiIg3AAIAKirIBIAAIAVBdIAWhdIBJAAIAJCrg");
	this.shape_1.setTransform(397.925,72.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAeBWIgHgYIgwAAIgGAYIg7AAIA8irIA9AAIA8CrgAALATIgLguIgNAuIAYAAg");
	this.shape_2.setTransform(377.875,72.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag9BWIAAirIB5AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBEAAIAAAtg");
	this.shape_3.setTransform(362,72.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_4.setTransform(347.625,72.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape_5.setTransform(328.9,72.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAxBWIgChiIgXBiIgvAAIgXhiIgCBiIg3AAIAKirIBIAAIAVBdIAWhdIBJAAIAJCrg");
	this.shape_6.setTransform(310.225,72.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_7.setTransform(289.175,72.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAYBWIAAg/IgvAAIAAA/Ig4AAIAAirIA4AAIAAA+IAvAAIAAg+IA4AAIAACrg");
	this.shape_8.setTransform(270.05,72.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag9BWIAAirIB5AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBEAAIAAAtg");
	this.shape_9.setTransform(248.95,72.075);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAXBWIAAg/IgtAAIAAA/Ig5AAIAAirIA5AAIAAA+IAtAAIAAg+IA5AAIAACrg");
	this.shape_10.setTransform(232.2,72.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_11.setTransform(216.075,72.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape_12.setTransform(197.35,72.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAOBWIgcg5IgKAMIAAAtIg4AAIAAirIA4AAIAAA0IAjg0IBDAAIg4BFIA7Bmg");
	this.shape_13.setTransform(182.225,72.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgbBWIAAirIA3AAIAACrg");
	this.shape_14.setTransform(168.775,72.075);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag5BWIAAirIA5AAIAAB9IA5AAIAAAug");
	this.shape_15.setTransform(158.7,72.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAOBWIgbg5IgHAAIAAA5Ig5AAIAAirIBLAAQAgAAARAMQAVAPAAAcQAAAigcARIAmBBgAgVgNIAPAAQAHAAAEgDQAHgEAAgIQAAgHgHgEQgEgEgHAAIgPAAg");
	this.shape_16.setTransform(139.4,72.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_17.setTransform(120.475,72.075);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_18.setTransform(104.875,72.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgbBWIAAirIA3AAIAACrg");
	this.shape_19.setTransform(93.925,72.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhFBBIAZgqQAMAJAMAFQAOAFAHAAQANAAAAgIQgBgFgMgEIgXgIQgRgGgIgGQgPgMgBgYQABgZATgRQATgPAfAAQAmABAYAUIgVAoQgKgIgMgEQgLgEgIgBQgOAAAAAIQAAAEAMAEIAJACIALAEQATAGAKAIQAQANAAAXQAAAcgWASQgUAPgegBQgkAAgfgXg");
	this.shape_20.setTransform(82.6,72.15);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgbBWIAAirIA3AAIAACrg");
	this.shape_21.setTransform(71.525,72.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgaBWIhBirIA7AAIAgBjIAhhjIA7AAIhACrg");
	this.shape_22.setTransform(58.45,72.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgbBWIAAhDIg8hoIA+AAIAZA6IAag6IA+AAIg8BoIAABDg");
	this.shape_23.setTransform(36.325,72.075);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAOBWIgbg5IgIAAIAAA5Ig4AAIAAirIBLAAQAgAAARAMQAVAPAAAcQAAAigcARIAmBBgAgVgNIAPAAQAHAAAEgDQAHgEAAgIQAAgHgHgEQgEgEgHAAIgPAAg");
	this.shape_24.setTransform(21.05,72.075);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape_25.setTransform(5,72.075);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgaBWIhCirIA8AAIAgBjIAghjIA8AAIhACrg");
	this.shape_26.setTransform(-11.5,72.075);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape_27.setTransform(-27.5,72.075);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_28.setTransform(-46.725,72.075);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAeBWIgHgYIgwAAIgGAYIg7AAIA8irIA9AAIA8CrgAALATIgLguIgNAuIAYAAg");
	this.shape_29.setTransform(-59.475,72.075);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape_30.setTransform(-75.35,72.075);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAOBWIgbg5IgHAAIAAA5Ig5AAIAAirIBLAAQAgAAARAMQAVAPAAAcQAAAigcARIAmBBgAgVgNIAOAAQAJAAADgDQAHgEgBgIQABgHgHgEQgEgEgIAAIgOAAg");
	this.shape_31.setTransform(-90.3,72.075);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_32.setTransform(-106.225,72.075);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBEAAIAAAtg");
	this.shape_33.setTransform(-124.95,72.075);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAXBWIgXhgIgWBgIg5AAIgxirIA7AAIAVBfIAVhfIA3AAIAWBfIAVhfIA6AAIgwCrg");
	this.shape_34.setTransform(-145.125,72.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(-159.8,58.7,579.9000000000001,29), null);


(lib.ClipGroup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ApfDVIAAmpIS/AAIAAGpg");
	mask.setTransform(60.8,21.275);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AglBDIAAiFIBLAAIAAAeIgpAAIAAAWIAmAAIAAAcIgmAAIAAAXIApAAIAAAeg");
	this.shape.setTransform(117.8,14.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgdAzQgWgUABgfQAAgcATgUQAVgWAeAAQAPAAAQAHIAAAqQgKgPgUAAQgQAAgJALQgKALAAAOQAAARAKAJQAJALAQAAQATAAALgOIAAApQgVAHgJAAQgcAAgWgUg");
	this.shape_1.setTransform(105.4,14.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AANBDIghg0IAAA0IgjAAIAAiFIA0AAQAUAAANAKQAMALAAAUQABAPgIAKQgIAKgOACIArA3gAgUgGIAEAAQAWAAAAgQQAAgRgWAAIgEAAg");
	this.shape_2.setTransform(93.25,14.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgrA2QgOgPAAggIAAhLIAjAAIAABGQAAAQADAJQAGALANAAQAPAAAFgLQADgIABgRIAAhGIAiAAIAABLQAAAQgCAIQgDAOgJAJQgPAPgdAAQgcAAgPgPg");
	this.shape_3.setTransform(78.45,14.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag0AyQgUgUAAgfQAAgeAWgUQAWgTAcAAQAeAAAVATQAWAUAAAeQAAAfgUAUQgVAVggAAQgfAAgVgVgAgagaQgLALAAAOQAAAQALALQALALAPAAQAQAAALgLQALgLAAgQQAAgOgLgLQgLgKgQAAQgOAAgMAKg");
	this.shape_4.setTransform(62.575,14.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcBDQgMgDgFgGIAAghQAGAIALAFQAMAFAJAAQAJAAAFgDQAEgDAAgGQAAgGgFgDQgFgDgLgFQgjgNAAgdQAAgSAMgMQAOgMATAAQAMAAAKADQAKAEAFAEIAAAgQgFgGgJgFQgKgEgIAAQgHAAgFADQgDADAAAGQAAAFAEAEQAGAEAJAEQARAGAKAKQAKAKAAAOQAAAUgNAMQgOAMgWAAQgNAAgMgEg");
	this.shape_5.setTransform(47.85,14.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgZAaQgLgLAAgPQAAgOALgLQALgKAOABQAPgBALAKQALALAAAOQAAAPgLALQgKAKgQAAQgPAAgKgKgAgMgMQgGAFAAAHQAAAIAGAFQAFAGAHAAQAIAAAFgGQAGgFAAgIQAAgHgGgFQgFgFgIAAQgHAAgFAFg");
	this.shape_6.setTransform(91.925,31.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgIAiIAAgzIgOAAIAAgQIAtAAIAAAQIgPAAIAAAzg");
	this.shape_7.setTransform(105.9,31.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAGAiIgQgaIAAAaIgRAAIAAhDIAbAAQAGABADABIAHAFIAEAHIACAIQAAAHgFAEQgCAEgIACIAVAcgAgKgCIAEAAQAGgBABgCQACgCABgDQgBgEgCgDQgBgCgGAAIgEAAg");
	this.shape_8.setTransform(99.9,31.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgYAiIAAhDIAbAAQAKAAAHAHQAFAFAAALQAAAKgFAGQgHAFgKAAIgKAAIAAAXgAgHgBIAGAAQAIAAAAgJQAAgIgIAAIgGAAg");
	this.shape_9.setTransform(84.15,31.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAGAhIgPgaIAAAaIgSAAIAAhBIAbAAQAFgBAEACQAFACACACQADADABAEIABAIQAAAHgDAFQgEAEgHACIAVAbgAgJgDIADAAQAFAAACgCQADgCAAgEQAAgEgDgCQgDgCgEgBIgDAAg");
	this.shape_10.setTransform(67.275,31.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgSAiIAAhDIAlAAIAAAQIgUAAIAAAKIASAAIAAAPIgSAAIAAAag");
	this.shape_11.setTransform(52.175,31.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgOAiQgFgCgDgDIAAgQQAEAEAFACQAFACAFAAQAEAAACgBQADgBAAgDQAAgEgDgBIgIgEQgRgGAAgPQAAgIAGgGQAHgHAJABQAFgBAGACQAFACADACIAAAQIgIgFQgFgCgEAAQgCAAgDABQAAAAgBABQAAABAAAAQAAABgBAAQAAABAAAAQAAABAAABQABABAAAAQAAABAAAAQABABAAAAIAHAEQAJADAFAEQAFAFAAAIQAAAJgGAGQgHAHgLAAQgHAAgGgCg");
	this.shape_12.setTransform(112.225,31.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgOAiQgFgCgDgDIAAgQQADAEAGACQAFACAFAAQAEAAACgBQADgBAAgDQAAgEgDgBIgIgEQgRgGAAgPQAAgIAGgGQAGgHAKABIALABIAIAEIAAAQIgIgFQgGgCgDAAQgCAAgDABQAAAAgBABQAAABAAAAQAAABgBAAQAAABAAAAQAAABAAABQABABAAAAQAAABAAAAQABABAAAAIAHAEQAJADAFAEQAFAFAAAIQAAAKgHAFQgGAHgLAAQgHAAgGgCg");
	this.shape_13.setTransform(77.575,31.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgZAZQgLgKAAgQQAAgOAMgKQALgKANABQAPgBALAKQALAKAAAOQAAAQgKAKQgLALgQgBQgPABgKgLgAgMgMQgGAEAAAHQAAAIAGAGQAFAGAHAAQAIAAAFgGQAGgGAAgIQAAgHgGgEQgFgGgIAAQgGAAgGAGg");
	this.shape_14.setTransform(59.275,31.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AALCZQhCAAgsgwQgUgVgLgbQgLgcAAgdQAAg/AtgsQAtgtA+AAQBMABA3ArIAAA8Qg5gxhHAAQgpAAgcAfQgaAcAAAlQAAAkAbAdQAcAeAoABQANAAAIAIQAJAJAAAMQAAAMgKAJQgJAIgLAAg");
	this.shape_15.setTransform(14.175,15.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AiYBZIAAg+QAdAfAeARQApAXAxAAQAqAAAcgfQAagcgBglQABgkgbgdQgcgegoAAQgNAAgIgJQgJgIAAgNQAAgMAKgJQAIgIAMAAIACAAQBCAAAtAwQAUAVALAcQALAbAAAcQAAA/gtAtQgsAthAAAQhbgBg9g/g");
	this.shape_16.setTransform(16.4,27.275);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,121.6,42.6), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfAVIgDgWIgKAWIgFAAIgJgWIgDAWIgLAAIAHgpIALAAIAIAUIAJgUIALAAIAHApgAghAVIAAgfIgJAAIAAgKIAeAAIAAAKIgJAAIAAAfg");
	this.shape.setTransform(209.1866,-65.6432,0.7347,0.7347);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgWAVQgJgIAAgNQAAgMAJgIQAIgHAOAAQAPAAAIAHQAJAIAAAMQAAANgJAIQgIAHgPAAQgOAAgIgHg");
	this.shape_1.setTransform(208.825,-51.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhABZIAAixIB/AAIAAAuIhFAAIAAATIBAAAIAAAtIhAAAIAAAUIBHAAIAAAvg");
	this.shape_2.setTransform(197.05,-57.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAzBZIgChlIgYBlIgxAAIgXhlIgCBlIg7AAIALixIBMAAIAVBfIAXhfIBLAAIAKCxg");
	this.shape_3.setTransform(177.65,-57.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAfBZIgHgYIgyAAIgHAYIg9AAIA+ixIBAAAIA/CxgAAMAUIgMgwIgOAwIAaAAg");
	this.shape_4.setTransform(156.925,-57.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag7BGQgdgaAAgsQAAgsAegZQAagWAogBQAeABAYAOQAIAEANANIgnAgQgQgPgUAAQgQAAgKAMQgLALAAAUQAAAVALALQAKAMAQAAQASAAAEgFIACgBIAAgOIgcAAIAAgqIBVAAIAABNIgJAJIgNAIQgIAGgIADQgTAIgaAAQgngBgagWg");
	this.shape_5.setTransform(137.9,-57.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAOBZIgcg7IgIAAIAAA7Ig6AAIAAixIBOAAQAgAAATAMQAWAQAAAdQAAAjgeASIAoBDgAgWgNIAPAAQAIAAAEgDQAHgFAAgIQAAgIgHgEQgEgEgIAAIgPAAg");
	this.shape_6.setTransform(115.825,-57.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag+BGQgTgUAAgnIAAhlIA7AAIAABoQAAANAGAHQAGAGAKAAQAKAAAHgGQAFgGABgOIAAhoIA7AAIAABlQAAAngUAUQgUAVgqAAQgoAAgWgVg");
	this.shape_7.setTransform(97.1,-57.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhFBEQgcgZABgrQgBgpAcgaQAbgZAqAAQArAAAbAZQAbAaAAApQAAArgbAZQgbAYgrABQgqgBgbgYgAgbgeQgLALAAATQAAARALANQALALAQgBQARABALgLQALgNAAgRQAAgTgLgLQgLgMgRAAQgQAAgLAMg");
	this.shape_8.setTransform(77.5,-57.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgdBZIAAhFIg+hsIBBAAIAaA8IAag8IBCAAIg/BsIAABFg");
	this.shape_9.setTransform(59.75,-57.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgdBZIAAiEIgqAAIAAgtICOAAIAAAtIgpAAIAACEg");
	this.shape_10.setTransform(38.95,-57.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgcBZIAAixIA5AAIAACxg");
	this.shape_11.setTransform(27.575,-57.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag9BZIAAixIB7AAIAAAuIhBAAIAAAcIA+AAIAAAtIg+AAIAAA6g");
	this.shape_12.setTransform(16.625,-57.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhABZIAAixIB+AAIAAAuIhDAAIAAATIBAAAIAAAtIhAAAIAAAUIBGAAIAAAvg");
	this.shape_13.setTransform(-3.15,-57.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAYBZIgYhkIgXBkIg8AAIgyixIA9AAIAWBiIAWhiIA5AAIAWBiIAWhiIA9AAIgyCxg");
	this.shape_14.setTransform(-24.125,-57.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(-41,-73.1,258.5,33.39999999999999), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AANAwIgNg1IgMA1IgfAAIgbhfIAgAAIAMA1IAMg1IAdAAIANA1IALg1IAgAAIgbBfg");
	this.shape.setTransform(403.65,-83.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AgkAkQgPgNAAgXQAAgWAPgNQAOgNAWAAQAXAAAOANQAPANAAAWQAAAXgPANQgOANgXAAQgWAAgOgNgAgOgQQgGAGAAAKQAAAKAGAGQAGAGAIAAQAJAAAGgGQAFgGAAgKQAAgKgFgGQgGgGgJAAQgIAAgGAGg");
	this.shape_1.setTransform(391.475,-83.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AANAwIgcg0IABAQIAAAkIgfAAIAAhfIAjAAIAaA1IAAgRIAAgkIAdAAIAABfg");
	this.shape_2.setTransform(380.75,-83.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AgmAwIAAhfIAoAAQARAAAKAIQAKAIAAARQAAAQgKAIQgKAIgRAAIgJAAIAAAegAgHgEIAFAAQAEAAADgCQADgCAAgGQAAgFgDgCQgDgCgEAAIgFAAg");
	this.shape_3.setTransform(368.825,-83.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AgkAkQgPgNAAgXQAAgWAPgNQAOgNAWAAQAXAAAOANQAPANAAAWQAAAXgPANQgOANgXAAQgWAAgOgNgAgOgQQgGAGAAAKQAAAKAGAGQAGAGAIAAQAJAAAGgGQAFgGAAgKQAAgKgFgGQgGgGgJAAQgIAAgGAGg");
	this.shape_4.setTransform(358.775,-83.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AANAwIAAgjIgZAAIAAAjIgfAAIAAhfIAfAAIAAAjIAZAAIAAgjIAfAAIAABfg");
	this.shape_5.setTransform(348.175,-83.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AgmAlIAOgYQAGAFAIACQAHADAEAAQAHAAAAgEQgBgDgGgCIgNgEQgJgEgEgDQgJgHAAgMQAAgOALgKQAKgIARAAQAVAAANAMIgMAVQgFgDgGgDQgHgCgEgBQgHAAAAAFQAAACAFACIAFABIAHACQAKAEAGAEQAJAHAAANQAAAPgNAKQgKAIgRAAQgTAAgSgMg");
	this.shape_6.setTransform(339.075,-83.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AmeCKQg9AAAAg9IAAiZQAAg9A9AAIM9AAQA9AAAAA9IAACZQAAA9g9AAg");
	this.shape_7.setTransform(372.575,-84.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(325,-98.1,95.19999999999999,27.599999999999994), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAIAPIgBgQIgDAQIgIAAIgDgQIAAAQIgJAAIABgdIAMAAIADAPIADgPIAMAAIADAdg");
	this.shape.setTransform(-284.3,286.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgEAPIAAgVIgGAAIAAgIIAVAAIAAAIIgGAAIAAAVg");
	this.shape_1.setTransform(-287.25,286.6);

	this.instance = new lib.ClipGroup();
	this.instance.setTransform(-416.75,268.2,2.3388,2.3388,0,0,0,60.7,21.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(-558.8,218.3,289.49999999999994,99.5), null);


// stage content:
(lib.home_728x90_en = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// EndText
	this.instance = new lib.endText();
	this.instance.setTransform(362.9,122.9,1.12,1.12,0,0,0,84.2,10.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(135).to({_off:false},0).to({alpha:1},23,cjs.Ease.quadInOut).wait(38));

	// Logo
	this.instance_1 = new lib.logo_en_stacked();
	this.instance_1.setTransform(362.05,8.5,0.448,0.448,0,0,0,177.6,184.6);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(130).to({_off:false},0).to({alpha:1},22,cjs.Ease.quadInOut).wait(44));

	// cta
	this.instance_2 = new lib.CTA();
	this.instance_2.setTransform(290.65,160.85,1.12,1.12,0,0,0,62.1,18.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(141).to({_off:false},0).to({alpha:1},22,cjs.Ease.quadInOut).wait(33));

	// text1
	this.instance_3 = new lib.text1();
	this.instance_3.setTransform(-390.95,-8.1,1.12,1.12,0,0,0,74.8,24);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(5).to({_off:false},0).to({x:302.15},34,cjs.Ease.quartOut).wait(77).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(59));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(196));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-289.7,45.5,1017.7,45);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;