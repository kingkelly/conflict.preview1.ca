(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"speed_336x280_en_atlas_P_1", frames: [[0,0,450,377]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Asset6tearBB = function() {
	this.initialize(ss["speed_336x280_en_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape.setTransform(127.7,-146.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgbBWIhAirIA7AAIAgBjIAhhjIA7AAIhBCrg");
	this.shape_1.setTransform(111.2,-146.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbBWIAAirIA3AAIAACrg");
	this.shape_2.setTransform(98.125,-146.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhFBBIAZgqQAMAJANAFQANAFAHAAQAMAAAAgHQgBgHgLgCIgYgIQgQgHgHgGQgRgNABgXQAAgZATgRQATgOAgAAQAlgBAYAVIgWAoQgIgIgMgEQgNgFgHABQgNgBgBAIQABAEAKADIAJADIAMADQATAHAKAJQAQAMAAAYQAAAbgXASQgSAPgfAAQgkAAgfgYg");
	this.shape_3.setTransform(86.8,-146.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag7BDQgTgTAAglIAAhiIA5AAIAABkQAAAOAGAFQAGAGAJAAQAKAAAGgGQAGgFAAgOIAAhkIA5AAIAABiQAAAlgTATQgUAVgoAAQgmAAgVgVg");
	this.shape_4.setTransform(70.775,-145.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag5BWIAAirIA4AAIAAB9IA6AAIAAAug");
	this.shape_5.setTransform(56.35,-146.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgxBBQgbgXAAgqQAAgoAbgYQAagYAnAAQAWAAAPAGQALAEAHAFIACABIgPAwIgFgEQgDgCgLgFQgKgEgKAAQgRAAgKAKQgLAKAAATQAAARALALQAKAKARAAQAaAAAQgPIAQAsQgWAWgnAAQgnAAgagYg");
	this.shape_6.setTransform(41.675,-146.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAcBWIgcg3IgaA3IhEAAIA6hZIg3hSIBDAAIAYAuIAZguIBDAAIg2BSIA5BZg");
	this.shape_7.setTransform(25.5,-146.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhCAAIAAATIA+AAIAAArIg+AAIAAAUIBFAAIAAAtg");
	this.shape_8.setTransform(9.5,-146.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(0,-159.5,136.9,29), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape.setTransform(93.85,-191.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgxBCQgbgYAAgqQAAgoAbgYQAagYAnAAQAWAAAPAGQALADAHAFIACADIgPAvIgFgFQgDgCgLgEQgKgEgKAAQgRAAgKAKQgLALAAASQAAARALALQAKAKARAAQAaAAAQgQIAQAtQgWAWgnAAQgnAAgagXg");
	this.shape_1.setTransform(78.675,-191.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOBWIgbg5IgHAAIAAA5Ig5AAIAAirIBLAAQAfAAASAMQAVAPAAAcQAAAigdARIAnBBgAgVgNIAOAAQAJAAADgDQAHgEgBgIQABgHgHgEQgEgEgIAAIgOAAg");
	this.shape_2.setTransform(63.05,-191.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag7BDQgTgTAAglIAAhiIA5AAIAABkQAAAOAGAFQAGAGAJAAQAKAAAGgGQAGgFAAgOIAAhkIA5AAIAABiQAAAlgTATQgUAVgoAAQgmAAgVgVg");
	this.shape_3.setTransform(44.975,-191.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_4.setTransform(26.125,-191.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhFBBIAZgqQALAJANAFQAOAFAHAAQAMAAAAgIQgBgFgKgEIgYgIQgRgGgIgGQgQgMAAgYQAAgZAVgRQASgPAfAAQAmABAYAUIgVAoQgKgIgMgEQgLgEgJgBQgMAAAAAHQAAAFAKAEIAJACIAMAEQATAGAKAIQAQANAAAXQAAAcgWASQgUAOgfAAQgiAAgggXg");
	this.shape_5.setTransform(9,-191.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(0,-205,103.1,29), null);


(lib.rip = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Asset6tearBB();
	this.instance.setTransform(-24,-11,0.7066,0.7066);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rip, new cjs.Rectangle(-24,-11,318,266.4), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfAVIgDgWIgKAWIgFAAIgJgWIgDAWIgLAAIAHgpIALAAIAIAUIAJgUIALAAIAHApgAghAVIAAgfIgJAAIAAgKIAeAAIAAAKIgJAAIAAAfg");
	this.shape.setTransform(283.8009,-144.2388,0.7,0.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiqEtIAApZIFVAAIAACEIi5AAIAABlICwAAIAACDIiwAAIAABpIC5AAIAACEg");
	this.shape_1.setTransform(289.5758,-191.5061,0.7,0.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgcEpQg7gWgwgrQhhhaAAiNQAAg+AXg6QAXg5ArgtQAtgvA+gaQA8gaBAAAQBIAABJAeIAAC+QgYgfglgSQglgSgpABQhHgBgtAxQgtAxAABGQAABJAtAvQAtAuBKABQAmAAAlgSQAkgRAZgeIAAC+QgxAPgWAFQgjAIgiAAQg/AAg6gYg");
	this.shape_2.setTransform(250.306,-191.4361,0.7,0.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AA3EtIiSjnIgCAAIAADnIicAAIAApZIDqAAQBdAAA3AtQA8AvAABdQAABBgiAuQgkAvg+ALIC9D3gAhdgeIAPAAQAwAAAagNQAigSAAgsQAAgsgigTQgagNgwAAIgPAAg");
	this.shape_3.setTransform(211.8062,-191.5061,0.7,0.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhqEmQg5gRgjgjQgpgngNg8QgKgoAAhKIAAlRICdAAIAAE8QAABMAPAjQAYA1BCgBQBDABAYg1QAPgiAAhNIAAk8ICdAAIAAFRQAABLgJAnQgOA8goAnQgjAjg5ARQgyAPg6AAQg5AAgxgPg");
	this.shape_4.setTransform(164.9064,-190.9461,0.7,0.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AjuDjQhehcAAiRQAAiFBmhaQBhhWCFgBQCGABBhBWQBmBaAACFQAACRheBcQheBdiRAAQiQAAhehdgAh3h4QgyAvAABAQAABLAyA1QAxAyBGAAQBHAAAxgyQAyg1AAhLQAAhAgygvQgzgwhFAAQhEAAgzAwg");
	this.shape_5.setTransform(114.5766,-191.4711,0.7,0.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AiEEwQgzgRgagYIAAiUQAeAjA0AWQA1AYAqAAQAnAAAWgPQAWgPAAgZQAAgagYgPQgWgPg5gWQicg5AAiIQAAhSA5g2QA6g2BeAAQA2AAArAOQAsAPAbATIAACTQgYgdgrgTQgrgVgnAAQgjAAgSAOQgTAQAAAYQAAAXAUARQAVARAzATQBPAdAtAtQAuAwAABDQAABXg8A2Qg9A3hrAAQg/AAgzgRg");
	this.shape_6.setTransform(67.9218,-191.4361,0.7,0.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ah3ByQgugvgBhIQAAhCA0gtQAwgrBCAAQBDAAAxArQAyAtAABCQAABIguAvQgvAuhJAAQhHAAgwgugAg7g8QgZAYAAAgQAAAlAZAaQAYAaAjAAQAkAAAYgaQAZgaAAglQAAgggZgYQgZgYgjAAQgiAAgZAYg");
	this.shape_7.setTransform(207.5537,-135.2789,0.7,0.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgmCYIAAjsIhBAAIAAhDIDPAAIAABDIhAAAIAADsg");
	this.shape_8.setTransform(251.811,-135.3139,0.7,0.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAcCYIhKh1IAAB1IhPAAIAAkvIB7AAQAYAAATAIQASAHANANQAMAMAHASQAGARAAATQAAAjgRAVQgRAVggAHIBfB9gAgugPIAPAAQAXAAALgKQANgJAAgSQAAgTgNgJQgKgKgYAAIgPAAg");
	this.shape_9.setTransform(232.8761,-135.3139,0.7,0.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhyCYIAAkvIB8AAQA0AAAbAbQAbAbAAAwQAAAwgbAaQgbAag0AAIgtAAIAABlgAgjgLIAaAAQAqAAAAgmQAAgmgqAAIgaAAg");
	this.shape_10.setTransform(182.9838,-135.3139,0.7,0.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAcCYIhKh1IAAB1IhPAAIAAkvIB7AAQAYAAATAIQATAHAMANQAMAMAHASQAGARAAATQAAAjgRAVQgQAVghAHIBfB9gAgugPIAPAAQAXAAAMgKQAMgKAAgSQAAgRgMgKQgMgKgXAAIgPAAg");
	this.shape_11.setTransform(129.4865,-135.2439,0.7,0.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhWCYIAAkvICtAAIAABDIheAAIAAAzIBVAAIAABCIhVAAIAAB3g");
	this.shape_12.setTransform(81.6067,-135.3139,0.7,0.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhBCXQgagHgNgNIAAhKQAPARAaAMQAaALAVAAQATABALgIQALgHAAgNQAAgMgLgIQgNgIgagKQhOgdAAhEQAAgoAcgbQAdgbAuAAQAcAAAVAHQAXAIAMAJIAABJQgLgOgWgKQgWgLgTABQgQgBgKAIQgJAHAAANQAAAMAKAIQAKAIAZAKQAnAOAXAWQAXAYAAAhQAAAsgeAaQgeAcg2AAQgfAAgZgJg");
	this.shape_13.setTransform(271.9359,-135.2964,0.7,0.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhBCXQgagHgNgNIAAhKQAOAQAbANQAbALAUAAQATABALgIQALgHAAgNQAAgMgMgIQgKgIgcgKQhOgdAAhEQAAgoAcgbQAcgbAvAAQAcAAAVAHQAXAIAMAJIAABJQgLgOgWgKQgWgLgTABQgQgBgKAIQgJAHAAANQAAAMAKAIQAKAIAZAKQAnAOAXAWQAXAYAAAhQAAAsgeAaQgfAcg1AAQgfAAgZgJg");
	this.shape_14.setTransform(162.1064,-135.2964,0.7,0.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ah2ByQgvgvAAhHQAAhDAygtQAxgrBCAAQBDAAAxArQAyAtAABDQAABHgvAvQguAuhJAAQhIAAgugugAg7g7QgZAYAAAfQAAAlAZAaQAYAZAjABQAjgBAZgZQAZgZAAgmQAAgfgZgYQgZgZgjAAQgiAAgZAZg");
	this.shape_15.setTransform(104.1816,-135.2264,0.7,0.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAxK0QiRAAiCg3QiBg3hihoQhahhgxh9Qgyh9AAiDQABkdDLjLQDLjLEcAAQFYADD6DGIAAEQQiDhyiOg3QiNg3ijAAQi/AAh/CLQh0CAgBCoQAAClB4CCQCACLC4AAQA5AAAmAmQAnAnAAA5QAAA3grAoQgoAkgzAAg");
	this.shape_16.setTransform(172.1339,-333.693,0.7,0.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AmrJUQiUhIh0h5IAAkXQCECOCHBKQC5BnDgAAQC+AAB/iLQB1iAAAioQAAilh3iCQiAiLi5AAQg6AAgmgmQgmgmAAg6QAAg4ArgnQAogkAzAAIANAAQCSgBCCA4QCCA4BhBoQBaBgAyB9QAxB+AACBQAAEejLDLQhgBgh8A1QiBA3iMAAQjogCjDhfg");
	this.shape_17.setTransform(179.1863,-295.7357,0.7,0.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(53.2,-382.1,248.40000000000003,258.1), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfAVIgDgWIgKAWIgFAAIgJgWIgDAWIgLAAIAHgpIALAAIAIAUIAJgUIALAAIAHApgAghAVIAAgfIgJAAIAAgKIAeAAIAAAKIgJAAIAAAfg");
	this.shape.setTransform(140.0505,-201.1704,0.4158,0.4158);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgKAKQgEgEAAgGQAAgFAEgDQAEgEAGAAQAHAAAEAEQAEADAAAFQAAAGgEAEQgEADgHAAQgGAAgEgDg");
	this.shape_1.setTransform(139.425,-195);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAVIgfAAIAAAJIAdAAIAAAUIgdAAIAAAJIAgAAIAAAWg");
	this.shape_2.setTransform(134.075,-197.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAXApIgBguIgKAuIgXAAIgKguIgBAuIgbAAIAFhRIAjAAIAJArIAKgrIAjAAIAFBRg");
	this.shape_3.setTransform(125.175,-197.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOApIgDgMIgWAAIgDAMIgcAAIAchRIAdAAIAcBRgAAFAJIgFgVIgGAVIALAAg");
	this.shape_4.setTransform(115.625,-197.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgaAgQgOgMAAgUQAAgUAOgLQAMgLARAAQAOAAALAHQAEADAGAFIgSAPQgHgHgKAAQgGgBgFAGQgFAFAAAJQAAAJAFAGQAFAFAGAAQAIAAADgCIAAgBIAAgGIgMAAIAAgTIAnAAIAAAjIgFAEIgFAEIgHAEQgKADgLABQgRAAgMgLg");
	this.shape_5.setTransform(106.925,-197.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAGApIgMgbIgDAAIAAAbIgbAAIAAhRIAjAAQAPAAAIAGQAKAHAAANQAAAPgNAJIASAfgAgKgGIAHAAQADAAACgBQADgCAAgDQAAgFgDgBQgCgCgDAAIgHAAg");
	this.shape_6.setTransform(96.775,-197.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgbAgQgKgJABgSIAAguIAbAAIAAAvQgBAHADACQADADAEAAQAFAAADgDQACgCAAgHIAAgvIAbAAIAAAuQABASgKAJQgJAKgTAAQgSAAgJgKg");
	this.shape_7.setTransform(88.25,-197.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgfAfQgNgMAAgTQAAgTANgLQAMgMATAAQATAAANAMQAMALAAATQAAATgMAMQgNAMgTAAQgTAAgMgMgAgMgOQgEAGgBAIQABAIAEAGQAFAEAHAAQAIAAAEgEQAGgGAAgIQAAgIgGgGQgEgEgIAAQgHAAgFAEg");
	this.shape_8.setTransform(79.25,-197.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgMApIAAggIgdgxIAeAAIALAcIANgcIAdAAIgdAxIAAAgg");
	this.shape_9.setTransform(71.1,-197.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgMApIAAg8IgUAAIAAgVIBBAAIAAAVIgUAAIAAA8g");
	this.shape_10.setTransform(61.525,-197.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgNApIAAhRIAaAAIAABRg");
	this.shape_11.setTransform(56.35,-197.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbApIAAhRIA3AAIAAAVIgdAAIAAANIAcAAIAAAUIgcAAIAAAbg");
	this.shape_12.setTransform(51.35,-197.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgdApIAAhRIA6AAIAAAVIgfAAIAAAJIAdAAIAAAUIgdAAIAAAJIAgAAIAAAWg");
	this.shape_13.setTransform(42.225,-197.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AALApIgLguIgKAuIgcAAIgXhRIAdAAIAKAtIAKgtIAaAAIAKAtIAKgtIAbAAIgWBRg");
	this.shape_14.setTransform(32.65,-197.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(25.2,-204.8,117.89999999999999,14.700000000000017), null);


(lib.Ctext3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVAUQgJgHAAgNQAAgMAJgHQAIgHANAAQAOAAAJAHQAIAHAAAMQAAANgIAHQgJAHgOAAQgNAAgIgHg");
	this.shape.setTransform(175.5,-140.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape_1.setTransform(164.15,-147.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgxBBQgbgXAAgqQAAgpAbgXQAagYAnAAQAWAAAPAGQALAEAHAFIACABIgPAwIgFgEQgDgCgLgFQgKgEgKAAQgRAAgKAKQgLALAAASQAAASALAKQAKAKARAAQAaAAAQgPIAQAsQgWAWgnAAQgnAAgagYg");
	this.shape_2.setTransform(148.975,-147.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAYBWIg0hfIABAeIAABBIg3AAIAAirIA9AAIAyBfIgCgeIAAhBIA4AAIAACrg");
	this.shape_3.setTransform(131.3,-147.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAeBWIgHgYIgwAAIgGAYIg7AAIA8irIA9AAIA8CrgAALATIgLguIgNAuIAYAAg");
	this.shape_4.setTransform(112.925,-147.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAxBWIgChiIgXBiIgvAAIgXhiIgCBiIg3AAIAKirIBIAAIAVBdIAWhdIBJAAIAJCrg");
	this.shape_5.setTransform(92.875,-147.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_6.setTransform(71.825,-147.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag7BWIAAirIB3AAIAAAsIg/AAIAAAbIA7AAIAAArIg7AAIAAA5g");
	this.shape_7.setTransform(55.85,-147.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AANBWIgag5IgIAAIAAA5Ig4AAIAAirIBLAAQAfAAASAMQAVAPAAAcQAAAigdARIAnBBgAgVgNIAPAAQAIAAADgDQAGgEAAgIQAAgHgGgEQgEgEgHAAIgPAAg");
	this.shape_8.setTransform(41.15,-147.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape_9.setTransform(25.1,-147.125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhGBWIAAirIBKAAQAfAAARAOQATAPAAAeQAAAdgTAQQgRAOgfAAIgSAAIAAA1gAgOgJIAJAAQAJAAAEgDQAGgEAAgKQAAgJgGgEQgEgEgJAAIgJAAg");
	this.shape_10.setTransform(10.375,-147.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext3, new cjs.Rectangle(0,-160.5,182.1,29), null);


(lib.Ctext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhQBWIAAirIBBAAQArAAAYASQAdAXAAAsQAAAtgdAWQgYATgrAAgAgYAnIANAAQAQAAAJgJQAKgKAAgUQAAgVgKgJQgJgJgQAAIgNAAg");
	this.shape.setTransform(173.775,-169.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAYBWIg0hfIACAeIAABBIg4AAIAAirIA9AAIAyBfIgBgeIAAhBIA3AAIAACrg");
	this.shape_1.setTransform(154.9,-169.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAeBWIgHgYIgwAAIgGAYIg7AAIA8irIA9AAIA8CrgAALATIgLguIgNAuIAYAAg");
	this.shape_2.setTransform(136.525,-169.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_3.setTransform(115.925,-169.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAOBWIgbg5IgIAAIAAA5Ig4AAIAAirIBLAAQAgAAARAMQAVAPAAAcQAAAigcARIAmBBgAgVgNIAPAAQAHAAAEgDQAHgEAAgIQAAgHgHgEQgEgEgHAAIgPAAg");
	this.shape_4.setTransform(101.6,-169.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_5.setTransform(82.675,-169.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag7BWIAAirIB3AAIAAAsIg/AAIAAAbIA8AAIAAArIg8AAIAAA5g");
	this.shape_6.setTransform(66.7,-169.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAxBWIgChiIgXBiIgvAAIgXhiIgCBiIg3AAIAKirIBIAAIAVBdIAWhdIBJAAIAJCrg");
	this.shape_7.setTransform(48.275,-169.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_8.setTransform(27.225,-169.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgxBBQgbgXAAgqQAAgoAbgYQAagYAnAAQAWAAAPAGQALADAHAGIACACIgPAvIgFgEQgDgDgLgEQgKgEgKAAQgRAAgKAKQgLALAAASQAAASALAKQAKAKARAAQAaAAAQgQIAQAtQgWAWgnAAQgnAAgagYg");
	this.shape_9.setTransform(10.175,-169.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext2, new cjs.Rectangle(0,-182.7,184.6,29), null);


(lib.Ctext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAOBWIgbg5IgIAAIAAA5Ig4AAIAAirIBLAAQAgAAARAMQAVAPAAAcQAAAigcARIAmBBgAgVgNIAPAAQAHAAAEgDQAHgEAAgIQAAgHgHgEQgEgEgHAAIgPAAg");
	this.shape.setTransform(185.75,-191.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_1.setTransform(166.825,-191.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag7BWIAAirIB3AAIAAAsIg/AAIAAAbIA8AAIAAArIg8AAIAAA5g");
	this.shape_2.setTransform(150.85,-191.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhQBWIAAirIBBAAQArAAAYASQAdAXAAAsQAAAtgdAWQgYATgrAAgAgYAnIANAAQAQAAAJgJQAKgKAAgUQAAgVgKgJQgJgJgQAAIgNAAg");
	this.shape_3.setTransform(130.125,-191.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape_4.setTransform(113.75,-191.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhKBWIAAgoIBKhWIhIAAIAAgtICQAAIAAAmIhKBXIBNAAIAAAug");
	this.shape_5.setTransform(98.05,-191.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgbBWIAAirIA3AAIAACrg");
	this.shape_6.setTransform(85.675,-191.625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAxBWIgChiIgXBiIgvAAIgXhiIgCBiIg3AAIAKirIBIAAIAVBdIAWhdIBJAAIAJCrg");
	this.shape_7.setTransform(70.425,-191.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgbBWIAAirIA3AAIAACrg");
	this.shape_8.setTransform(55.175,-191.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_9.setTransform(44.225,-191.625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhGBWIAAirIBKAAQAfAAARAOQATAPAAAeQAAAdgTAQQgRAOgfAAIgSAAIAAA1gAgOgJIAJAAQAJAAAEgDQAGgEAAgKQAAgJgGgEQgEgEgJAAIgJAAg");
	this.shape_10.setTransform(30.125,-191.625);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_11.setTransform(11.875,-191.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ctext1, new cjs.Rectangle(0,-205,195.4,29), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AALAsIgLgxIgLAxIgdAAIgYhXIAdAAIALAwIALgwIAbAAIALAwIAKgwIAeAAIgYBXg");
	this.shape.setTransform(73.05,-98.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AghAhQgOgMAAgVQAAgUAOgMQANgMAUAAQAVAAAOAMQANAMgBAUQABAVgNAMQgOAMgVAAQgUAAgNgMgAgNgOQgEAFAAAJQAAAJAEAFQAGAGAHAAQAJAAAEgGQAGgFAAgJQAAgJgGgFQgEgGgJAAQgHAAgGAGg");
	this.shape_1.setTransform(61.85,-98.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AAMAsIgagwIABAPIAAAhIgcAAIAAhXIAfAAIAZAwIgBgPIAAghIAcAAIAABXg");
	this.shape_2.setTransform(52.075,-98.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AgjAsIAAhXIAlAAQAPAAAJAHQAKAIAAAPQAAAPgKAIQgJAHgPAAIgJAAIAAAbgAgHgEIAFAAQAEAAACgCQADgCAAgFQAAgEgDgDQgCgBgEAAIgFAAg");
	this.shape_3.setTransform(41.1,-98.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AghAhQgOgMAAgVQAAgUAOgMQANgMAUAAQAVAAANAMQAOAMAAAUQAAAVgOAMQgNAMgVAAQgUAAgNgMgAgMgOQgFAFgBAJQABAJAFAFQAEAGAIAAQAJAAAFgGQAEgFAAgJQAAgJgEgFQgFgGgJAAQgIAAgEAGg");
	this.shape_4.setTransform(31.85,-98.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AAMAsIAAghIgXAAIAAAhIgdAAIAAhXIAdAAIAAAgIAXAAIAAggIAcAAIAABXg");
	this.shape_5.setTransform(22.15,-98.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AgiAhIAMgVQAGAEAHADQAHADADAAQAGAAAAgFQgBgDgFgBIgMgEQgJgDgDgDQgIgHAAgLQAAgNAKgJQAJgHAQAAQASAAANAKIgLAVQgEgEgHgCQgFgDgFABQgGgBAAAEQAAADAFABIAFACIAFABQALADAFAFQAHAGABAMQAAAOgMAIQgKAIgPAAQgRAAgQgMg");
	this.shape_6.setTransform(13.8,-98.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Al7B/Qg5AAAAg5IAAiLQAAg5A5AAIL3AAQA5AAAAA5IAACLQAAA5g5AAg");
	this.shape_7.setTransform(45.025,-99.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(1.4,-111.7,87.3,25.400000000000006), null);


(lib.Btext22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVAUQgIgHAAgNQAAgMAIgHQAIgHANAAQAOAAAJAHQAHAHABAMQgBANgHAHQgJAHgOAAQgNAAgIgHg");
	this.shape.setTransform(33.45,-217.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag4BWIAAirIA3AAIAAB9IA7AAIAAAug");
	this.shape_1.setTransform(23.1,-223.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_2.setTransform(6.225,-223.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAOBWIgbg5IgHAAIAAA5Ig5AAIAAirIBLAAQAgAAARAMQAVAPAAAcQAAAigcARIAmBBgAgVgNIAOAAQAJAAADgDQAHgEgBgIQABgHgHgEQgEgEgIAAIgOAAg");
	this.shape_3.setTransform(-11.1,-223.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_4.setTransform(-27.025,-223.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAYBWIg0hfIABAeIAABBIg3AAIAAirIA+AAIAxBfIgCgeIAAhBIA3AAIAACrg");
	this.shape_5.setTransform(-43.4,-223.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhCBBQgbgYAAgpQAAgoAbgYQAagYAoAAQApAAAbAYQAaAYAAAoQAAApgaAYQgbAYgpAAQgoAAgagYgAgagdQgKALAAASQAAARAKALQAKALAQAAQAQAAALgLQAKgLAAgRQAAgSgKgLQgKgLgRAAQgQAAgKALg");
	this.shape_6.setTransform(-62.775,-223.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgxBCQgbgYAAgqQAAgpAbgXQAagYAnAAQAWAAAPAGQALAEAHAEIACACIgPAwIgFgFQgDgCgLgEQgKgEgKAAQgRAAgKAKQgLAKAAATQAAARALALQAKAKARAAQAaAAAQgPIAQAsQgWAWgnAAQgnAAgagXg");
	this.shape_7.setTransform(-79.825,-223.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-236.7,130.1,29);


(lib.Btext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhQBWIAAirIBBAAQArAAAYASQAdAXAAAsQAAAtgdAWQgYATgrAAgAgYAnIANAAQAQAAAJgJQAKgKAAgUQAAgVgKgJQgJgJgQAAIgNAAg");
	this.shape.setTransform(165.225,-226.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape_1.setTransform(148.85,-226.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag+BWIAAirIB6AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBDAAIAAAtg");
	this.shape_2.setTransform(134.35,-226.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhGBWIAAirIBKAAQAfAAARAOQATAPAAAeQAAAdgTAQQgRAOgfAAIgSAAIAAA1gAgOgJIAJAAQAJAAAEgDQAGgEAAgKQAAgJgGgEQgEgEgJAAIgJAAg");
	this.shape_3.setTransform(119.625,-226.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhFBCIAZgrQALAJAOAFQANAFAHAAQANAAAAgIQgCgFgLgEIgYgHQgQgHgHgGQgQgNAAgXQAAgZATgRQATgOAgAAQAkgBAZAVIgWAoQgIgIgMgEQgNgFgHABQgNAAgBAGQABAGALACIAJADIALADQATAHAKAJQAQAMAAAYQAAAbgXASQgSAOgfAAQgkABgfgXg");
	this.shape_4.setTransform(104,-226.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgbBWIAAh/IgpAAIAAgsICJAAIAAAsIgpAAIAAB/g");
	this.shape_5.setTransform(90.475,-226.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag9BWIAAirIB5AAIAAAsIhBAAIAAATIA9AAIAAArIg9AAIAAAUIBEAAIAAAtg");
	this.shape_6.setTransform(76.6,-226.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAxBWIgChiIgXBiIgvAAIgXhiIgCBiIg3AAIAKirIBIAAIAVBdIAWhdIBJAAIAJCrg");
	this.shape_7.setTransform(43.375,-226.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgxBBQgbgXAAgqQAAgpAbgXQAagYAnAAQAWAAAPAGQALAEAHAFIACABIgPAwIgFgEQgDgCgLgFQgKgEgKAAQgRAAgKAKQgLALAAASQAAASALAKQAKAKARAAQAaAAAQgPIAQAsQgWAWgnAAQgnAAgagYg");
	this.shape_8.setTransform(24.525,-226.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgxBBQgbgXAAgqQAAgpAbgXQAagYAnAAQAWAAAPAGQALAEAHAFIACABIgPAwIgFgEQgDgCgLgFQgKgEgKAAQgRAAgKAKQgLALAAASQAAASALAKQAKAKARAAQAaAAAQgPIAQAsQgWAWgnAAQgnAAgagYg");
	this.shape_9.setTransform(9.175,-226.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgcBYQgJgCgDgCIACgpQAIADAGAAQAFAAABgCQADgCAAgGIAAh8IA4AAIAAB8QAAAbgNANQgMANgXAAIgVgBg");
	this.shape_10.setTransform(64.325,-226.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btext1, new cjs.Rectangle(-1,-239.7,177.1,29), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-97.8,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-281.3,136.9,29);


// stage content:
(lib.speed_336x280_en = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(184.8,359.8,1.12,1.12,0,0,0,62,18.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(309).to({_off:false},0).to({alpha:1},22,cjs.Ease.cubicInOut).wait(12));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(-101.85,413.9,1.12,1.12,0,0,0,84.2,10.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(292).to({_off:false},0).to({x:166.9},20,cjs.Ease.quartOut).wait(31));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(166.05,299.5,0.448,0.448,0,0,0,177.6,184.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(268).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(46));

	// cta
	this.instance_3 = new lib.CTA();
	this.instance_3.setTransform(94.65,320.25,1.12,1.12,0,0,0,62.1,18.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(145).to({y:296.75},23,cjs.Ease.quartInOut).wait(81).to({y:297.85,alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(76));

	// Ctext3
	this.instance_4 = new lib.Ctext3();
	this.instance_4.setTransform(-103.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(157).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(81));

	// Ctet2
	this.instance_5 = new lib.Ctext2();
	this.instance_5.setTransform(-117.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(154).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(84));

	// Ctext1
	this.instance_6 = new lib.Ctext1();
	this.instance_6.setTransform(-103.9,282.9,1.12,1.12,0,0,0,74.7,24);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(151).to({_off:false},0).to({regX:74.8,x:106.15},22,cjs.Ease.quartOut).wait(65).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(87));

	// Btext2
	this.instance_7 = new lib.Btext22();
	this.instance_7.setTransform(-156.25,366.45,1.12,1.12);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(17).to({_off:false},0).to({x:123.25},22,cjs.Ease.quartOut).wait(92).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(194));

	// Btext1
	this.instance_8 = new lib.Btext1();
	this.instance_8.setTransform(-147.8,372.95,1.12,1.12,0,0,0,74.8,24);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(13).to({_off:false},0).to({x:106.15,y:371.6},22,cjs.Ease.quartOut).wait(93).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(197));

	// text2
	this.instance_9 = new lib.Tween2("synched",0);
	this.instance_9.setTransform(-158.95,366.45,1.12,1.12);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(9).to({_off:false},0).to({x:123.25},21,cjs.Ease.quartOut).wait(95).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(200));

	// text1
	this.instance_10 = new lib.text1();
	this.instance_10.setTransform(-206.95,282.9,1.12,1.12,0,0,0,74.8,24);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(5).to({_off:false},0).to({x:106.15},21,cjs.Ease.quartOut).wait(96).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(200));

	// rip
	this.instance_11 = new lib.rip();
	this.instance_11.setTransform(177.95,140.25,1.12,1.12,0,0,0,151.9,126.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(253).to({x:379.55},21,cjs.Ease.quartInOut).wait(69));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(167.9993,335.9985,1.12,1.12);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(343));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-122.7,126.6,661.3000000000001,545.4);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 336,
	height: 280,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/speed_336x280_en_atlas_P_1.png", id:"speed_336x280_en_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;