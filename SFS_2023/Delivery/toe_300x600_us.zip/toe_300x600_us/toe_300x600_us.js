(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.text2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABUCUIgEipIgmCpIhTAAIgnipIgDCpIhfAAIAQknIB9AAIAlCgIAmigIB9AAIAQEng");
	this.shape.setTransform(200.7,21.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhzBxQgtgqAAhHQAAhGAtgpQAtgpBGAAQBHAAAtApQAtApAABGQAABHgtAqQgtAohHAAQhGAAgtgogAgtgzQgSATAAAfQAAAeASAUQARASAcAAQAcAAASgSQARgUAAgeQAAgfgRgTQgRgTgdAAQgcAAgRATg");
	this.shape_1.setTransform(164.475,21.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAXCUIgvhjIgMAAIAABjIhhAAIAAknICBAAQA2AAAfAVQAkAaAAAvQAAA7gxAeIBCBwgAglgXIAZAAQAOAAAGgFQALgIAAgNQAAgNgLgHQgGgFgOAAIgZAAg");
	this.shape_2.setTransform(134.725,21.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhmCUIAAknIDNAAIAABMIhtAAIAAAuIBnAAIAABMIhnAAIAABhg");
	this.shape_3.setTransform(107.975,21.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ah4BxIAshJQATAQAXAIQAXAIANAAQAVAAAAgNQgCgKgTgFIgqgOQgcgLgNgLQgbgWAAgoQAAgrAigdQAggZA3AAQBAAAAqAjIglBFQgQgNgUgIQgVgHgOAAQgXAAAAAMQAAAIATAFIAPAFIAVAGQAhALARAOQAcAXAAApQgBAvgmAeQgiAZg1AAQg8AAg3gng");
	this.shape_4.setTransform(74.7,21.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgwCUIAAjcIhFAAIAAhLIDsAAIAABLIhHAAIAADcg");
	this.shape_5.setTransform(51.5,21.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgvCUIAAknIBgAAIAAEng");
	this.shape_6.setTransform(32.65,21.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhmCUIAAknIDNAAIAABMIhtAAIAAAuIBnAAIAABMIhnAAIAABhg");
	this.shape_7.setTransform(14.475,21.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(0,0,222.1,47), null);


(lib.text1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgwCUIAAjcIhFAAIAAhLIDrAAIAABLIhGAAIAADcg");
	this.shape.setTransform(179.85,-6.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah4BxIArhJQAUAQAXAIQAXAIAMAAQAXAAgBgNQgCgKgTgFIgqgOQgcgLgNgLQgbgWAAgoQAAgrAjgdQAfgZA3AAQA/AAAqAjIgkBFQgQgNgUgIQgVgHgOAAQgXAAAAAMQAAAIAUAFIAOAFIAVAGQAhALAQAOQAcAXAAApQABAvgnAeQgiAZg1AAQg9AAg2gng");
	this.shape_1.setTransform(156,-5.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhqCUIAAknIDRAAIAABMIhxAAIAAAgIBqAAIAABMIhqAAIAAAiIB2AAIAABNg");
	this.shape_2.setTransform(131.95,-6.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ah/CUIAAknIB6AAQAxAAAZAKQAUAIAMAQQAMASAAAXQAAAXgMATQgMARgRAHQAaAGAPASQAPATAAAZQAAAtghAWQgdATgwAAgAgfBMIAgAAQAeAAAAgXQAAgNgJgGQgIgFgNAAIggAAgAgfgiIAUAAQANAAAHgFQAJgGAAgLQAAgLgJgGQgGgEgOAAIgUAAg");
	this.shape_3.setTransform(105.675,-6.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhrCUIAAknIDSAAIAABMIhxAAIAAAgIBrAAIAABMIhrAAIAAAiIB1AAIAABNg");
	this.shape_4.setTransform(70.35,-6.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AApCUIAAhtIhQAAIAABtIhhAAIAAknIBhAAIAABrIBQAAIAAhrIBgAAIAAEng");
	this.shape_5.setTransform(41.55,-6.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgwCUIAAjcIhGAAIAAhLIDtAAIAABLIhGAAIAADcg");
	this.shape_6.setTransform(13.85,-6.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text1, new cjs.Rectangle(0,-27.6,193.9,47), null);


(lib.logo_en_stacked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgFAVIAAgfIgJAAIAAgLIAdAAIAAALIgJAAIAAAfg");
	this.shape.setTransform(321.4,336.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPAVIgDgVIgKAVIgDAAIgKgVIgDAVIgMAAIAHgqIAMAAIAHAWIAIgWIAMAAIAHAqg");
	this.shape_1.setTransform(325.8,336.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgnCYIAAiSIhuidIBeAAIA3BTIA4hTIBeAAIhvCdIAACSg");
	this.shape_2.setTransform(300.9,349.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhVCYIAAkvICrAAIAABDIhcAAIAAAzIBXAAIAABCIhXAAIAAA0IBcAAIAABDg");
	this.shape_3.setTransform(275.325,349.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAoCYIhmiEIAACEIhPAAIAAkvIBPAAIAAB9IBfh9IBiAAIh5CQICECfg");
	this.shape_4.setTransform(249.025,349.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhDBzQgwgvAAhEQAAhEAwguQAvgtBAAAQAiAAAmAQIAABeQgcghgogBQgjAAgXAZQgXAXAAAjQAAAkAYAYQAWAYAjAAQAmAAAeghIAABeIgIADQgkAMgdAAQg/AAgvgtg");
	this.shape_5.setTransform(218.275,349.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ah4ByQgvgtAAhFQAAhDAvgtQAwgvBIAAQBJAAAwAvQAvAtAABDQAABFgvAtQgwAuhJAAQhIAAgwgugAg7g6QgaAXAAAjQAAAkAaAYQAYAYAjAAQAjAAAZgYQAZgYAAgkQAAgjgZgXQgZgZgjAAQgjAAgYAZg");
	this.shape_6.setTransform(186.275,349.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AA5CYIAAh9IhxAAIAAB9IhPAAIAAkvIBPAAIAAB1IBxAAIAAh1IBPAAIAAEvg");
	this.shape_7.setTransform(150.925,349.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAcCYIhKh1IAAB1IhPAAIAAkvIB7AAQAvAAAbAcQAZAaAAAoQAABFhDAPIBgB9gAgugPIAOAAQAYAAALgKQANgKAAgRQAAgSgNgKQgLgKgYAAIgOAAg");
	this.shape_8.setTransform(107.8,349.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ah4ByQgvgtAAhFQAAhDAvgtQAwgvBIAAQBJAAAwAvQAvAtAABDQAABFgvAtQgwAuhJAAQhJAAgvgugAg7g6QgZAXgBAjQABAkAZAYQAYAYAjAAQAjAAAZgYQAagYgBgkQABgjgagXQgZgZgjAAQgjAAgYAZg");
	this.shape_9.setTransform(73.4,349.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhWCYIAAkvICtAAIAABDIheAAIAAAzIBVAAIAABCIhVAAIAAB3g");
	this.shape_10.setTransform(44.6,349.725);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AirEtIAApZIFWAAIAACEIi5AAIAABlICvAAIAACDIivAAIAABpIC5AAIAACEg");
	this.shape_11.setTransform(336.6,269.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgcEpQg7gWgvgsQhihYAAiPQAAg9AXg6QAXg5ArgtQAtgvA+gaQA8gaBBAAQBHAABJAeIAAC+QgXgfgmgSQgkgSgqABQhHgBgtAxQgtAxAABGQAABJAtAvQAtAuBKABQAmAAAlgSQAkgSAZgdIAAC+QgxAPgWAFQgjAIgiAAQg/AAg6gYg");
	this.shape_12.setTransform(280.475,269.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AA4EtIiTjnIgCAAIAADnIicAAIAApZIDqAAQBdAAA3AtQA8AvAABdQAABBgiAuQgkAvg+ALIC9D3gAhdgeIAPAAQAwAAAagNQAigSAAgtQAAgrgigTQgagNgwABIgPAAg");
	this.shape_13.setTransform(225.475,269.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhqEmQg6gRgjgjQgogngOg8QgJgnAAhLIAAlRICdAAIAAE8QAABNAPAiQAYA1BCgBQBDABAYg1QAPgjAAhMIAAk8ICdAAIAAFRQAABKgJAoQgOA8gpAnQgjAjg5ARQgxAPg6AAQg5AAgxgPg");
	this.shape_14.setTransform(158.525,270.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AjtDjQhfhdAAiRQABiEBlhaQBhhWCFgBQCFABBiBWQBlBaAACEQAACRhdBdQheBdiRAAQiQAAhdhdgAh3h4QgyAvAABAQAABMAyAzQAxAzBGAAQBHAAAxgzQAyg0AAhLQAAhAgygvQgzgwhFAAQhFAAgyAwg");
	this.shape_15.setTransform(86.6,269.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AiEEwQgzgRgagYIAAiUQAcAhA2AYQAzAXArAAQAoAAAWgOQAVgPAAgZQAAgZgXgRQgXgPg4gVQicg5AAiIQAAhSA5g2QA5g2BfAAQA1AAAsAOQAtAQAaASIAACTQgYgcgsgUQgrgWgmABQgjAAgSAOQgTAPAAAZQAAAYAUAQQATAQA1AUQBOAcAuAuQAuAwAABDQAABXg9A2Qg8A3hrAAQhBAAgxgRg");
	this.shape_16.setTransform(19.95,269.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAyK0QiSAAiCg3QiCg3hghoQhbhhgxh9Qgyh9AAiDQAAkdDLjLQDLjLEdAAQFYADD6DGIAAEQQiEhziNg2QiNg3ijAAQi/AAh/CLQh0CAAACoQAAClB3CCQB/CLC5AAQA5AAAnAmQAmAmAAA6QAAA3grAoQgpAkgyAAg");
	this.shape_17.setTransform(168.825,66.375);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AmrJUQiUhIh0h5IAAkXQCECOCHBKQC5BnDgAAQC/AAB+iLQB1iAAAioQAAilh3iCQiAiLi4AAQg7AAglgmQgmgmAAg6QAAg4AqgnQAogkA0AAIAMAAQCSgBCCA4QCCA4BhBoQBaBhAyB8QAxB9AACCQAAEejLDLQhgBgh8A1QiAA3iNAAQjogCjDhfg");
	this.shape_18.setTransform(178.875,120.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_en_stacked, new cjs.Rectangle(-1,-2.8,354.8,368.5), null);


(lib.endText = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAfAVIgDgWIgKAWIgFAAIgJgWIgDAWIgLAAIAHgpIALAAIAIAUIAJgUIALAAIAHApgAghAVIAAgfIgJAAIAAgKIAeAAIAAAKIgJAAIAAAfg");
	this.shape.setTransform(163.953,5.2228,0.594,0.594);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOAOQgGgFAAgJQAAgIAGgFQAFgEAJgBQAJABAGAEQAGAFAAAIQAAAJgGAFQgGAEgJABQgJgBgFgEg");
	this.shape_1.setTransform(163.225,13.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgpA7IAAh1IBSAAIAAAfIgsAAIAAAMIApAAIAAAeIgpAAIAAANIAuAAIAAAfg");
	this.shape_2.setTransform(155.5,9.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAiA7IgChCIgQBCIggAAIgPhCIgBBCIgmAAIAHh1IAxAAIAOA/IAPg/IAxAAIAHB1g");
	this.shape_3.setTransform(142.8,9.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAUA7IgEgRIghAAIgEARIgoAAIAph1IApAAIApB1gAAIANIgIgfIgIAfIAQAAg");
	this.shape_4.setTransform(129.2,9.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgmAuQgTgRAAgdQAAgdATgQQARgPAaAAQAUAAAPAJQAGAEAIAIIgaAVQgKgKgNAAQgKAAgHAHQgHAIAAANQAAANAHAIQAHAIAKAAQALAAAEgDIABgBIAAgJIgSAAIAAgcIA3AAIAAAzIgGAGIgIAFIgKAGQgNAEgRABQgZAAgRgPg");
	this.shape_5.setTransform(116.775,9.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAJA7IgRgnIgGAAIAAAnIgmAAIAAh1IAzAAQAVAAAMAJQAPAKAAATQAAAXgUALIAaAtgAgOgIIAKAAQAFAAACgCQAEgDAAgFQAAgGgEgCQgCgDgFAAIgKAAg");
	this.shape_6.setTransform(102.25,9.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgoAuQgMgNAAgZIAAhDIAmAAIAABEQAAAJAEAEQAFAEAFAAQAHAAAEgEQAEgEAAgJIAAhEIAmAAIAABDQAAAZgMANQgOAOgbAAQgaAAgOgOg");
	this.shape_7.setTransform(90,9.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgtAtQgSgRAAgcQAAgbASgQQASgQAbgBQAcABASAQQASAQAAAbQAAAcgSARQgSAQgcAAQgbAAgSgQgAgRgTQgHAHAAAMQAAAMAHAHQAHAIAKAAQALAAAHgIQAHgHAAgMQAAgMgHgHQgHgIgLAAQgLAAgGAIg");
	this.shape_8.setTransform(77.225,9.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgSA7IAAguIgphHIArAAIAQAoIASgoIAqAAIgpBHIAAAug");
	this.shape_9.setTransform(65.55,9.725);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgSA7IAAhXIgcAAIAAgeIBdAAIAAAeIgcAAIAABXg");
	this.shape_10.setTransform(51.925,9.725);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgSA7IAAh1IAlAAIAAB1g");
	this.shape_11.setTransform(44.525,9.725);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgoA7IAAh1IBRAAIAAAfIgrAAIAAASIAoAAIAAAdIgoAAIAAAng");
	this.shape_12.setTransform(37.325,9.725);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgqA7IAAh1IBTAAIAAAfIgsAAIAAAMIApAAIAAAeIgpAAIAAANIAuAAIAAAfg");
	this.shape_13.setTransform(24.35,9.725);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAQA7IgQhCIgPBCIgnAAIghh1IAoAAIAOBBIAPhBIAlAAIAPBBIAOhBIAoAAIghB1g");
	this.shape_14.setTransform(10.625,9.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endText, new cjs.Rectangle(0,0,168.4,21), null);


(lib.CTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AgsA+IAAh7IBXAAIAAAgIgvAAIAAAOIAsAAIAAAeIgsAAIAAAPIAxAAIAAAgg");
	this.shape.setTransform(121.95,32.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#231F20").s().p("AAJA+IgSgpIgGAAIAAApIgoAAIAAh7IA2AAQAWAAANAJQAPALAAATQAAAZgVAMIAcAvgAgPgJIALAAQAFAAACgCQAFgDAAgGQAAgGgFgCQgCgCgFgBIgLAAg");
	this.shape_1.setTransform(111.225,32.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#231F20").s().p("AgvAvQgUgSAAgdQAAgdAUgRQASgRAdAAQAeAAASARQAUARgBAdQABAdgUASQgSARgeAAQgdAAgSgRgAgSgVQgIAIAAANQAAAMAIAJQAHAHALAAQAMAAAHgHQAIgJAAgMQAAgNgIgIQgHgIgMAAQgLAAgHAIg");
	this.shape_2.setTransform(97.6,32.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#231F20").s().p("AAkA+IgChGIgQBGIgiAAIgQhGIgCBGIgoAAIAHh7IA1AAIAOBCIAQhCIA0AAIAHB7g");
	this.shape_3.setTransform(82.45,32.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#231F20").s().p("AARA+IglhEIABAVIAAAvIgoAAIAAh7IAsAAIAkBEIgBgVIAAgvIAnAAIAAB7g");
	this.shape_4.setTransform(64.1,32.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#231F20").s().p("AAJA+IgSgpIgGAAIAAApIgoAAIAAh7IA2AAQAWAAANAJQAPALAAATQAAAZgVAMIAcAvgAgPgJIALAAQAFAAACgCQAFgDAAgGQAAgGgFgCQgCgCgFgBIgLAAg");
	this.shape_5.setTransform(51.925,32.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#231F20").s().p("AAWA+IgFgRIgjAAIgEARIgrAAIAsh7IAsAAIArB7gAAIANIgIggIgJAgIARAAg");
	this.shape_6.setTransform(39.025,32.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#231F20").s().p("AgsA+IAAh7IBXAAIAAAgIgvAAIAAAOIAsAAIAAAeIgsAAIAAAPIAxAAIAAAgg");
	this.shape_7.setTransform(27.65,32.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#231F20").s().p("AgpA+IAAh7IApAAIAABaIAqAAIAAAhg");
	this.shape_8.setTransform(17.95,32.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AphC0QhaAAAAhQIAAjHQAAhQBaAAITDAAQBaAAAABQIAADHQAABQhaAAg");
	this.shape_9.setTransform(70,32.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(0,14.5,140,36), null);


(lib.Btext22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgmAiQgOgMABgWQgBgVAOgMQAPgNAXAAQAYAAAOANQAOAMAAAVQAAAWgOAMQgOANgYAAQgXAAgPgNg");
	this.shape.setTransform(138.25,25.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhiBzQgwgpAAhKQAAhKAxgpQArglBCAAQAzAAAmAXQAQAIAUAVIhBA2QgagbgiABQgagBgRAUQgSAUAAAhQAAAiASATQARAUAaAAQAeAAAIgJIADgCIAAgVIgtAAIAAhHICLAAIAACAIgQAPIgTANQgOAKgNAEQggANgrAAQhAAAgsgmg");
	this.shape_1.setTransform(114.525,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA0CUIgMgqIhUAAIgLAqIhlAAIBnknIBrAAIBnEngAAUAgIgVhOIgWBOIArAAg");
	this.shape_2.setTransform(83.725,14.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAXCUIgvhjIgMAAIAABjIhhAAIAAknICBAAQA2AAAfAVQAkAaAAAvQAAA7gxAeIBCBwgAglgXIAZAAQAOAAAGgFQALgIAAgNQAAgNgLgHQgGgFgOAAIgZAAg");
	this.shape_3.setTransform(55.675,14.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AiLCUIAAknIBwAAQBLAAAqAgQAyAmAABNQAABOgyAmQgqAghLAAgAgqBDIAWAAQAdAAAQgQQARgRAAgiQAAglgRgQQgQgPgdAAIgWAAg");
	this.shape_4.setTransform(25.275,14.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhDAlIAAhJICHAAIAABJg");
	this.shape_5.setTransform(0.875,18.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhrCUIAAknIDSAAIAABMIhxAAIAAAgIBrAAIAABMIhrAAIAAAiIB2AAIAABNg");
	this.shape_6.setTransform(-19.4,14.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhzBxQgtgqAAhHQAAhGAtgpQAtgpBGAAQBHAAAtApQAtApAABGQAABHgtAqQgtAohHAAQhGAAgtgogAgtgzQgSATAAAfQAAAeASAUQARASAcAAQAcAAASgSQARgUAAgeQAAgfgRgTQgRgTgdAAQgcAAgRATg");
	this.shape_7.setTransform(-49.275,14.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgwCUIAAjcIhGAAIAAhLIDtAAIAABLIhGAAIAADcg");
	this.shape_8.setTransform(-76.15,14.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-6.6,238,47);


(lib.Btext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhzBxQgtgqAAhHQAAhGAtgpQAtgpBGAAQBHAAAtApQAtApAABGQAABHgtAqQgtAohHAAQhGAAgtgogAgtgzQgSATAAAfQAAAeASAUQARASAcAAQAcAAASgSQARgUAAgeQAAgfgRgTQgRgTgdAAQgcAAgRATg");
	this.shape.setTransform(167.225,-4.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgwCUIAAjcIhFAAIAAhLIDrAAIAABLIhGAAIAADcg");
	this.shape_1.setTransform(140.35,-4.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AiLCUIAAknIBwAAQBLAAAqAgQAyAmAABNQAABOgyAmQgqAghLAAgAgqBDIAWAAQAdAAAQgQQARgRAAgiQAAglgRgQQgQgPgdAAIgWAAg");
	this.shape_2.setTransform(105.325,-4.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AA0CUIgMgqIhUAAIgLAqIhlAAIBnknIBrAAIBnEngAAUAgIgVhOIgWBOIArAAg");
	this.shape_3.setTransform(73.975,-4.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhrCUIAAknIDSAAIAABMIhxAAIAAAgIBqAAIAABMIhqAAIAAAiIB1AAIAABNg");
	this.shape_4.setTransform(46.7,-4.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AApCUIAAhtIhQAAIAABtIhiAAIAAknIBiAAIAABrIBQAAIAAhrIBhAAIAAEng");
	this.shape_5.setTransform(17.9,-4.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btext1, new cjs.Rectangle(0,-26.4,186.4,47), null);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text2();
	this.instance.setTransform(0,-61.8,1,1,0,0,0,90,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90,-85.8,222.1,47);


// stage content:
(lib.toe_300x600_us = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// cta_end
	this.instance = new lib.CTA();
	this.instance.setTransform(140,465.95,1,1,0,0,0,62,18);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(171).to({_off:false},0).to({alpha:1},22,cjs.Ease.cubicInOut).wait(13));

	// EndText
	this.instance_1 = new lib.endText();
	this.instance_1.setTransform(-90.95,369.5,1,1,0,0,0,84.2,10.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(156).to({_off:false},0).to({x:149.05},20,cjs.Ease.quartOut).wait(30));

	// Logo
	this.instance_2 = new lib.logo_en_stacked();
	this.instance_2.setTransform(148.25,267.4,0.4,0.4,0,0,0,177.5,184.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(132).to({_off:false},0).to({alpha:1},29,cjs.Ease.quartInOut).wait(45));

	// cta
	this.instance_3 = new lib.CTA();
	this.instance_3.setTransform(84.45,403.4,1,1,0,0,0,62,18);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(116).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(72));

	// Btext2
	this.instance_4 = new lib.Btext22();
	this.instance_4.setTransform(-161.15,327.2);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(17).to({_off:false},0).to({x:110.05},22,cjs.Ease.quartOut).wait(74).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(75));

	// Btext1
	this.instance_5 = new lib.Btext1();
	this.instance_5.setTransform(-132,333,1,1,0,0,0,74.8,24);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(13).to({_off:false},0).to({x:94.8,y:331.8},22,cjs.Ease.quartOut).wait(75).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(78));

	// text2
	this.instance_6 = new lib.Tween2("synched",0);
	this.instance_6.setTransform(-141.95,327.2);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(9).to({_off:false},0).to({x:110.05},21,cjs.Ease.quartOut).wait(77).to({startPosition:0},0).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},1).wait(81));

	// text1
	this.instance_7 = new lib.text1();
	this.instance_7.setTransform(-184.8,252.6,1,1,0,0,0,74.8,24);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(5).to({_off:false},0).to({x:94.8},21,cjs.Ease.quartOut).wait(78).to({alpha:0},17,cjs.Ease.quartInOut).to({_off:true},4).wait(81));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(206));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-109.6,300,409.6,300);
// library properties:
lib.properties = {
	id: '758E0282264D47629A39BAD509FAEF4B',
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['758E0282264D47629A39BAD509FAEF4B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;